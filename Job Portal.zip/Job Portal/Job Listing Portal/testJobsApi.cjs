const axios = require('axios');

async function testJobsApi() {
  try {
    console.log('Testing Jobs API...');
    
    // First login as admin to get token
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@jobportal.com',
      password: 'Admin'
    });
    
    const token = loginResponse.data.token;
    console.log('Admin token obtained');
    
    // Test admin jobs endpoint
    const response = await axios.get('http://localhost:5000/api/users/admin/jobs', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('Jobs API Response:');
    console.log(JSON.stringify(response.data, null, 2));
    
  } catch (error) {
    console.error('Error testing Jobs API:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

testJobsApi();