# Admin Panel Data Relationships

This document explains how data is connected in the admin panel of the job portal application.

## Database Models and Relations

### 1. User Model
- **Fields**: name, email, password, role, profile, company, jobSeekerProfile
- **Roles**: admin, employer, jobseeker
- **Relations**:
  - One-to-Many with Job (employer → jobs)
  - One-to-Many with Application (jobseeker → applications)

### 2. Job Model
- **Fields**: title, description, requirements, location, employmentType, company, applicants, etc.
- **Relations**:
  - Many-to-One with User (job → employer)
  - One-to-Many with Application (job → applications)

### 3. Application Model
- **Fields**: job, applicant, resume, coverLetter, status
- **Relations**:
  - Many-to-One with Job (application → job)
  - Many-to-One with User (application → jobseeker)

## Admin Panel Components

### 1. Dashboard
- Shows statistics from all models:
  - Total users (User.count)
  - Total jobs (Job.count)
  - Total applications (Application.count)
  - Active jobs (Job.where(isActive: true))

### 2. User Management
- Displays all users with enhanced information:
  - For employers: Includes job count (Job.where(company: user._id).count)
  - For job seekers: Includes application count (Application.where(applicant: user._id).count)
- Actions: View, Block/Unblock, Delete

### 3. Employer Management
- Filtered view of users where role = 'employer'
- Shows:
  - Employer details (name, email, company info)
  - Job count for each employer
  - Approval status
  - Account status
- Actions: View, Delete

### 4. Job Seeker Management
- Filtered view of users where role = 'jobseeker'
- Shows:
  - Job seeker details (name, email)
  - Application count for each job seeker
  - Account status
- Actions: View, Delete

### 5. Job Management
- Displays all jobs with company information
- Shows:
  - Job details (title, location, created date)
  - Company details (name)
  - Applicant count (applications where job = this job)
  - Status (active/inactive)
- Actions: View, Close, Delete

### 6. Application Management
- Displays all applications with populated data
- Shows:
  - Job details (title, company)
  - Applicant details (name, email)
  - Application date
  - Status
- Actions: View, Download Resume

## API Endpoints

### User Endpoints
- `GET /api/users` - Get all users with enhanced information
- `DELETE /api/users/:id` - Delete user
- `PUT /api/users/:id/block` - Block/unblock user
- `PUT /api/users/:id/approve-company` - Approve company

### Job Endpoints
- `GET /api/users/admin/jobs` - Get all jobs
- `DELETE /api/users/admin/jobs/:id` - Delete job
- `PUT /api/users/admin/jobs/:id/close` - Close job

### Application Endpoints
- `GET /api/applications/admin/all` - Get all applications
- `GET /api/applications/admin/:id/resume` - Download resume (admin)

## Data Flow

1. **Dashboard Statistics**:
   - Admin requests dashboard data
   - Server queries each model for counts
   - Server returns aggregated statistics

2. **User Management**:
   - Admin requests all users
   - Server fetches users and enhances with job/application counts
   - Server returns enhanced user data

3. **Job Management**:
   - Admin requests all jobs
   - Server fetches jobs with populated company data
   - Server returns job data with applicant counts

4. **Application Management**:
   - Admin requests all applications
   - Server fetches applications with populated job and applicant data
   - Server returns enhanced application data

## Security

All admin endpoints are protected with:
- Authentication middleware (protect)
- Authorization middleware (authorize('admin'))

This ensures only authenticated admin users can access these endpoints.