// Diagnostic script to check what's happening with jobs data in the frontend
import React, { useState, useEffect } from 'react';
import { adminAPI } from './client/src/services/api';

const DiagnoseJobs = () => {
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [loading, setLoading] = useState(true);

  // Fetch jobs
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setLoading(true);
        const response = await adminAPI.getAllJobs();
        console.log('Raw jobs data:', response.data);
        setJobs(response.data);
        setFilteredJobs(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching jobs:', error);
        setLoading(false);
        setJobs([]);
        setFilteredJobs([]);
      }
    };

    fetchJobs();
  }, []);

  // Filter jobs (same logic as in Jobs.jsx)
  useEffect(() => {
    console.log('Filtering jobs...');
    console.log('Original jobs count:', jobs.length);
    console.log('Search term:', searchTerm);
    console.log('Filter status:', filterStatus);
    
    let result = jobs;
    console.log('Initial result count:', result.length);
    
    if (searchTerm) {
      result = result.filter(job => {
        const matches = 
          (job.title && job.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (job.company?.name && job.company.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (job.company?.company?.name && job.company.company.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (job.location && job.location.toLowerCase().includes(searchTerm.toLowerCase()));
        console.log('Job', job.title, 'matches search:', matches);
        return matches;
      });
      console.log('After search filter count:', result.length);
    }
    
    if (filterStatus !== 'all') {
      result = result.filter(job => {
        let matches = false;
        if (filterStatus === 'active') {
          matches = job.isActive === true;
        } else if (filterStatus === 'closed') {
          matches = job.isActive === false;
        }
        console.log('Job', job.title, 'matches status filter:', matches);
        return matches;
      });
      console.log('After status filter count:', result.length);
    }
    
    console.log('Final filtered jobs count:', result.length);
    console.log('Filtered jobs:', result);
    setFilteredJobs(result);
  }, [searchTerm, filterStatus, jobs]);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h1>Jobs Diagnosis</h1>
      <p>Total jobs: {jobs.length}</p>
      <p>Filtered jobs: {filteredJobs.length}</p>
      
      <div>
        <h2>Filters</h2>
        <input 
          type="text" 
          placeholder="Search term" 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <select 
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
        >
          <option value="all">All Statuses</option>
          <option value="active">Active</option>
          <option value="pending">Pending</option>
          <option value="closed">Closed</option>
        </select>
      </div>
      
      <div>
        <h2>Jobs Data</h2>
        <pre>{JSON.stringify(jobs, null, 2)}</pre>
      </div>
      
      <div>
        <h2>Filtered Jobs Data</h2>
        <pre>{JSON.stringify(filteredJobs, null, 2)}</pre>
      </div>
    </div>
  );
};

export default DiagnoseJobs;