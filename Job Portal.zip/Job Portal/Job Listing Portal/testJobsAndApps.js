import axios from 'axios';

async function testJobsAndApplications() {
  try {
    console.log('Testing jobs and applications API endpoints...');
    
    // First, login as admin
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@jobportal.com',
      password: 'Admin'
    });
    
    const token = loginResponse.data.token;
    console.log('Admin logged in successfully');
    
    // Create axios instance with auth header
    const api = axios.create({
      baseURL: 'http://localhost:5000/api',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    // Test getting all jobs
    const jobsResponse = await api.get('/users/admin/jobs');
    console.log('Jobs count:', jobsResponse.data.length);
    console.log('Jobs:', JSON.stringify(jobsResponse.data, null, 2));
    
    // Test getting all applications
    const applicationsResponse = await api.get('/applications/admin/all');
    console.log('Applications count:', applicationsResponse.data.length);
    console.log('Applications:', JSON.stringify(applicationsResponse.data, null, 2));
    
    console.log('Test completed successfully!');
  } catch (error) {
    console.error('Error testing API:', error.response?.data || error.message);
  }
}

testJobsAndApplications();