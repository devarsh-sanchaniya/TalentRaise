// Diagnostic script to check what's happening with admin data
import axios from 'axios';

async function diagnoseAdminData() {
  try {
    console.log('=== Admin Data Diagnosis ===');
    
    // Login as admin
    console.log('\n1. Logging in as admin...');
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@jobportal.com',
      password: 'Admin'
    });
    
    const token = loginResponse.data.token;
    console.log('✓ Admin login successful');
    console.log('  Token:', token.substring(0, 20) + '...');
    console.log('  Role:', loginResponse.data.role);
    
    // Create API client
    const api = axios.create({
      baseURL: 'http://localhost:5000/api',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    // Check users
    console.log('\n2. Checking users...');
    const usersResponse = await api.get('/users');
    console.log('  Users count:', usersResponse.data.length);
    
    // Check jobs
    console.log('\n3. Checking jobs...');
    const jobsResponse = await api.get('/users/admin/jobs');
    console.log('  Jobs count:', jobsResponse.data.length);
    if (jobsResponse.data.length > 0) {
      console.log('  First job:', {
        id: jobsResponse.data[0]._id,
        title: jobsResponse.data[0].title,
        company: jobsResponse.data[0].company?.name || jobsResponse.data[0].company?.company?.name,
        applicants: jobsResponse.data[0].applicants?.length || 0
      });
    }
    
    // Check applications
    console.log('\n4. Checking applications...');
    const applicationsResponse = await api.get('/applications/admin/all');
    console.log('  Applications count:', applicationsResponse.data.length);
    if (applicationsResponse.data.length > 0) {
      console.log('  First application:', {
        id: applicationsResponse.data[0]._id,
        jobTitle: applicationsResponse.data[0].job?.title,
        applicantName: applicationsResponse.data[0].applicant?.name,
        status: applicationsResponse.data[0].status
      });
    }
    
    console.log('\n=== Diagnosis Complete ===');
    console.log('If you see data above but it\'s not showing in the admin panel,');
    console.log('the issue is likely in the frontend rendering/filtering logic.');
    
  } catch (error) {
    console.error('❌ Error during diagnosis:', error.response?.data || error.message);
  }
}

diagnoseAdminData();