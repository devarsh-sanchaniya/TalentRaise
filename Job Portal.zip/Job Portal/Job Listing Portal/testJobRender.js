// Test component to verify job rendering
import React from 'react';

const TestJobRender = () => {
  // Sample job data from our diagnostic
  const sampleJob = {
    "_id": "692d84ab8e2c03fffe4f220d",
    "title": "Java Developer",
    "description": "ffsf sdflsdfj asdfsdf asdfsf asdsdf asdf d sd sd sdfsdfs ",
    "requirements": [
      "expereance"
    ],
    "responsibilities": [
      "team work"
    ],
    "location": "Mumbai",
    "employmentType": "Full-time",
    "experienceLevel": "Mid",
    "salaryMin": 30000,
    "salaryMax": 40000,
    "salaryCurrency": "USD",
    "salaryPeriod": "Monthly",
    "category": "Technology",
    "skills": [],
    "deadline": "2025-12-10T00:00:00.000Z",
    "isActive": true,
    "company": {
      "_id": "692d7de38e2c03fffe4f219f",
      "name": "Raj patel",
      "email": "raj@gmail.com"
    },
    "applicants": [
      {
        "user": "692b04a85ea9b9ae0dd316e4",
        "status": "Pending",
        "_id": "692d8fa07298a2aab35ee28a",
        "appliedAt": "2025-12-01T12:52:48.011Z",
        "id": "692d8fa07298a2aab35ee28a"
      }
    ],
    "createdAt": "2025-12-01T12:06:03.495Z",
    "updatedAt": "2025-12-01T12:52:48.014Z",
    "__v": 1,
    "salary": "₹2,490,000 - ₹3,320,000",
    "formattedSalary": "₹30,000 - ₹40,000 Monthly",
    "id": "692d84ab8e2c03fffe4f220d"
  };

  // Test the getTypeClass function
  const getTypeClass = (type) => {
    switch (type) {
      case 'Full-time':
        return 'bg-blue-100 text-blue-800';
      case 'Part-time':
        return 'bg-purple-100 text-purple-800';
      case 'Contract':
        return 'bg-green-100 text-green-800';
      case 'Internship':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  try {
    console.log('Testing job rendering...');
    console.log('Job title:', sampleJob.title);
    console.log('Employment type:', sampleJob.employmentType);
    console.log('Type class:', getTypeClass(sampleJob.employmentType));
    console.log('Applicants count:', sampleJob.applicants ? sampleJob.applicants.length : 0);
    console.log('✅ Job rendering test passed!');
  } catch (error) {
    console.error('❌ Job rendering test failed:', error);
  }

  return (
    <div>
      <h1>Test Job Render</h1>
      <p>If you see this without errors, the job rendering should work.</p>
    </div>
  );
};

export default TestJobRender;