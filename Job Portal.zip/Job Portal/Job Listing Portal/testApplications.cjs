const axios = require('axios');

async function testApplications() {
  try {
    console.log('Testing applications API...');
    
    // First login as admin to get token
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@jobportal.com',
      password: 'Admin'
    });
    
    const token = loginResponse.data.token;
    console.log('Admin token obtained');
    
    // Test admin applications endpoint
    const applicationsResponse = await axios.get('http://localhost:5000/api/applications/admin/all', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('Total applications returned:', applicationsResponse.data.length);
    
    // Show first few applications
    console.log('First 3 applications:');
    console.log(JSON.stringify(applicationsResponse.data.slice(0, 3), null, 2));
    
  } catch (error) {
    console.error('Error testing applications:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

testApplications();