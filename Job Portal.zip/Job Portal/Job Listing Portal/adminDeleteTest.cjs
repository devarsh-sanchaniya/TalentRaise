const axios = require('axios');

async function adminDeleteTest() {
  try {
    console.log('Testing admin-side user deletion...');
    
    // Register a new test user with a unique email
    const timestamp = Date.now();
    const registerResponse = await axios.post('http://localhost:5000/api/auth/register', {
      name: 'Admin Delete Test User',
      email: `admindeletetest${timestamp}@test.com`,
      password: 'password123',
      role: 'jobseeker'
    });
    
    console.log('Test user registered successfully');
    const testUserId = registerResponse.data._id;
    
    // Login as admin
    const adminLoginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@jobportal.com',
      password: 'Admin'
    });
    
    const adminToken = adminLoginResponse.data.token;
    console.log('Admin logged in successfully');
    
    // Try to delete the user via admin API
    console.log('Attempting to delete user via admin API...');
    const deleteResponse = await axios.delete(`http://localhost:5000/api/users/${testUserId}`, {
      headers: {
        'Authorization': `Bearer ${adminToken}`
      }
    });
    
    console.log('Admin delete response:', deleteResponse.data);
    console.log('✅ Admin-side user deletion successful');
    
    // Try to login with the deleted user (should fail)
    try {
      await axios.post('http://localhost:5000/api/auth/login', {
        email: `admindeletetest${timestamp}@test.com`,
        password: 'password123'
      });
      console.log('❌ ISSUE: Admin-deleted user can still login');
    } catch (error) {
      if (error.response && error.response.status === 401) {
        console.log('✅ SUCCESS: Admin-deleted user cannot login anymore');
      } else {
        console.log('❓ INFO: Unexpected error when trying to login with admin-deleted user:', error.message);
      }
    }
    
  } catch (error) {
    console.error('Test error:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

adminDeleteTest();