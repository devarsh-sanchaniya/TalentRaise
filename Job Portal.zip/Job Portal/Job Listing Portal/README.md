# TalentRaise - Job Portal Web App

A modern, responsive job portal application built with React, Node.js, Express, and MongoDB.

## Features

### User Roles
- **Job Seekers**: Create profiles, search jobs, apply to positions, track applications
- **Employers**: Post jobs, manage applications, view candidate profiles
- **Admins**: Manage users, approve companies, moderate content

### Key Functionality
- User authentication with JWT
- Job posting and management
- Advanced job search and filtering
- Application tracking system
- Profile management
- Responsive design for all devices

## Tech Stack

### Frontend
- React 18 with Hooks
- React Router v6
- Tailwind CSS for styling
- Framer Motion for animations
- React Icons

### Backend
- Node.js with Express
- MongoDB with Mongoose
- JWT for authentication
- Bcrypt for password hashing
- Multer for file uploads
- Cloudinary for image storage

## Project Structure

```
job-portal/
├── client/           # React frontend
│   ├── src/
│   │   ├── components/   # Reusable UI components
│   │   ├── pages/        # Page components
│   │   ├── contexts/     # React contexts
│   │   ├── services/     # API service files
│   │   └── utils/        # Utility functions
│   └── ...
├── server/           # Node.js backend
│   ├── controllers/      # Request handlers
│   ├── models/          # Mongoose models
│   ├── routes/          # API routes
│   ├── middleware/      # Custom middleware
│   └── utils/           # Utility functions
└── ...
```

## Getting Started

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (local or cloud instance)
- npm or yarn

### Installation

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd job-portal
   ```

2. **Install server dependencies:**
   ```bash
   cd server
   npm install
   ```

3. **Install client dependencies:**
   ```bash
   cd ../client
   npm install
   ```

4. **Environment Variables:**
   
   Create a `.env` file in the `server` directory:
   ```env
   NODE_ENV=development
   PORT=5000
   MONGODB_URI=your_mongodb_connection_string
   JWT_SECRET=your_jwt_secret_key
   CLOUDINARY_CLOUD_NAME=your_cloud_name
   CLOUDINARY_API_KEY=your_api_key
   CLOUDINARY_API_SECRET=your_api_secret
   ```

### Running the Application

1. **Start the backend server:**
   ```bash
   cd server
   npm run dev
   ```

2. **Start the frontend development server:**
   ```bash
   cd client
   npm run dev
   ```

3. **Access the application:**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/profile` - Update user profile

### Jobs
- `GET /api/jobs` - Get all jobs
- `GET /api/jobs/:id` - Get job by ID
- `POST /api/jobs` - Create new job (Employer only)
- `PUT /api/jobs/:id` - Update job (Employer only)
- `DELETE /api/jobs/:id` - Delete job (Employer only)
- `GET /api/jobs/my-jobs` - Get jobs posted by employer (Employer only)

### Applications
- `POST /api/applications` - Apply for job (Job Seeker only)
- `GET /api/applications/job/:jobId` - Get applications for job (Employer only)
- `GET /api/applications/my-applications` - Get user's applications (Job Seeker only)
- `PUT /api/applications/:id` - Update application status (Employer only)

### Users (Admin)
- `GET /api/users` - Get all users (Admin only)
- `GET /api/users/:id` - Get user by ID (Admin only)
- `DELETE /api/users/:id` - Delete user (Admin only)
- `PUT /api/users/:id/approve-company` - Approve company (Admin only)
- `GET /api/users/admin/jobs` - Get all jobs (Admin only)
- `DELETE /api/users/admin/jobs/:id` - Delete job (Admin only)

## Deployment

### Frontend
The frontend can be deployed to any static hosting service like Netlify, Vercel, or GitHub Pages.

1. Build the production version:
   ```bash
   cd client
   npm run build
   ```

2. Deploy the `dist` folder to your hosting provider.

### Backend
The backend can be deployed to platforms like Heroku, Render, or any cloud provider that supports Node.js.

1. Set environment variables on your deployment platform
2. Deploy the `server` directory
3. Make sure to provision a MongoDB database

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a pull request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- [React](https://reactjs.org/)
- [Tailwind CSS](https://tailwindcss.com/)
- [Node.js](https://nodejs.org/)
- [Express](https://expressjs.com/)
- [MongoDB](https://www.mongodb.com/)