import { adminAuthAPI } from '../services/api';

/**
 * Validates admin authentication by checking token with server
 * @returns {Promise<boolean>} True if admin is authenticated, false otherwise
 */
export const validateAdminAuth = async () => {
  try {
    // Check if admin markers exist in localStorage
    const isAdminAuthenticated = localStorage.getItem('isAdmin') === 'true';
    const token = localStorage.getItem('adminToken');
    
    // If no token or not marked as admin, return false immediately
    if (!isAdminAuthenticated || !token) {
      return false;
    }

    // Validate token with server using adminAuthAPI
    const response = await adminAuthAPI.getProfile();
    
    // Check if user is actually an admin and the response is valid
    if (response.data && response.data.role === 'admin') {
      return true;
    } else {
      // User is not an admin or response is invalid, clear localStorage
      clearAdminAuth();
      return false;
    }
  } catch (error) {
    // Log the error for debugging
    console.error('Admin authentication validation error:', error);
    // Check if this is a 401 (unauthorized) error which means the token is invalid
    if (error.response && (error.response.status === 401 || error.response.status === 403)) {
      // Token is invalid, clear localStorage
      clearAdminAuth();
    }
    return false;
  }
};

/**
 * Clears all admin authentication data
 */
export const clearAdminAuth = () => {
  localStorage.removeItem('adminToken');
  localStorage.removeItem('adminUser');
  localStorage.removeItem('isAdmin');
};

/**
 * Sets admin authentication data
 * @param {Object} userData - User data from login response
 */
export const setAdminAuth = (userData) => {
  // Clear any existing auth data first
  clearAdminAuth();
  
  // Set new auth data with admin-specific keys
  localStorage.setItem('adminToken', userData.token);
  localStorage.setItem('adminUser', JSON.stringify(userData));
  localStorage.setItem('isAdmin', 'true');
};

/**
 * Gets admin token
 * @returns {string|null} Admin token or null if not authenticated
 */
export const getAdminToken = () => {
  return localStorage.getItem('adminToken');
};