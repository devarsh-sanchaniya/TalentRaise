// Utility function to convert USD to INR
// Using approximate exchange rate: 1 USD = 83 INR (as of 2024)
const USD_TO_INR_RATE = 83;

export const convertUsdToInr = (usdAmount) => {
  // Handle "plus" values (e.g., "$150k+")
  if (usdAmount.includes('+')) {
    const cleanAmount = usdAmount.replace(/[^\d.]/g, '');
    const value = parseFloat(cleanAmount);
    if (!isNaN(value)) {
      const inrValue = Math.round(value * USD_TO_INR_RATE);
      return `₹${formatNumber(inrValue)}+`;
    }
  }
  
  // Handle range values (e.g., "120k - 150k")
  if (usdAmount.includes('-')) {
    const parts = usdAmount.split('-');
    const min = parseFloat(parts[0].replace(/[^\d.]/g, ''));
    const max = parseFloat(parts[1].replace(/[^\d.]/g, ''));
    
    if (!isNaN(min) && !isNaN(max)) {
      const minInr = Math.round(min * USD_TO_INR_RATE);
      const maxInr = Math.round(max * USD_TO_INR_RATE);
      return `₹${formatNumber(minInr)} - ₹${formatNumber(maxInr)}`;
    }
  }
  
  // Handle hourly rates (e.g., "$20/hr")
  if (usdAmount.includes('/hr')) {
    const cleanAmount = usdAmount.replace(/[^\d.-]/g, '');
    const hourlyRate = parseFloat(cleanAmount);
    if (!isNaN(hourlyRate)) {
      const inrRate = Math.round(hourlyRate * USD_TO_INR_RATE);
      return `₹${formatNumber(inrRate)}/hr`;
    }
  }
  
  // Handle single values with k (e.g., "120k")
  if (usdAmount.includes('k')) {
    const cleanAmount = usdAmount.replace(/[^\d.-]/g, '');
    const value = parseFloat(cleanAmount);
    if (!isNaN(value)) {
      const inrValue = Math.round(value * USD_TO_INR_RATE);
      return `₹${formatNumber(inrValue)}`;
    }
  }
  
  // Handle single numeric values
  const cleanAmount = usdAmount.replace(/[^\d.-]/g, '');
  const numericValue = parseFloat(cleanAmount);
  if (!isNaN(numericValue)) {
    const inrValue = Math.round(numericValue * USD_TO_INR_RATE);
    return `₹${formatNumber(inrValue)}`;
  }
  
  // Return original if conversion fails
  return usdAmount;
};

// Helper function to format numbers with commas (e.g., 100000 -> 1,00,000)
const formatNumber = (num) => {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};

export default convertUsdToInr;