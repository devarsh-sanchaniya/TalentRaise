import React, { createContext, useState, useContext, useEffect } from 'react';
import { authAPI } from '../services/api';
import { useNavigate } from 'react-router-dom';

const AuthContext = createContext();

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is logged in (from localStorage or API)
    const token = localStorage.getItem('token');
    if (token) {
      // Fetch user data from API
      loadUser();
    } else {
      setLoading(false);
    }
  }, []);

  const loadUser = async () => {
    try {
      const res = await authAPI.getProfile();
      setUser(res.data);
    } catch (err) {
      console.error('Error loading user:', err);
      localStorage.removeItem('token');
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password) => {
    try {
      const res = await authAPI.login({ email, password });
      setUser(res.data);
      localStorage.setItem('token', res.data.token);
      return { success: true };
    } catch (err) {
      return { success: false, message: err.response?.data?.message || 'Login failed' };
    }
  };

  const logout = async () => {
    try {
      // Call the logout API to update the user's online status
      await authAPI.logout();
    } catch (err) {
      console.error('Logout API error:', err);
    } finally {
      // Clear user data from frontend
      setUser(null);
      localStorage.removeItem('token');
      // Redirect to home page after logout
      navigate('/');
    }
  };

  const register = async (userData) => {
    try {
      const res = await authAPI.register(userData);
      setUser(res.data);
      localStorage.setItem('token', res.data.token);
      return { success: true };
    } catch (err) {
      return { success: false, message: err.response?.data?.message || 'Registration failed' };
    }
  };

  const updateProfile = async (userData) => {
    try {
      const res = await authAPI.updateProfile(userData);
      setUser(res.data);
      return { success: true };
    } catch (err) {
      return { success: false, message: err.response?.data?.message || 'Profile update failed' };
    }
  };

  const deleteProfile = async () => {
    try {
      await authAPI.deleteProfile();
      logout();
      navigate('/'); // Redirect to home page after deletion
      return { success: true };
    } catch (err) {
      return { success: false, message: err.response?.data?.message || 'Profile deletion failed' };
    }
  };

  const value = {
    user,
    loading,
    login,
    logout,
    register,
    updateProfile,
    deleteProfile,
    loadUser
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};