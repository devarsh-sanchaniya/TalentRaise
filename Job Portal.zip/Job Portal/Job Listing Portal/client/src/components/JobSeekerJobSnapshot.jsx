import React, { useState, useEffect } from 'react';
import { FaBriefcase, FaCheck, FaTimes, FaClock, FaHistory, FaSearch } from 'react-icons/fa';
import { applicationsAPI, jobsAPI } from '../services/api';

const JobSeekerJobSnapshot = () => {
  const [applications, setApplications] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch job seeker's applications
        const appsRes = await applicationsAPI.getMyApplications();
        const applicationsData = appsRes.data || [];
        setApplications(applicationsData);

        // Fetch job details for each application to enrich data
        const jobIds = [...new Set(applicationsData.map(app => app.job?._id).filter(id => id))];
        const jobsData = [];
        
        for (const jobId of jobIds) {
          try {
            const jobRes = await jobsAPI.getJobById(jobId);
            jobsData.push(jobRes.data);
          } catch (jobErr) {
            console.error(`Error fetching job ${jobId}:`, jobErr);
          }
        }
        
        setJobs(jobsData);
        setError('');
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to load job applications data');
        // Still set empty arrays to render the component
        setApplications([]);
        setJobs([]);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);

  // Calculate statistics
  const totalApplied = applications.length;
  const acceptedCount = applications.filter(app => app.status.toLowerCase() === 'accepted' || app.status.toLowerCase() === 'accept').length;
  const rejectedCount = applications.filter(app => app.status.toLowerCase() === 'rejected').length;
  const interviewCount = applications.filter(app => app.status.toLowerCase() === 'interview').length;
  const pendingCount = applications.filter(app => app.status.toLowerCase() === 'pending').length;

  // Get recent activities (last 5 applications sorted by date)
  const recentActivities = [...applications]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case 'accepted':
      case 'accept':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'interview':
        return 'bg-yellow-100 text-yellow-800';
      case 'pending':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch (status.toLowerCase()) {
      case 'accepted':
      case 'accept':
        return <FaCheck className="text-green-500" />;
      case 'rejected':
        return <FaTimes className="text-red-500" />;
      case 'interview':
        return <FaClock className="text-yellow-500" />;
      case 'pending':
        return <FaClock className="text-blue-500" />;
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="animate-pulse flex flex-col space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-20 bg-gray-100 rounded"></div>
            ))}
          </div>
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-100 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="text-center py-8">
          <div className="text-red-500 text-2xl mb-2">⚠️</div>
          <h3 className="text-lg font-medium text-gray-900 mb-1">Error Loading Data</h3>
          <p className="text-gray-600">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-2">
              <FaSearch className="text-blue-600" />
              Job Application Tracker
            </h2>
            <p className="text-gray-600 text-sm mt-1">Track your job applications and progress</p>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-6 bg-gray-50">
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="text-2xl font-bold text-blue-600">{totalApplied}</div>
          <div className="text-sm text-gray-600">Jobs Applied</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="text-2xl font-bold text-green-600">{acceptedCount}</div>
          <div className="text-sm text-gray-600">Selected</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="text-2xl font-bold text-yellow-600">{interviewCount}</div>
          <div className="text-sm text-gray-600">Interviews</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="text-2xl font-bold text-red-600">{rejectedCount}</div>
          <div className="text-sm text-gray-600">Rejected</div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-gray-800 flex items-center gap-2">
            <FaHistory className="text-gray-600" />
            Recent Activity
          </h3>
          <span className="text-sm text-gray-600">{recentActivities.length} recent actions</span>
        </div>

        <div className="space-y-4">
          {recentActivities.length > 0 ? (
            recentActivities.map((app) => (
              <div key={app._id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 hover:shadow-sm transition-shadow">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center">
                      <FaBriefcase className="text-blue-600 text-lg" />
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">
                      {app.job?.title || 'Job Title'}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {app.job?.company?.company?.name || app.job?.company?.name || 'Company Name'}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Applied {new Date(app.createdAt).toLocaleDateString()} at {new Date(app.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(app.status)}`}>
                    {getStatusIcon(app.status)}
                    <span className="ml-1 capitalize">{app.status}</span>
                  </span>
                  <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                    View Details
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8">
              <div className="text-gray-400 text-5xl mb-3">📋</div>
              <h4 className="text-lg font-medium text-gray-900 mb-1">No Recent Activity</h4>
              <p className="text-gray-600">Your job applications will appear here</p>
            </div>
          )}
        </div>
      </div>

      {/* Progress Summary */}
      <div className="p-6 bg-gray-50 border-t border-gray-200">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Application Progress</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-xl font-bold text-blue-600">{pendingCount}</div>
            <div className="text-xs text-gray-600">Pending Review</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-yellow-600">{interviewCount}</div>
            <div className="text-xs text-gray-600">In Interview</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-green-600">{acceptedCount}</div>
            <div className="text-xs text-gray-600">Selected</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-red-600">{rejectedCount}</div>
            <div className="text-xs text-gray-600">Rejected</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobSeekerJobSnapshot;