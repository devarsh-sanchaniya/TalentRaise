import React from 'react';

const ResumePreview = ({ resumeData, className = '' }) => {
  const {
    personal = {},
    education = [],
    experience = [],
    skills = [],
    projects = [],
    certifications = [],
    activities = []
  } = resumeData;

  return (
    <div className={`bg-white ${className.includes('resume-preview-for-pdf') ? '' : 'rounded-2xl'} ${className.includes('resume-preview-for-pdf') ? '' : 'shadow-lg'} p-8 ${className.includes('resume-preview-for-pdf') ? '' : 'border border-gray-200'} w-full ${className}`}>
      {/* Header */}
      <div className="text-center mb-8 pb-6 border-b border-gray-200">
        <h1 className="text-3xl font-bold text-gray-900">
          {personal.firstName} {personal.lastName}
        </h1>
        <p className="text-lg text-primary-600 font-medium mt-2">
          {personal.headline}
        </p>
        <div className="flex flex-wrap justify-center gap-4 mt-4 text-sm text-gray-600">
          {personal.email && <span className="flex items-center gap-1.5"><span className="font-bold text-base">✉️</span> {personal.email}</span>}
          {personal.phone && <span className="flex items-center gap-1.5"><span className="font-bold text-base">📞</span> {personal.phone}</span>}
          {personal.location && <span className="flex items-center gap-1.5"><span className="font-bold text-base">📍</span> {personal.location}</span>}
          {personal.linkedin && <span className="flex items-center gap-1.5"><span className="font-bold text-base">💼</span> <a href={personal.linkedin} target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:underline">LinkedIn</a></span>}
          {personal.github && <span className="flex items-center gap-1.5"><span className="font-bold text-base">💻</span> <a href={personal.github} target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:underline">GitHub</a></span>}
        </div>
      </div>

      {/* Summary */}
      {personal.summary && (
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-3 pb-2 border-b border-gray-200 flex items-center">
            <span className="mr-2" style={{marginTop: '2px', alignSelf: 'center', verticalAlign: 'middle'}}>•</span> Summary
          </h2>
          <p className="text-gray-700 leading-relaxed break-words">
            {personal.summary}
          </p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Left Column */}
        <div>
          {/* Education */}
          {education.length > 0 && (
            <div className="mb-8">
              <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b-2 border-blue-500 flex items-center">
                <span className="mr-2" style={{marginTop: '2px', alignSelf: 'center', verticalAlign: 'middle'}}>•</span> Education
              </h2>
              <div className="space-y-4">
                {education.map((edu, index) => (
                  <div key={index} className="border-l-4 border-blue-500 pl-4">
                    <h3 className="font-semibold text-gray-900">{edu.degree} in {edu.fieldOfStudy}</h3>
                    <p className="text-blue-600 font-medium">{edu.institution}</p>
                    <p className="text-gray-600 text-sm">
                      {edu.startDate ? new Date(edu.startDate).toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric'
                      }) : ''} - {edu.endDate ? new Date(edu.endDate).toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric'
                      }) : 'Present'}
                    </p>
                    {edu.description && (
                      <p className="text-gray-700 mt-2 text-sm break-words">{edu.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Skills */}
          {skills.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b-2 border-gray-300 flex items-center">
                <span className="mr-2" style={{marginTop: '2px', alignSelf: 'center', verticalAlign: 'middle'}}>•</span> Skills
              </h2>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-gray-100 text-gray-800 rounded-full text-sm font-medium"
                  >
                    {skill.name}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {/* Projects */}
          {projects.length > 0 && (
            <div className="mt-8">
              <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b-2 border-blue-500 flex items-center">
                <span className="mr-2" style={{marginTop: '2px', alignSelf: 'center', verticalAlign: 'middle'}}>•</span> Projects
              </h2>
              <div className="space-y-4">
                {projects.map((project, index) => (
                  <div key={index} className="border-l-4 border-blue-500 pl-4">
                    <h3 className="font-semibold text-gray-900">{project.title}</h3>
                    <p className="text-blue-600 font-medium">{project.technologies}</p>
                    {project.description && (
                      <p className="text-gray-700 mt-2 text-sm break-words">{project.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column */}
        <div>
          {/* Experience */}
          {experience.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b-2 border-blue-500 flex items-center">
                <span className="mr-2" style={{marginTop: '2px', alignSelf: 'center', verticalAlign: 'middle'}}>•</span> Experience
              </h2>
              <div className="space-y-4">
                {experience.map((exp, index) => (
                  <div key={index} className="border-l-4 border-blue-500 pl-4">
                    <h3 className="font-semibold text-gray-900">{exp.position}</h3>
                    <p className="text-blue-600 font-medium">{exp.company}</p>
                    <p className="text-gray-600 text-sm">
                      {exp.startDate ? new Date(exp.startDate).toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric'
                      }) : ''} - {exp.endDate ? new Date(exp.endDate).toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric'
                      }) : 'Present'}
                    </p>
                    {exp.description && (
                      <p className="text-gray-700 mt-2 text-sm break-words">{exp.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Certifications */}
          {certifications.length > 0 && (
            <div className="mt-8">
              <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b-2 border-blue-500 flex items-center">
                <span className="mr-2" style={{marginTop: '2px', alignSelf: 'center', verticalAlign: 'middle'}}>•</span> Certifications
              </h2>
              <div className="space-y-4">
                {certifications.map((cert, index) => (
                  <div key={index} className="border-l-4 border-blue-500 pl-4">
                    <h3 className="font-semibold text-gray-900">{cert.name}</h3>
                    <p className="text-blue-600 font-medium">{cert.issuer}</p>
                    <p className="text-gray-600 text-sm">
                      {cert.dateObtained ? new Date(cert.dateObtained).toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric'
                      }) : ''}{cert.credentialId ? ' | ID: ' + cert.credentialId : ''}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Activities */}
          {activities.length > 0 && (
            <div className="mt-8">
              <h2 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b-2 border-blue-500 flex items-center">
                <span className="mr-2" style={{marginTop: '2px', alignSelf: 'center', verticalAlign: 'middle'}}>•</span> Activities
              </h2>
              <div className="space-y-4">
                {activities.map((activity, index) => (
                  <div key={index} className="border-l-4 border-blue-500 pl-4">
                    <h3 className="font-semibold text-gray-900">{activity.title}</h3>
                    <p className="text-blue-600 font-medium">{activity.organization}</p>
                    <p className="text-gray-600 text-sm">
                      {activity.date ? new Date(activity.date).toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric'
                      }) : ''}
                    </p>
                    {activity.description && (
                      <p className="text-gray-700 mt-2 text-sm break-words">{activity.description}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResumePreview;