import React from 'react';
import { FiX, FiChevronDown } from 'react-icons/fi';

const FilterSidebar = ({ filters, onFilterChange }) => {
  const jobTypes = [
    'Full-time',
    'Part-time',
    'Contract',
    'Freelance',
    'Internship'
  ];

  const experienceLevels = [
    'Entry',
    'Mid',
    'Senior',
    'Executive'
  ];

  const salaryRanges = [
    'Any',
    '0 - 10,000',
    '10,000 - 50,000',
    '50,000 - 1,00,000',
    '1,00,000 - 3,00,000',
    '3,00,000 - 5,00,000',
    '5,00,000 - 10,00,000',
    '10,00,000 - 20,00,000',
    '20,00,000 - 30,00,000',
    '30,00,000+'
  ];

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 sticky top-8">
      <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-100">
        <h3 className="text-xl font-bold text-gray-900">Filters</h3>
        <button className="text-gray-400 hover:text-gray-600 transition-colors duration-300">
          <FiX className="h-5 w-5" />
        </button>
      </div>

      {/* Job Type Filter */}
      <div className="mb-6">
        <h4 className="font-bold text-gray-900 mb-4 flex items-center justify-between text-lg">
          Job Type
          <FiChevronDown className="h-5 w-5 text-gray-500" />
        </h4>
        <div className="space-y-3">
          {jobTypes.map((type, index) => (
            <div key={index} className="flex items-center group">
              <input
                id={`type-${index}`}
                name="job-type"
                type="radio"
                className="h-5 w-5 text-primary-600 focus:ring-primary-500"
                checked={filters.jobType === type}
                onChange={() => onFilterChange('jobType', type)}
              />
              <label htmlFor={`type-${index}`} className="ml-3 text-gray-700 font-medium group-hover:text-primary-600 transition-colors duration-300 cursor-pointer">
                {type}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Experience Level Filter */}
      <div className="mb-6">
        <h4 className="font-bold text-gray-900 mb-4 flex items-center justify-between text-lg">
          Experience Level
          <FiChevronDown className="h-5 w-5 text-gray-500" />
        </h4>
        <div className="space-y-3">
          {experienceLevels.map((level, index) => (
            <div key={index} className="flex items-center group">
              <input
                id={`exp-${index}`}
                name="experience"
                type="radio"
                className="h-5 w-5 text-primary-600 focus:ring-primary-500"
                checked={filters.experience === level}
                onChange={() => onFilterChange('experience', level)}
              />
              <label htmlFor={`exp-${index}`} className="ml-3 text-gray-700 font-medium group-hover:text-primary-600 transition-colors duration-300 cursor-pointer">
                {level}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Salary Range Filter */}
      <div className="mb-8">
        <h4 className="font-bold text-gray-900 mb-4 flex items-center justify-between text-lg">
          Salary Range
          <FiChevronDown className="h-5 w-5 text-gray-500" />
        </h4>
        <div className="space-y-3">
          {salaryRanges.map((range, index) => (
            <div key={index} className="flex items-center group">
              <input
                id={`salary-${index}`}
                name="salary"
                type="radio"
                className="h-5 w-5 text-primary-600 focus:ring-primary-500"
                checked={filters.salary === range}
                onChange={() => onFilterChange('salary', range)}
              />
              <label htmlFor={`salary-${index}`} className="ml-3 text-gray-700 font-medium group-hover:text-primary-600 transition-colors duration-300 cursor-pointer">
                {range}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Reset Filters Button */}
      <button 
        className="w-full bg-gradient-to-r from-gray-100 to-gray-200 hover:from-gray-200 hover:to-gray-300 text-gray-700 font-medium py-3 rounded-xl transition-all duration-300 shadow-md hover:shadow-lg"
        onClick={() => {
          onFilterChange('jobType', '');
          onFilterChange('experience', '');
          onFilterChange('salary', '');
        }}
      >
        Reset Filters
      </button>
    </div>
  );
};

export default FilterSidebar;