import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import SharedDashboardLayout from './SharedDashboardLayout';

const EmployerRouteWrapper = ({ children }) => {
  const { user } = useAuth();

  // Only wrap with dashboard layout if the user is an employer or jobseeker
  if (user && (user.role === 'employer' || user.role === 'jobseeker')) {
    return <SharedDashboardLayout>{children}</SharedDashboardLayout>;
  }
  
  // For other users, render children directly
  return children;
};

export default EmployerRouteWrapper;