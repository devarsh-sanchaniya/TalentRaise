import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FiFacebook, FiTwitter, FiLinkedin, FiInstagram, FiMail, FiPhone, FiMapPin } from 'react-icons/fi';

const Footer = () => {
  const navigate = useNavigate();

  const handleAdminClick = (e) => {
    e.preventDefault();
    navigate('/admin/login');
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="w-full py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-2xl font-bold text-gradient mb-4">Talent<span className="text-primary-400">Raise</span></h3>
            <p className="text-gray-400 mb-4">
              Connecting talented professionals with top companies across India. Find your dream job or the perfect candidate.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                <FiFacebook className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                <FiTwitter className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                <FiLinkedin className="h-6 w-6" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition duration-300">
                <FiInstagram className="h-6 w-6" />
              </a>
            </div>
          </div>

          {/* For Job Seekers */}
          <div>
            <h3 className="text-lg font-semibold mb-4">For Job Seekers</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/jobs" className="text-gray-400 hover:text-white transition duration-300">
                  Browse Jobs
                </Link>
              </li>
              <li>
                <Link to="/companies" className="text-gray-400 hover:text-white transition duration-300">
                  Browse Companies
                </Link>
              </li>
              <li>
                <Link to="/job-alerts" className="text-gray-400 hover:text-white transition duration-300">
                  Job Alerts
                </Link>
              </li>
              <li>
                <Link to="/resume-builder" className="text-gray-400 hover:text-white transition duration-300">
                  Resume Builder
                </Link>
              </li>
              <li>
                <Link to="/career-advice" className="text-gray-400 hover:text-white transition duration-300">
                  Career Advice
                </Link>
              </li>
            </ul>
          </div>

          {/* For Employers */}
          <div>
            <h3 className="text-lg font-semibold mb-4">For Employers</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/post-job" className="text-gray-400 hover:text-white transition duration-300">
                  Post a Job
                </Link>
              </li>
              <li>
                <Link to="/browse-resumes" className="text-gray-400 hover:text-white transition duration-300">
                  Browse Resumes
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="text-gray-400 hover:text-white transition duration-300">
                  Pricing Plans
                </Link>
              </li>
              <li>
                <Link to="/employer-resources" className="text-gray-400 hover:text-white transition duration-300">
                  Employer Resources
                </Link>
              </li>
              <li>
                <Link to="/hire-advice" className="text-gray-400 hover:text-white transition duration-300">
                  Hiring Advice
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <FiMapPin className="h-5 w-5 text-primary-400 mt-1 mr-3 flex-shrink-0" />
                <span className="text-gray-400">123 Business Avenue, Suite 100<br />Mumbai, Maharashtra 400001</span>
              </li>
              <li className="flex items-center">
                <FiPhone className="h-5 w-5 text-primary-400 mr-3 flex-shrink-0" />
                <span className="text-gray-400">+91 98765 43210</span>
              </li>
              <li className="flex items-center">
                <FiMail className="h-5 w-5 text-primary-400 mr-3 flex-shrink-0" />
                <span className="text-gray-400">support@talentraise.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 text-center">
          <p className="text-gray-400">
            <button 
              onClick={handleAdminClick}
              className="hover:text-white focus:outline-none"
              title="Admin Access"
            >
              &copy; {new Date().getFullYear()} TalentRaise. All rights reserved.
            </button>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;