import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiUser, FiBriefcase, FiMenu, FiX, FiLogOut, FiMail } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';
import { messagesAPI } from '../services/api';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [messageCount, setMessageCount] = useState(0);
  const { user, logout } = useAuth();
  const isAuthenticated = !!user;

  // Fetch message count when user is authenticated
  useEffect(() => {
    const fetchMessageCount = async () => {
      if (isAuthenticated && user?.role !== 'admin') {
        try {
          const response = await messagesAPI.getUserMessageCount();
          setMessageCount(response.data?.count || 0);
        } catch (error) {
          console.error('Error fetching message count:', error);
        }
      }
    };

    fetchMessageCount();
    
    // Set up interval to periodically update message count
    const interval = setInterval(fetchMessageCount, 30000); // Update every 30 seconds
    
    return () => clearInterval(interval);
  }, [isAuthenticated, user]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleLogout = async () => {
    await logout();
  };

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <Link to="/" className="text-2xl font-bold text-gradient">
              Talent<span className="text-primary-600">Raise</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:ml-6 md:flex md:items-center md:space-x-8">
            <Link to="/" className="text-gray-700 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-bold transition duration-300">
              Home
            </Link>
            <Link to="/jobs" className="text-gray-700 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-bold transition duration-300">
              Find Jobs
            </Link>
            <Link to="/faq" className="text-gray-700 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-bold transition duration-300">
              FAQ
            </Link>
            {/* Companies link removed as per user request */}
            <Link to="/about" className="text-gray-700 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-bold transition duration-300">
              About
            </Link>
            <Link to="/contact" className="text-gray-700 hover:text-primary-600 px-3 py-2 rounded-md text-sm font-bold transition duration-300">
              Contact
            </Link>
          </div>

          {/* User Actions */}
          <div className="hidden md:flex md:items-center md:space-x-4">
            {isAuthenticated ? (
              <>
                <div className="relative group">
                  <button className="flex items-center space-x-2 focus:outline-none">
                    {user.profile?.avatar ? (
                      <img 
                        src={`http://localhost:5000${user.profile.avatar}`} 
                        alt={user.name} 
                        className="w-10 h-10 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                        <FiUser className="h-6 w-6 text-gray-600" />
                      </div>
                    )}
                  </button>
                  
                  {/* Dropdown menu */}
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 z-50">
                    <Link 
                      to="/dashboard" 
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Dashboard
                    </Link>
                    <Link 
                      to="/profile" 
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      Profile
                    </Link>
                    <Link 
                      to="/messages" 
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex justify-between items-center"
                    >
                      <span>Messages</span>
                      {messageCount > 0 && (
                        <span className="inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white bg-red-500 rounded-full">
                          {messageCount}
                        </span>
                      )}
                    </Link>
                    <button 
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                    >
                      <div className="flex items-center">
                        <FiLogOut className="mr-2" />
                        Logout
                      </div>
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-primary">
                  Login
                </Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="-mr-2 flex items-center md:hidden">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-600 hover:text-primary-600 focus:outline-none"
            >
              {isMenuOpen ? (
                <FiX className="block h-6 w-6" />
              ) : (
                <FiMenu className="block h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link
              to="/"
              className="block px-4 py-2 text-base font-bold text-gray-700 hover:text-primary-600 hover:bg-gray-50"
              onClick={toggleMenu}
            >
              Home
            </Link>
            <Link
              to="/jobs"
              className="block px-4 py-2 text-base font-bold text-gray-700 hover:text-primary-600 hover:bg-gray-50"
              onClick={toggleMenu}
            >
              Find Jobs
            </Link>
            <Link
              to="/faq"
              className="block px-4 py-2 text-base font-bold text-gray-700 hover:text-primary-600 hover:bg-gray-50"
              onClick={toggleMenu}
            >
              FAQ
            </Link>
            {/* Companies link removed as per user request */}
            <Link
              to="/about"
              className="block px-4 py-2 text-base font-bold text-gray-700 hover:text-primary-600 hover:bg-gray-50"
              onClick={toggleMenu}
            >
              About
            </Link>
            <Link
              to="/contact"
              className="block px-4 py-2 text-base font-bold text-gray-700 hover:text-primary-600 hover:bg-gray-50"
              onClick={toggleMenu}
            >
              Contact
            </Link>
            
            {isAuthenticated ? (
              <div className="px-4 py-2 space-y-2 border-t border-gray-200 pt-4">
                <div className="flex items-center space-x-3 mb-4">
                  {user.profile?.avatar ? (
                    <img 
                      src={`http://localhost:5000${user.profile.avatar}`} 
                      alt={user.name} 
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                      <FiUser className="h-6 w-6 text-gray-600" />
                    </div>
                  )}
                  <div>
                    <p className="text-sm font-medium text-gray-900">{user.name}</p>
                    <p className="text-xs text-gray-500">{user.role === 'employer' ? 'Employer' : 'Job Seeker'}</p>
                  </div>
                </div>
                <Link
                  to="/dashboard"
                  className="block w-full text-center px-4 py-2 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-primary-600 hover:bg-primary-700"
                  onClick={toggleMenu}
                >
                  Dashboard
                </Link>
                <Link
                  to="/profile"
                  className="block w-full text-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-base font-medium text-primary-600 bg-white hover:bg-gray-50"
                  onClick={toggleMenu}
                >
                  Profile
                </Link>
                <Link
                  to="/messages"
                  className="block w-full text-center px-4 py-2 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-primary-600 hover:bg-primary-700 flex justify-between items-center"
                  onClick={toggleMenu}
                >
                  <span>Messages</span>
                  {messageCount > 0 && (
                    <span className="inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white bg-red-500 rounded-full">
                      {messageCount}
                    </span>
                  )}
                </Link>
                <button
                  onClick={async () => { await handleLogout(); toggleMenu(); }}
                  className="block w-full text-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-base font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  <div className="flex items-center justify-center">
                    <FiLogOut className="mr-2" />
                    Logout
                  </div>
                </button>
              </div>
            ) : (
              <div className="px-4 py-2 space-y-2">
                <Link
                  to="/login"
                  className="block w-full text-center px-4 py-2 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-primary-600 hover:bg-primary-700"
                  onClick={toggleMenu}
                >
                  Login
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;