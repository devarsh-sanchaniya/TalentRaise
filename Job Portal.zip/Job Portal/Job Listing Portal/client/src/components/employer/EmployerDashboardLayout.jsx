import React, { useState, useEffect } from 'react';
import { FiBarChart2, FiUser, FiBriefcase, FiFileText, FiMail, FiLogOut } from 'react-icons/fi';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { authAPI } from '../../services/api';

const EmployerDashboardLayout = ({ children }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isAuthenticated, setIsAuthenticated] = useState(null); // null means checking

  // Check if user is an employer
  useEffect(() => {
    if (user && user.role !== 'employer') {
      // If user is not an employer, redirect to home
      navigate('/');
    } else {
      setIsAuthenticated(!!user);
    }
  }, [user, navigate]);

  const handleLogout = async () => {
    try {
      // Call the logout API
      await authAPI.logout();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // Perform logout and redirect
      logout(); // This clears user context
      navigate('/'); // Redirect to home page
    }
  };

  const navItems = [
    { name: 'Dashboard', icon: <FiBarChart2 className="h-5 w-5" />, path: '/dashboard' },
    { name: 'Profile', icon: <FiUser className="h-5 w-5" />, path: '/profile' },
    { name: 'Post Job', icon: <FiBriefcase className="h-5 w-5" />, path: '/post-job' },
    { name: 'View Applications', icon: <FiFileText className="h-5 w-5" />, path: '/applications' },
    { name: 'Messages', icon: <FiMail className="h-5 w-5" />, path: '/messages' }
  ];

  // If still checking authentication, show loading
  if (isAuthenticated === null) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  // If not authenticated or not an employer, redirect to home
  if (!isAuthenticated || !user || user.role !== 'employer') {
    navigate('/');
    return null;
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Static sidebar for desktop */}
      <div className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0">
        <div className="flex-1 flex flex-col min-h-0 border-r border-gray-200 bg-white">
          <div className="flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
            {/* User profile section */}
            <div className="flex items-center flex-shrink-0 px-4 mb-5">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center mr-3">
                {user?.profile?.avatar ? (
                  <img 
                    src={`http://localhost:5000${user.profile.avatar}`} 
                    alt={user.name} 
                    className="w-full h-full object-cover rounded-full" 
                  />
                ) : (
                  <FiUser className="h-6 w-6 text-blue-600" />
                )}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900 truncate">{user?.name || 'Employer'}</p>
                <p className="text-xs text-gray-500 truncate">Employer</p>
              </div>
            </div>
            
            <nav className="mt-2 flex-1 px-2 bg-white space-y-1">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`${location.pathname === item.path 
                    ? 'bg-gray-100 text-gray-900' 
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'} 
                    group flex items-center px-2 py-2 text-sm font-medium rounded-md`}
                >
                  {item.icon}
                  <span className="ml-3">{item.name}</span>
                </Link>
              ))}
            </nav>
          </div>
          <div className="flex-shrink-0 flex border-t border-gray-200 p-4">
            <button
              onClick={handleLogout}
              className="flex-shrink-0 w-full group block"
            >
              <div className="flex items-center">
                <FiLogOut className="h-5 w-5 text-gray-400" />
                <span className="ml-3 text-sm font-medium text-gray-700">Logout</span>
              </div>
            </button>
          </div>
        </div>
      </div>

      <div className="md:pl-64 flex flex-col flex-1">
        <main className="flex-1">
          {children}
        </main>
      </div>
    </div>
  );
};

export default EmployerDashboardLayout;