import React, { useState, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { validateAdminAuth } from '../../utils/adminAuth';

const ProtectedAdminRoute = ({ children }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const validateAuth = async () => {
      try {
        const isValid = await validateAdminAuth();
        setIsAuthenticated(isValid);
      } catch (error) {
        console.error('Authentication validation error:', error);
        setIsAuthenticated(false);
      } finally {
        setIsLoading(false);
      }
    };

    validateAuth();
  }, []);

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  // If admin is not authenticated, redirect to admin login
  if (!isAuthenticated) {
    return <Navigate to="/admin/login" replace />;
  }

  // If admin is authenticated, render the children
  return children;
};

export default ProtectedAdminRoute;