import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { FiMenu, FiX, FiHome, FiBriefcase, FiUsers, FiFileText, FiEdit, FiMessageSquare, FiLogOut, FiUser } from 'react-icons/fi';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const SharedDashboardLayout = ({ children }) => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Close sidebar when route changes
  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: <FiHome className="w-5 h-5" /> },
    { name: 'Post Job', path: '/post-job', icon: <FiBriefcase className="w-5 h-5" /> },
    { name: 'My Jobs', path: '/my-jobs', icon: <FiEdit className="w-5 h-5" /> },
    { name: 'All Applications', path: '/all-applications', icon: <FiFileText className="w-5 h-5" /> },
    { name: 'Messages', path: '/messages', icon: <FiMessageSquare className="w-5 h-5" /> },
    { name: 'Profile', path: '/profile', icon: <FiUser className="w-5 h-5" /> },
  ];

  // Filter navigation items based on user role
  const filteredNavItems = user?.role === 'employer' ? navItems : 
    user?.role === 'jobseeker' ? [
      { name: 'Dashboard', path: '/dashboard', icon: <FiHome className="w-5 h-5" /> },
      { name: 'Messages', path: '/messages', icon: <FiMessageSquare className="w-5 h-5" /> },
      { name: 'Profile', path: '/profile', icon: <FiUser className="w-5 h-5" /> },
    ] : navItems.filter(item => 
      item.path === '/dashboard' || item.path === '/profile' || item.path === '/messages'
    );

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Mobile sidebar toggle button */}
      <button
        className="md:hidden fixed top-4 left-4 z-50 p-2 rounded-md bg-white shadow-md text-gray-600"
        onClick={() => setSidebarOpen(!sidebarOpen)}
      >
        {sidebarOpen ? <FiX className="w-6 h-6" /> : <FiMenu className="w-6 h-6" />}
      </button>

      {/* Sidebar */}
      <div 
        className={`fixed md:relative z-40 transform ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        } md:translate-x-0 w-64 h-full bg-white shadow-lg transition-transform duration-300 ease-in-out`}
      >
        {/* Sidebar Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center overflow-hidden">
              {user?.profile?.avatar ? (
                <img 
                  src={`http://localhost:5000${user.profile.avatar}`} 
                  alt={user.name} 
                  className="w-full h-full object-cover rounded-full" 
                />
              ) : (
                <FiUser className="h-6 w-6 text-blue-600" />
              )}
            </div>
            <div>
              <h3 className="font-bold text-gray-900 truncate">{user?.name || 'User'}</h3>
              <p className="text-sm text-gray-600 capitalize">{user?.role || 'Account'} Account</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4">
          <ul className="space-y-2">
            {filteredNavItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center px-4 py-3 rounded-lg transition-colors duration-200 ${
                    location.pathname === item.path
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                  onClick={() => setSidebarOpen(false)}
                >
                  <span className="mr-3">{item.icon}</span>
                  <span className="font-medium">{item.name}</span>
                </Link>
              </li>
            ))}
            <li>
              <button
                onClick={handleLogout}
                className="w-full flex items-center px-4 py-3 rounded-lg text-red-600 hover:bg-red-50 transition-colors duration-200"
              >
                <FiLogOut className="w-5 h-5 mr-3" />
                <span className="font-medium">Logout</span>
              </button>
            </li>
          </ul>
        </nav>
      </div>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden"
          onClick={() => setSidebarOpen(false)}
        ></div>
      )}

      {/* Main content */}
      <div className="flex-1 overflow-auto">
        <div className="p-6">
          {children}
        </div>
      </div>
    </div>
  );
};

export default SharedDashboardLayout;