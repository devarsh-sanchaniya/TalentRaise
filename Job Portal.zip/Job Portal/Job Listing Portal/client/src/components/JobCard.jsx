import React from 'react';
import { Link } from 'react-router-dom';
import { FiMapPin, FiClock, FiBriefcase, FiChevronRight } from 'react-icons/fi';

const JobCard = ({ job, viewMode }) => {
  // Format the posted date to show relative time
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffMinutes < 60) {
      return `${diffMinutes} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else if (diffDays === 1) {
      return '1 day ago';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      const weeks = Math.floor(diffDays / 7);
      return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
    } else {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months > 1 ? 's' : ''} ago`;
    }
  };

  if (viewMode === 'list') {
    return (
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden flex flex-col md:flex-row border border-gray-100 hover:shadow-xl transition-all duration-300">
        <div className="md:w-1/4 p-6 flex items-center">
          <div className="w-16 h-16 rounded-xl bg-white flex items-center justify-center shadow-md border border-gray-200">
            {job.companyLogo ? (
              <img 
                src={`http://localhost:5000${job.companyLogo}`} 
                alt={`${job.company?.company?.name || job.company?.name || 'Company'} logo`} 
                className="w-10 h-10 object-contain rounded-md"
              />
            ) : (
              <FiBriefcase className="h-8 w-8 text-primary-600" />
            )}
          </div>
          <div className="ml-4">
            <h3 className="font-bold text-xl text-gray-900">{job.title}</h3>
            <p className="text-gray-600 font-medium">{job.company?.company?.name || job.company?.name || 'Company Name'}</p>
          </div>
        </div>
        
        <div className="md:w-1/2 p-6 border-l border-gray-100">
          <div className="flex flex-wrap gap-3 mb-4">
            <span className="bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800 text-sm font-medium px-3 py-1.5 rounded-full">
              {job.employmentType}
            </span>
            <span className="bg-gradient-to-r from-green-100 to-green-200 text-green-800 text-sm font-medium px-3 py-1.5 rounded-full">
              {job.formattedSalary || 'Not specified'}
            </span>
            <span className="bg-gradient-to-r from-purple-100 to-purple-200 text-purple-800 text-sm font-medium px-3 py-1.5 rounded-full">
              {job.experienceLevel}
            </span>
          </div>
          
          <div className="flex flex-wrap gap-5 text-gray-600 mb-4">
            <div className="flex items-center">
              <FiMapPin className="mr-2" />
              <span className="font-medium">{job.location}</span>
            </div>
            <div className="flex items-center">
              <FiClock className="mr-2" />
              <span className="font-medium">{formatDate(job.createdAt)}</span>
            </div>
          </div>
          
          <p className="text-gray-600 mb-4 leading-relaxed">{job.description?.substring(0, 120)}...</p>
          
          <div className="flex flex-wrap gap-2">
            {job.skills?.slice(0, 4).map((skill, index) => (
              <span key={index} className="bg-gray-100 text-gray-800 text-sm font-medium px-3 py-1 rounded-full">
                {skill}
              </span>
            ))}
            {job.skills?.length > 4 && (
              <span className="bg-gray-100 text-gray-800 text-sm font-medium px-3 py-1 rounded-full">
                +{job.skills.length - 4} more
              </span>
            )}
          </div>
        </div>
        
        <div className="md:w-1/4 p-6 border-l border-gray-100 flex flex-col justify-between bg-gray-50">
          <div>
            <Link to={`/jobs/${job._id}`} className="bg-gradient-to-r from-primary-600 to-secondary-600 hover:from-primary-700 hover:to-secondary-700 text-white font-medium w-full text-center py-3.5 rounded-xl transition-all duration-300 shadow-md transform hover:scale-[1.02] flex items-center justify-center">
              View Details <FiBriefcase className="ml-2" />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-lg overflow-hidden h-full flex flex-col border border-gray-100 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
      <div className="p-7">
        <div className="flex items-start mb-5">
          <div className="w-14 h-14 rounded-xl bg-white flex items-center justify-center shadow-md border border-gray-200">
            {job.companyLogo ? (
              <img 
                src={`http://localhost:5000${job.companyLogo}`} 
                alt={`${job.company?.company?.name || job.company?.name || 'Company'} logo`} 
                className="w-8 h-8 object-contain rounded-md"
              />
            ) : (
              <FiBriefcase className="h-7 w-7 text-primary-600" />
            )}
          </div>
          <div className="ml-4">
            <h3 className="font-bold text-xl text-gray-900">{job.title}</h3>
            <p className="text-gray-600 font-medium">{job.company?.company?.name || job.company?.name || 'Company Name'}</p>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3 mb-5">
          <span className="bg-gradient-to-r from-blue-100 to-blue-200 text-blue-800 text-sm font-medium px-3 py-1.5 rounded-full">
            {job.employmentType}
          </span>
          <span className="bg-gradient-to-r from-green-100 to-green-200 text-green-800 text-sm font-medium px-3 py-1.5 rounded-full">
            {job.formattedSalary || 'Not specified'}
          </span>
          <span className="bg-gradient-to-r from-purple-100 to-purple-200 text-purple-800 text-sm font-medium px-3 py-1.5 rounded-full">
            {job.experienceLevel}
          </span>
        </div>
        
        <div className="space-y-3 text-gray-600 mb-5">
          <div className="flex items-center">
            <FiMapPin className="mr-3 flex-shrink-0" />
            <span className="font-medium">{job.location}</span>
          </div>
          <div className="flex items-center">
            <FiClock className="mr-3 flex-shrink-0" />
            <span className="font-medium">{formatDate(job.createdAt)}</span>
          </div>
          <div className="flex items-center">
            <FiBriefcase className="mr-3 flex-shrink-0" />
            <span className="font-medium">{job.description?.substring(0, 80)}...</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-7">
          {job.skills?.slice(0, 3).map((skill, index) => (
            <span key={index} className="bg-gray-100 text-gray-800 text-sm font-medium px-3 py-1.5 rounded-full">
              {skill}
            </span>
          ))}
          {job.skills?.length > 3 && (
            <span className="bg-gray-100 text-gray-800 text-sm font-medium px-3 py-1.5 rounded-full">
              +{job.skills.length - 3} more
            </span>
          )}
        </div>
      </div>
      
      <div className="mt-auto p-7 pt-0">
        <Link to={`/jobs/${job._id}`} className="bg-gradient-to-r from-primary-600 to-secondary-600 hover:from-primary-700 hover:to-secondary-700 text-white font-medium w-full text-center py-3.5 rounded-xl transition-all duration-300 shadow-md transform hover:scale-[1.02] flex items-center justify-center">
          View Details <FiChevronRight className="ml-2" />
        </Link>
      </div>
    </div>
  );
};

export default JobCard;
