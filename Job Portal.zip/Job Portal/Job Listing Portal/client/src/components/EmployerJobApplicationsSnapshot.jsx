import React, { useState, useEffect } from 'react';
import { FaChartBar, FaEye, FaCheck, FaTimes, FaClock, FaSearch, FaFilter } from 'react-icons/fa';
import { applicationsAPI, jobsAPI } from '../services/api';

const EmployerJobApplicationsSnapshot = () => {
  const [applications, setApplications] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedJob, setSelectedJob] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch employer's jobs
        const jobsRes = await jobsAPI.getJobsByUser();
        const jobsData = jobsRes.data || [];
        setJobs(jobsData);
        
        // Fetch all applications for employer's jobs
        let allApplications = [];
        for (const job of jobsData) {
          try {
            const appRes = await applicationsAPI.getApplicationsByJob(job._id);
            const jobApplications = appRes.data.map(app => ({
              id: app._id,
              jobId: job._id,
              jobTitle: job.title,
              applicantName: app.applicant?.name || 'N/A',
              email: app.applicant?.email || 'N/A',
              appliedDate: app.createdAt,
              status: app.status,
              phone: app.applicant?.profile?.phone || 'N/A',
              location: app.applicant?.profile?.location || 'N/A',
              applicantId: app.applicant?._id,
              applicationId: app._id
            }));
            allApplications = [...allApplications, ...jobApplications];
          } catch (appErr) {
            console.error(`Error fetching applications for job ${job._id}:`, appErr);
          }
        }
        
        setApplications(allApplications);
        setError('');
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to load job applications data');
        // Still set empty arrays to render the component
        setApplications([]);
        setJobs([]);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);

  const filteredApplications = applications.filter(app => {
    const matchesJob = selectedJob === 'all' || app.jobId === selectedJob;
    const matchesSearch = app.applicantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.jobTitle.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesJob && matchesSearch;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'interview': return 'bg-yellow-100 text-yellow-800';
      case 'pending': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'accepted': return <FaCheck className="text-green-500" />;
      case 'rejected': return <FaTimes className="text-red-500" />;
      case 'interview': return <FaClock className="text-yellow-500" />;
      case 'pending': return <FaClock className="text-blue-500" />;
      default: return null;
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="animate-pulse flex flex-col space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-4 bg-gray-200 rounded w-1/4"></div>
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-100 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-gray-200 bg-gray-50">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
              <FaChartBar className="text-blue-600" />
              Job Applications Overview
            </h2>
            <p className="text-gray-600 text-sm mt-1">Monitor and manage all applications across your job postings</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3">
            {/* Search */}
            <div className="relative">
              <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search applicants, jobs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none w-full sm:w-64 transition-all duration-200"
              />
            </div>
            
            {/* Job Filter */}
            <div className="relative">
              <FaFilter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <select
                value={selectedJob}
                onChange={(e) => setSelectedJob(e.target.value)}
                className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none appearance-none bg-white w-full sm:w-48 transition-all duration-200"
              >
                <option value="all">All Jobs</option>
                {jobs.map(job => (
                  <option key={job._id} value={job._id}>{job.title}</option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 p-6 bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-5 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
          <div className="text-3xl font-bold mb-1">{applications.length}</div>
          <div className="text-sm opacity-90">Total Applications</div>
        </div>
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl p-5 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
          <div className="text-3xl font-bold mb-1">
            {applications.filter(a => a.status.toLowerCase() === 'accepted' || a.status.toLowerCase() === 'accept').length}
          </div>
          <div className="text-sm opacity-90">Accepted</div>
        </div>
        <div className="bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl p-5 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
          <div className="text-3xl font-bold mb-1">
            {applications.filter(a => a.status.toLowerCase() === 'interview').length}
          </div>
          <div className="text-sm opacity-90">In Interview</div>
        </div>
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl p-5 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
          <div className="text-3xl font-bold mb-1">{jobs.length}</div>
          <div className="text-sm opacity-90">Active Jobs</div>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200">
            <tr>
              <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Applicant</th>
              <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Job Applied</th>
              <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Contact</th>
              <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Location</th>
              <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Applied Date</th>
              <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredApplications.length > 0 ? (
              filteredApplications.map((app) => (
                <tr key={app.id} className="hover:bg-gray-50 transition-colors duration-200">
                  <td className="py-4 px-6">
                    <div className="font-semibold text-gray-900">{app.applicantName}</div>
                    <div className="text-sm text-gray-600 truncate max-w-xs">{app.email}</div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="font-medium text-gray-900 truncate max-w-xs">{app.jobTitle}</div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="text-sm text-gray-900 font-medium">{app.phone}</div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="text-sm text-gray-900">{app.location}</div>
                  </td>
                  <td className="py-4 px-6">
                    <div className="text-sm text-gray-900">{new Date(app.appliedDate).toLocaleDateString()}</div>
                  </td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold ${getStatusColor(app.status)}`}>
                      {getStatusIcon(app.status)}
                      <span className="ml-1.5 capitalize">{app.status}</span>
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" className="py-16 px-6 text-center text-gray-500">
                  <div className="flex flex-col items-center justify-center">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-6">
                      <FaChartBar className="w-8 h-8 text-gray-600" />
                    </div>
                    <p className="text-lg font-medium text-gray-900 mb-2">No applications found</p>
                    <p className="text-sm text-gray-600 max-w-md mx-auto">Try adjusting your search or filter criteria to find the applications you're looking for</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 bg-gray-50">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 text-sm text-gray-600">
          <div>
            Showing <span className="font-semibold text-gray-900">{filteredApplications.length}</span> of <span className="font-semibold text-gray-900">{applications.length}</span> applications
          </div>
          <div className="flex flex-wrap gap-3">
            <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
              <FaCheck className="w-3 h-3 mr-1.5" /> {applications.filter(a => a.status.toLowerCase() === 'accepted' || a.status.toLowerCase() === 'accept').length} Accepted
            </span>
            <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
              <FaClock className="w-3 h-3 mr-1.5" /> {applications.filter(a => a.status.toLowerCase() === 'interview').length} Interview
            </span>
            <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
              <FaClock className="w-3 h-3 mr-1.5" /> {applications.filter(a => a.status.toLowerCase() === 'pending').length} Pending
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployerJobApplicationsSnapshot;