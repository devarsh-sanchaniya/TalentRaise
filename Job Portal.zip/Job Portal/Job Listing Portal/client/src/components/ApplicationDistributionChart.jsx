import React, { useState, useEffect, useMemo } from 'react';
import { FiClock, FiEye, FiCheckCircle, FiXCircle } from 'react-icons/fi';

const ApplicationDistributionChart = ({ applications = [] }) => {
  // Calculate status distribution using useMemo to optimize calculations
  const distribution = useMemo(() => {
    const total = applications.length;
    
    if (total === 0) {
      return {
        pending: { count: 0, percentage: 0 },
        viewed: { count: 0, percentage: 0 },
        shortlisted: { count: 0, percentage: 0 },
        rejected: { count: 0, percentage: 0 },
        total: 0
      };
    }

    const pending = applications.filter(app => 
      app.status.toLowerCase() === 'pending'
    ).length;

    const viewed = applications.filter(app => 
      app.status.toLowerCase() === 'viewed' || 
      app.status.toLowerCase() === 'reviewed' ||
      app.status.toLowerCase() === 'seen'
    ).length;

    const shortlisted = applications.filter(app => 
      app.status.toLowerCase() === 'interview' || 
      app.status.toLowerCase() === 'shortlisted' ||
      app.status.toLowerCase() === 'selected' ||
      app.status.toLowerCase() === 'accepted'
    ).length;

    const rejected = applications.filter(app => 
      app.status.toLowerCase() === 'rejected' || 
      app.status.toLowerCase() === 'declined' ||
      app.status.toLowerCase() === 'not selected'
    ).length;

    return {
      pending: { 
        count: pending, 
        percentage: total > 0 ? Math.round((pending / total) * 100) : 0 
      },
      viewed: { 
        count: viewed, 
        percentage: total > 0 ? Math.round((viewed / total) * 100) : 0 
      },
      shortlisted: { 
        count: shortlisted, 
        percentage: total > 0 ? Math.round((shortlisted / total) * 100) : 0 
      },
      rejected: { 
        count: rejected, 
        percentage: total > 0 ? Math.round((rejected / total) * 100) : 0 
      },
      total
    };
  }, [applications]);

  // Colors for each status
  const statusColors = {
    pending: 'bg-blue-500',
    viewed: 'bg-yellow-500',
    shortlisted: 'bg-green-500',
    rejected: 'bg-red-500'
  };

  // Icons for each status
  const statusIcons = {
    pending: <FiClock className="w-5 h-5" />,
    viewed: <FiEye className="w-5 h-5" />,
    shortlisted: <FiCheckCircle className="w-5 h-5" />,
    rejected: <FiXCircle className="w-5 h-5" />
  };

  // Labels for each status
  const statusLabels = {
    pending: 'Pending',
    viewed: 'Viewed',
    shortlisted: 'Interview/Accepted',
    rejected: 'Rejected'
  };

  // Calculate angles for the pie chart
  const totalApplications = distribution.total;
  const pendingAngle = (distribution.pending.count / totalApplications) * 360;
  const viewedAngle = (distribution.viewed.count / totalApplications) * 360;
  const shortlistedAngle = (distribution.shortlisted.count / totalApplications) * 360;
  const rejectedAngle = (distribution.rejected.count / totalApplications) * 360;

  // Calculate cumulative angles for positioning
  const cumulativeAngles = {
    pending: 0,
    viewed: pendingAngle,
    shortlisted: pendingAngle + viewedAngle,
    rejected: pendingAngle + viewedAngle + shortlistedAngle
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-gray-800 flex items-center gap-2">
              <span className="w-3 h-3 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full"></span>
              Application Distribution
            </h2>
            <p className="text-gray-600 text-sm mt-1">Status breakdown of your applications</p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-gray-900">{distribution.total}</div>
            <div className="text-sm text-gray-600">Total Apps</div>
          </div>
        </div>
      </div>

      {/* Chart and Legend */}
      <div className="p-6">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Pie Chart */}
          <div className="flex-1 flex justify-center">
            <div className="relative w-48 h-48 sm:w-56 sm:h-56 md:w-64 md:h-64">
              {/* SVG Pie Chart */}
              <svg viewBox="0 0 200 200" className="w-full h-full">
                {/* Background circle */}
                <circle cx="100" cy="100" r="90" fill="#f3f4f6" />
                
                {/* Pending slice */}
                {distribution.pending.count > 0 && (
                  <path
                    d={`M100,100 L${100 + 90 * Math.cos(cumulativeAngles.pending * Math.PI / 180)},${100 + 90 * Math.sin(cumulativeAngles.pending * Math.PI / 180)} A90,90 0 ${pendingAngle > 180 ? 1 : 0},1 ${100 + 90 * Math.cos((cumulativeAngles.pending + pendingAngle) * Math.PI / 180)},${100 + 90 * Math.sin((cumulativeAngles.pending + pendingAngle) * Math.PI / 180)} Z`}
                    fill="#3B82F6" // blue-500
                  />
                )}
                
                {/* Viewed slice */}
                {distribution.viewed.count > 0 && (
                  <path
                    d={`M100,100 L${100 + 90 * Math.cos(cumulativeAngles.viewed * Math.PI / 180)},${100 + 90 * Math.sin(cumulativeAngles.viewed * Math.PI / 180)} A90,90 0 ${viewedAngle > 180 ? 1 : 0},1 ${100 + 90 * Math.cos((cumulativeAngles.viewed + viewedAngle) * Math.PI / 180)},${100 + 90 * Math.sin((cumulativeAngles.viewed + viewedAngle) * Math.PI / 180)} Z`}
                    fill="#EAB308" // yellow-500
                  />
                )}
                
                {/* Shortlisted slice */}
                {distribution.shortlisted.count > 0 && (
                  <path
                    d={`M100,100 L${100 + 90 * Math.cos(cumulativeAngles.shortlisted * Math.PI / 180)},${100 + 90 * Math.sin(cumulativeAngles.shortlisted * Math.PI / 180)} A90,90 0 ${shortlistedAngle > 180 ? 1 : 0},1 ${100 + 90 * Math.cos((cumulativeAngles.shortlisted + shortlistedAngle) * Math.PI / 180)},${100 + 90 * Math.sin((cumulativeAngles.shortlisted + shortlistedAngle) * Math.PI / 180)} Z`}
                    fill="#22C55E" // green-500
                  />
                )}
                
                {/* Rejected slice */}
                {distribution.rejected.count > 0 && (
                  <path
                    d={`M100,100 L${100 + 90 * Math.cos(cumulativeAngles.rejected * Math.PI / 180)},${100 + 90 * Math.sin(cumulativeAngles.rejected * Math.PI / 180)} A90,90 0 ${rejectedAngle > 180 ? 1 : 0},1 ${100 + 90 * Math.cos((cumulativeAngles.rejected + rejectedAngle) * Math.PI / 180)},${100 + 90 * Math.sin((cumulativeAngles.rejected + rejectedAngle) * Math.PI / 180)} Z`}
                    fill="#EF4444" // red-500
                  />
                )}
                
                {/* Center circle */}
                <circle cx="100" cy="100" r="50" fill="white" className="shadow-inner" />
                <text x="100" y="90" textAnchor="middle" className="text-lg font-bold fill-gray-900" fontSize="24">{distribution.total}</text>
                <text x="100" y="115" textAnchor="middle" className="text-xs fill-gray-600" fontSize="12">Apps</text>
              </svg>
            </div>
          </div>

          {/* Legend */}
          <div className="flex-1 min-w-[200px]">
            <div className="space-y-3">
              {Object.entries(distribution).filter(([key]) => key !== 'total').map(([status, data]) => (
                <div key={status} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`${statusColors[status]} w-4 h-4 rounded-full flex items-center justify-center text-white`}>
                      {statusIcons[status]}
                    </div>
                    <span className="font-medium text-gray-800">{statusLabels[status]}</span>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-gray-900">{data.count}</div>
                    <div className="text-sm text-gray-600">{data.percentage}%</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Status indicators */}
        <div className="mt-6 pt-6 border-t border-gray-100">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-xl font-bold text-blue-600">{distribution.pending.count}</div>
              <div className="text-sm text-blue-800 font-medium">Pending</div>
              <div className="text-xs text-blue-600 mt-1">{distribution.pending.percentage}%</div>
            </div>
            <div className="text-center p-4 bg-yellow-50 rounded-lg">
              <div className="text-xl font-bold text-yellow-600">{distribution.viewed.count}</div>
              <div className="text-sm text-yellow-800 font-medium">Viewed</div>
              <div className="text-xs text-yellow-600 mt-1">{distribution.viewed.percentage}%</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-xl font-bold text-green-600">{distribution.shortlisted.count}</div>
              <div className="text-sm text-green-800 font-medium">Shortlisted</div>
              <div className="text-xs text-green-600 mt-1">{distribution.shortlisted.percentage}%</div>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-xl font-bold text-red-600">{distribution.rejected.count}</div>
              <div className="text-sm text-red-800 font-medium">Rejected</div>
              <div className="text-xs text-red-600 mt-1">{distribution.rejected.percentage}%</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicationDistributionChart;