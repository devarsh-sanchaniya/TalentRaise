import axios from 'axios';

export const getGeminiResponse = async (message) => {
  try {
    console.log('Sending request to server:', `${process.env.REACT_APP_API_URL || 'http://localhost:5000'}/api/gemini/chat`);
    console.log('Message to send:', message);
    
    const response = await axios.post(`${process.env.REACT_APP_API_URL || 'http://localhost:5000'}/api/gemini/chat`, 
      { message },
      {
        headers: {
          'Content-Type': 'application/json',
        },
        timeout: 20000
      }
    );
    
    console.log('Received response from server:', response.data);
    
    return response.data.response;
  } catch (error) {
    console.error('Error calling Gemini API through server:', error);
    console.error('Error details:', {
      status: error.response?.status,
      data: error.response?.data,
      message: error.message,
      url: `${process.env.REACT_APP_API_URL || 'http://localhost:5000'}/api/gemini/chat`
    });
    
    // Return a helpful fallback message
    if (error.response?.status === 400) {
      return `I'm having trouble processing your request. ${error.response?.data?.error || 'Please try rephrasing your question.'}`;
    } else if (error.response?.status === 429) {
      return "I'm currently experiencing high demand. Please try again in a moment.";
    } else if (error.response?.status === 401 || error.response?.status === 403) {
      return "There seems to be an issue with my configuration. Please check the API key.";
    } else {
      return `Sorry, I'm unable to process your request right now: ${error.response?.data?.error || 'Please try again later.' }`;
    }
  }
};