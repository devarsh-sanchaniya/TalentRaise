import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:5000/api'
});

// Add auth token to requests if available
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Create a separate instance for authentication that doesn't automatically add auth headers
const AUTH_API = axios.create({
  baseURL: 'http://localhost:5000/api'
});

// Create a separate instance for admin authentication that doesn't automatically add auth headers
const ADMIN_AUTH_API = axios.create({
  baseURL: 'http://localhost:5000/api'
});

// Create a separate instance for admin API calls with admin token handling
const ADMIN_API = axios.create({
  baseURL: 'http://localhost:5000/api'
});

// Add admin auth token to requests if available
ADMIN_API.interceptors.request.use((config) => {
  const token = localStorage.getItem('adminToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Interceptor to handle admin token expiration
ADMIN_API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && (error.response.status === 401 || error.response.status === 403)) {
      // Clear admin auth if token is invalid
      localStorage.removeItem('adminToken');
      localStorage.removeItem('adminUser');
      localStorage.removeItem('isAdmin');
    }
    return Promise.reject(error);
  }
);

// Auth API functions
export const authAPI = {
  // Register user
  register: (userData) => AUTH_API.post('/auth/register', userData),
  
  // Login user
  login: (credentials) => AUTH_API.post('/auth/login', credentials),
  
  // Get user profile
  getProfile: () => API.get('/auth/profile'),
  
  // Update user profile
  updateProfile: (userData) => API.put('/auth/profile', userData),
  
  // Logout user
  logout: () => API.post('/auth/logout'),
  
  // Update company logo
  updateCompanyLogo: (logoData) => {
    const formData = new FormData();
    formData.append('logo', logoData);
    return API.put('/auth/company-logo', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    });
  },
  
  // Delete user profile
  deleteProfile: () => API.delete('/auth/profile')
};

// Admin Auth API functions (completely separate from user auth)
export const adminAuthAPI = {
  // Login admin (uses separate instance without user auth headers)
  login: (credentials) => ADMIN_AUTH_API.post('/auth/login', credentials),
  
  // Get admin profile (uses separate instance with admin token)
  getProfile: () => ADMIN_API.get('/auth/profile'),
  
  // Logout admin (uses separate instance with admin token)
  logout: () => ADMIN_API.post('/auth/logout')
};

// Jobs API functions
export const jobsAPI = {
  // Get all jobs
  getAllJobs: () => API.get('/jobs'),
  
  // Get jobs with filters
  getJobs: (params = {}) => {
    const queryParams = new URLSearchParams(params).toString();
    return API.get(`/jobs${queryParams ? `?${queryParams}` : ''}`);
  },
  
  // Get job by ID
  getJobById: (id) => API.get(`/jobs/${id}`),
  
  // Create job (Employer)
  createJob: (jobData) => API.post('/jobs', jobData),
  
  // Get jobs by user (Employer)
  getJobsByUser: () => API.get('/jobs/user'),
  
  // Update job (Employer)
  updateJob: (id, jobData) => API.put(`/jobs/${id}`, jobData),
  
  // Delete job (Employer)
  deleteJob: (id) => API.delete(`/jobs/${id}`),
  
  // Search jobs
  searchJobs: (query) => API.get(`/jobs/search?query=${query}`)
};

// Applications API functions
export const applicationsAPI = {
  // Apply for job (Job Seeker)
  applyForJob: (applicationData) => API.post('/applications', applicationData),
  
  // Get my applications (Job Seeker)
  getMyApplications: () => API.get('/applications/my-applications'),
  
  // Get applications by job (Employer)
  getApplicationsByJob: (jobId) => API.get(`/applications/job/${jobId}`),
  
  // Get application by ID (Employer)
  getApplicationById: (id) => API.get(`/applications/${id}`),
  
  // Update application status (Employer)
  updateApplicationStatus: (id, statusData) => API.put(`/applications/${id}`, statusData),
  
  // Delete application (Job Seeker)
  deleteApplication: (id) => API.delete(`/applications/${id}`),
  
  // Download applicant resume (Employer)
  downloadResume: (applicationId) => API.get(`/applications/${applicationId}/resume`, {
    responseType: 'blob'
  }),
  
  // Update user (Admin)
  updateUser: (id, userData) => API.put(`/applications/admin/${id}`, userData),
  
  // Update job (Admin)
  updateJob: (id, jobData) => API.put(`/applications/admin/jobs/${id}`, jobData),
  
  // Update application status (Admin) - Placeholder for future implementation
  updateApplicationStatusAdmin: (id, statusData) => API.put(`/applications/admin/${id}`, statusData)
};

// Admin API functions
export const adminAPI = {
  // Get admin stats
  getStats: () => ADMIN_API.get('/users/admin/stats'),
  
  // Get recent activities
  getRecentActivities: () => ADMIN_API.get('/users/admin/recent-activities'),
  
  // Get system reports
  getSystemReports: () => ADMIN_API.get('/users/admin/system-reports'),
  
  // Get all users (Admin)
  getAllUsers: () => ADMIN_API.get('/users'),
  
  // Get user by ID (Admin)
  getUserById: (id) => ADMIN_API.get(`/users/${id}`),
  
  // Update user (Admin)
  updateUser: (id, userData) => ADMIN_API.put(`/users/${id}`, userData),
  
  // Delete user (Admin)
  deleteUser: (id) => ADMIN_API.delete(`/users/${id}`),
  
  // Get all jobs (Admin)
  getAllJobs: () => ADMIN_API.get('/users/admin/jobs'),
  
  // Get job by ID (Admin)
  getJobById: (id) => ADMIN_API.get(`/users/admin/jobs/${id}`),
  
  // Update job (Admin)
  updateJob: (id, jobData) => ADMIN_API.put(`/users/admin/jobs/${id}`, jobData),
  
  // Delete job (Admin)
  deleteJob: (id) => ADMIN_API.delete(`/users/admin/jobs/${id}`),
  
  // Get all applications (Admin)
  getAllApplications: () => ADMIN_API.get('/applications/admin/all'),
  
  // Block/unblock user (Admin)
  blockUser: (id) => ADMIN_API.put(`/users/${id}/block`),
  
  // Approve company (Admin)
  approveCompany: (id) => ADMIN_API.put(`/users/${id}/approve-company`),
  
  // Get application by ID (Admin)
  getApplicationById: (id) => ADMIN_API.get(`/admin/applications/${id}`),
  
  // Update application status (Admin)
  updateApplicationStatus: (id, statusData) => ADMIN_API.put(`/admin/applications/${id}/status`, statusData),
  
  // Delete application (Admin)
  deleteApplication: (id) => ADMIN_API.delete(`/admin/applications/${id}`),
  
  // Download applicant resume (Admin)
  downloadResume: (applicationId) => ADMIN_API.get(`/admin/applications/${applicationId}/resume`, {
    responseType: 'blob'
  }),
  
  // Update user (Admin)
  updateUserAdmin: (id, userData) => ADMIN_API.put(`/users/${id}`, userData),
  
  // Update job (Admin)
  updateJobAdmin: (id, jobData) => ADMIN_API.put(`/users/admin/jobs/${id}`, jobData),
  
  // Update application status (Admin) - Placeholder for future implementation
  updateApplicationStatusAdminPlaceholder: (id, statusData) => ADMIN_API.put(`/applications/admin/${id}`, statusData)
};

// Messages API functions
export const messagesAPI = {
  // Send message to admin (Employer/Job Seeker)
  sendMessage: (messageData) => API.post('/messages', messageData),
  
  // Get messages for admin
  getAdminMessages: () => ADMIN_API.get('/messages/admin'),
  
  // Mark message as read (Admin)
  markMessageAsRead: (id) => ADMIN_API.put(`/messages/admin/${id}/read`),
  
  // Delete message (Admin)
  deleteMessage: (id) => ADMIN_API.delete(`/messages/admin/${id}`),
  
  // Get unread message count (Admin)
  getMessageCount: () => ADMIN_API.get('/messages/admin/count'),
  
  // Reply to message (Admin)
  replyToMessage: (id, messageData) => ADMIN_API.post(`/messages/admin/${id}/reply`, messageData),
  
  // Get messages for user
  getUserMessages: () => API.get('/messages/user'),
  
  // Delete user message
  deleteUserMessage: (id) => API.delete(`/messages/user/${id}`),
  
  // Mark user message as read
  markUserMessageAsRead: (id) => API.put(`/messages/user/${id}/read`),
  
  // Get unread message count for user
  getUserMessageCount: () => API.get('/messages/user/count')
};

export default API;