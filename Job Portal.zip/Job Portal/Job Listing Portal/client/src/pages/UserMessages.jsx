import React, { useState, useEffect } from 'react';
import { FiMail, FiUser, FiClock, FiCheckCircle, FiTrash2, FiArrowLeft, FiInbox, FiMessageSquare } from 'react-icons/fi';
import { messagesAPI } from '../services/api';
import { useNavigate } from 'react-router-dom';

const UserMessages = () => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedMessage, setSelectedMessage] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    try {
      setLoading(true);
      const response = await messagesAPI.getUserMessages();
      setMessages(response.data || []);
      setError('');
    } catch (err) {
      console.error('Error fetching messages:', err);
      setError(`Failed to fetch messages: ${err.response?.data?.message || err.message || 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (messageId) => {
    try {
      await messagesAPI.markUserMessageAsRead(messageId);
      setMessages(prev => prev.map(msg => 
        msg._id === messageId ? { ...msg, isRead: true } : msg
      ));
      
      // Update selected message if it's the one being marked as read
      if (selectedMessage && selectedMessage._id === messageId) {
        setSelectedMessage({ ...selectedMessage, isRead: true });
      }
    } catch (err) {
      console.error('Error marking message as read:', err);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }) + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Function to format message content with proper markdown parsing
  const formatMessageContent = (content) => {
    if (!content) return '';
    
    // Split content into lines
    const lines = content.split('\n');
    const formattedLines = [];
    
    lines.forEach(line => {
      if (line.startsWith('**From:**')) {
        // Format sender name line
        const name = line.replace('**From:**', '').trim();
        formattedLines.push(<div key={formattedLines.length} className="font-bold text-lg mb-1">From: <span className="text-blue-600">{name}</span></div>);
      } else if (line.startsWith('**Email:**')) {
        // Format email line
        const email = line.replace('**Email:**', '').trim();
        formattedLines.push(<div key={formattedLines.length} className="text-gray-700 mb-3">Email: <span className="font-medium">{email}</span></div>);
      } else if (line.startsWith('**Message:**')) {
        // Format message header
        formattedLines.push(<div key={formattedLines.length} className="font-semibold text-gray-900 mt-4 mb-2">Message:</div>);
      } else if (line.trim() !== '') {
        // Regular message content
        formattedLines.push(<div key={formattedLines.length} className="text-gray-800 mb-2">{line}</div>);
      } else {
        // Empty line for spacing
        formattedLines.push(<div key={formattedLines.length} className="h-1"></div>);
      }
    });
    
    return formattedLines;
  };

  const handleSelectMessage = (message) => {
    setSelectedMessage(message);
    // Mark as read when opening
    if (!message.isRead) {
      markAsRead(message._id);
    }
  };

  const handleBackToList = () => {
    setSelectedMessage(null);
  };

  const deleteMessage = async (messageId) => {
    if (!window.confirm('Are you sure you want to delete this message?')) {
      return;
    }
    
    try {
      await messagesAPI.deleteUserMessage(messageId);
      // Refresh the messages list
      fetchMessages();
      // If we're viewing the deleted message, go back to the list
      if (selectedMessage && selectedMessage._id === messageId) {
        handleBackToList();
      }
    } catch (err) {
      console.error('Error deleting message:', err);
      alert('Failed to delete message. Please try again.');
    }
  };

  // Helper function to safely access sender data
  const getSenderData = (message) => {
    if (!message.sender) {
      return {
        name: 'Admin',
        email: 'admin@talentraise.com',
        profile: null
      };
    }
    return message.sender;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-6">
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          {selectedMessage ? (
            // Detailed message view
            <div className="bg-white shadow rounded-lg overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <div className="flex items-center">
                  <button
                    onClick={handleBackToList}
                    className="mr-4 inline-flex items-center p-2 border border-transparent rounded-full shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    <FiArrowLeft className="h-5 w-5" />
                  </button>
                  <h1 className="text-2xl font-semibold text-gray-900">Message Details</h1>
                </div>
                <div className="flex space-x-2">
                  {!selectedMessage.isRead && (
                    <button
                      onClick={() => markAsRead(selectedMessage._id)}
                      className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <FiCheckCircle className="-ml-1 mr-1 h-4 w-4" />
                      Mark as Read
                    </button>
                  )}
                  <button
                    onClick={() => deleteMessage(selectedMessage._id)}
                    className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-red-700 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                  >
                    <FiTrash2 className="-ml-1 mr-1 h-4 w-4" />
                    Delete
                  </button>
                </div>
              </div>
              
              <div className="p-6">
                <div className="border-b border-gray-200 pb-6 mb-6">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      {getSenderData(selectedMessage).profile?.avatar ? (
                        <img
                          src={`http://localhost:5000${getSenderData(selectedMessage).profile.avatar}`}
                          alt={getSenderData(selectedMessage).name}
                          className="h-16 w-16 rounded-full object-cover"
                        />
                      ) : (
                        <div className="h-16 w-16 rounded-full bg-blue-100 flex items-center justify-center">
                          <FiUser className="h-8 w-8 text-blue-600" />
                        </div>
                      )}
                    </div>
                    <div className="ml-4 flex-1">
                      <div className="flex items-center justify-between">
                        <div>
                          <h2 className="text-xl font-bold text-gray-900">{getSenderData(selectedMessage).name}</h2>
                          <p className="text-gray-600 mt-1">{getSenderData(selectedMessage).email}</p>
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <FiClock className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                          <span>{formatDate(selectedMessage.createdAt)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Subject: {selectedMessage.subject}</h3>
                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                    <div className="text-gray-800 text-lg leading-relaxed whitespace-pre-line">
                      {formatMessageContent(selectedMessage.content)}
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <button
                    onClick={handleBackToList}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Back to Messages
                  </button>
                </div>
              </div>
            </div>
          ) : (
            // Message list view
            <div>
              <div className="flex items-center mb-6">
                <button
                  onClick={() => navigate(-1)}
                  className="mr-4 inline-flex items-center p-2 border border-transparent rounded-full shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  <FiArrowLeft className="h-5 w-5" />
                </button>
                <div className="flex items-center">
                  <FiInbox className="h-8 w-8 text-blue-600 mr-3" />
                  <h1 className="text-2xl font-semibold text-gray-900">Messages</h1>
                </div>
              </div>
              
              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-red-800">{error}</p>
                </div>
              )}
              
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
              ) : (
                <div className="bg-white shadow overflow-hidden sm:rounded-md">
                  <ul className="divide-y divide-gray-200">
                    {messages.length === 0 ? (
                      <li className="px-6 py-12 text-center">
                        <FiMessageSquare className="mx-auto h-12 w-12 text-gray-400" />
                        <h3 className="mt-2 text-lg font-medium text-gray-900">No messages</h3>
                        <p className="mt-1 text-gray-500">You don't have any messages yet.</p>
                      </li>
                    ) : (
                      messages.map((message) => (
                        <li 
                          key={message._id} 
                          className="transition-colors duration-200"
                        >
                          <div className="px-4 py-4 sm:px-6 flex items-center justify-between">
                            <div 
                              className={`${message.isRead ? 'bg-white hover:bg-gray-50' : 'bg-blue-50 hover:bg-blue-100'} flex items-center flex-1 cursor-pointer rounded-md p-2`}
                              onClick={() => handleSelectMessage(message)}
                            >
                              <div className="flex items-center">
                                <div className="flex-shrink-0">
                                  {getSenderData(message).profile?.avatar ? (
                                    <img
                                      src={`http://localhost:5000${getSenderData(message).profile.avatar}`}
                                      alt={getSenderData(message).name}
                                      className="h-10 w-10 rounded-full object-cover"
                                    />
                                  ) : (
                                    <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                      <FiUser className="h-5 w-5 text-blue-600" />
                                    </div>
                                  )}
                                </div>
                                <div className="ml-4">
                                  <div className="flex items-center">
                                    <p className="text-sm font-medium text-blue-600 truncate">
                                      {getSenderData(message).name}
                                    </p>
                                    {!message.isRead && (
                                      <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                        New
                                      </span>
                                    )}
                                  </div>
                                  <p className="text-sm text-gray-500">
                                    {getSenderData(message).email}
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-center text-sm text-gray-500">
                                <FiClock className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                                <span>{formatDate(message.createdAt)}</span>
                              </div>
                            </div>
                            <button
                              onClick={() => deleteMessage(message._id)}
                              className="ml-2 p-2 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-full"
                              title="Delete message"
                            >
                              <FiTrash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </li>
                      ))
                    )}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UserMessages;