import React, { useState, useEffect } from 'react';
import { FiSearch, FiFilter, FiGrid, FiList, FiMapPin, FiClock, FiBriefcase } from 'react-icons/fi';
import JobCard from '../components/JobCard';
import FilterSidebar from '../components/FilterSidebar';
import { jobsAPI } from '../services/api';

const JobList = () => {
  const [viewMode, setViewMode] = useState('grid');
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: '',
    location: '',
    jobType: '',
    experience: '',
    salary: ''
  });

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setLoading(true);
        
        // Build query parameters
        const params = {};
        if (filters.search) params.search = filters.search;
        if (filters.location) params.location = filters.location;
        if (filters.jobType) params.employmentType = filters.jobType;
        if (filters.experience) params.experienceLevel = filters.experience;
        if (filters.salary) params.salaryRange = filters.salary;
        
        const response = await jobsAPI.getJobs(params);
        setJobs(response.data.jobs);
      } catch (error) {
        console.error('Error fetching jobs:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, [filters]);

  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({
      ...prev,
      [filterName]: value
    }));
  };

  const filteredJobs = jobs.filter(job => {
    return (
      job.title.toLowerCase().includes(filters.search.toLowerCase()) ||
      job.company.name.toLowerCase().includes(filters.search.toLowerCase()) ||
      job.location.toLowerCase().includes(filters.search.toLowerCase())
    ) && 
    (filters.location ? job.location.toLowerCase().includes(filters.location.toLowerCase()) : true) &&
    (filters.jobType ? job.employmentType === filters.jobType : true) &&
    (filters.experience ? job.experienceLevel === filters.experience : true);
  });

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-3">Find Your Dream Job with TalentRaise</h1>
        <p className="text-xl text-gray-600">Browse through our carefully curated job listings</p>
      </div>

      {/* Search and Filters */}
      <div className="mb-8 bg-white rounded-2xl shadow-lg p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FiSearch className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Job title, keywords, or company"
              className="w-full px-4 py-3 text-gray-700 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent pl-10"
              value={filters.search}
              onChange={(e) => handleFilterChange('search', e.target.value)}
            />
          </div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FiMapPin className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Location"
              className="w-full md:w-64 px-4 py-3 text-gray-700 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent pl-10"
              value={filters.location}
              onChange={(e) => handleFilterChange('location', e.target.value)}
            />
          </div>
          <button className="bg-gradient-to-r from-primary-600 to-secondary-600 hover:from-primary-700 hover:to-secondary-700 text-white font-medium py-3 px-6 rounded-xl transition-all duration-300 flex items-center shadow-md">
            <FiFilter className="mr-2" /> Filter
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Fixed Sidebar */}
        <div className="lg:w-1/4 sticky top-8 h-fit">
          <FilterSidebar 
            filters={filters} 
            onFilterChange={handleFilterChange} 
          />
        </div>

        {/* Main Content */}
        <div className="lg:w-3/4">
          {/* Results Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 bg-white rounded-2xl shadow-lg p-6">
            <p className="text-gray-600 mb-4 md:mb-0 text-lg">
              Showing <span className="font-bold text-primary-600">{filteredJobs.length}</span> of <span className="font-bold text-primary-600">{jobs.length}</span> jobs
            </p>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <button 
                  className={`p-3 rounded-xl ${viewMode === 'grid' ? 'bg-primary-100 text-primary-600' : 'bg-gray-100 text-gray-600'} transition-all duration-300 hover:shadow-md`}
                  onClick={() => setViewMode('grid')}
                >
                  <FiGrid className="h-5 w-5" />
                </button>
                <button 
                  className={`p-3 rounded-xl ${viewMode === 'list' ? 'bg-primary-100 text-primary-600' : 'bg-gray-100 text-gray-600'} transition-all duration-300 hover:shadow-md`}
                  onClick={() => setViewMode('list')}
                >
                  <FiList className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Job Listings */}
          {loading ? (
            <div className="flex justify-center items-center h-96 bg-white rounded-2xl shadow-lg">
              <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary-600"></div>
            </div>
          ) : filteredJobs.length > 0 ? (
            <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 gap-6' : 'space-y-6'}>
              {filteredJobs.map(job => (
                <JobCard key={job._id} job={job} viewMode={viewMode} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-white rounded-2xl shadow-lg">
              <div className="text-gray-300 text-7xl mb-6">🔍</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">No jobs found</h3>
              <p className="text-gray-600 text-lg mb-6">Try adjusting your search or filter criteria</p>
              <button 
                className="bg-gradient-to-r from-primary-600 to-secondary-600 hover:from-primary-700 hover:to-secondary-700 text-white font-medium py-3 px-8 rounded-xl transition-all duration-300 shadow-md"
                onClick={() => {
                  handleFilterChange('search', '');
                  handleFilterChange('location', '');
                  handleFilterChange('jobType', '');
                  handleFilterChange('experience', '');
                  handleFilterChange('salary', '');
                }}
              >
                Reset All Filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobList;