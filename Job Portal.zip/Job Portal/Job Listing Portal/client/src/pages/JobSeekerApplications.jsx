import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { applicationsAPI } from '../services/api';
import { FiUser, FiDownload, FiMail, FiClock, FiCalendar, FiFileText, FiSearch, FiFilter, FiBriefcase, FiMapPin, FiTag } from 'react-icons/fi';

const JobSeekerApplications = () => {
  const { user } = useAuth();
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  // Format date as DD/MM/YYYY with zero-padding
  const formatAbsoluteDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  // Format the posted date to show relative time
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (diffMinutes < 60) {
      return `${diffMinutes} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else if (diffDays === 1) {
      return '1 day ago';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      const weeks = Math.floor(diffDays / 7);
      return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
    } else {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months > 1 ? 's' : ''} ago`;
    }
  };

  // Fetch applications
  useEffect(() => {
    const fetchApplications = async () => {
      try {
        setLoading(true);
        setError('');
        
        if (user?.role === 'jobseeker') {
          const res = await applicationsAPI.getMyApplications();
          setApplications(res.data || []);
        }
      } catch (err) {
        console.error('Error fetching applications:', err);
        setError('Failed to fetch applications');
        setApplications([]);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchApplications();
    }
  }, [user]);

  // Filter applications based on search term and status
  const filteredApplications = applications.filter(app => {
    const matchesSearch = searchTerm === '' ||
      app.job?.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.job?.company?.company?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.job?.company?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.status.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = filterStatus === 'all' || 
      app.status.toLowerCase() === filterStatus.toLowerCase();

    return matchesSearch && matchesStatus;
  });

  if (!user) {
    return null; // Will be redirected by protection logic
  }

  if (loading) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative mb-4">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">My Applications</h1>
        <p className="text-xl text-gray-600 mt-2">Track and manage your job applications</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-6">
        <div className="p-6 border-b border-gray-200">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FiSearch className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  className="focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                  placeholder="Search applications..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <FiFilter className="h-5 w-5 text-gray-400 mr-2" />
                <select
                  className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                >
                  <option value="all">All Statuses</option>
                  <option value="Pending">Pending</option>
                  <option value="Interview">Interview</option>
                  <option value="Accepted">Accepted</option>
                  <option value="Rejected">Rejected</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="p-6">
          {filteredApplications.length > 0 ? (
            <div className="space-y-6">
              {filteredApplications.map((application) => (
                <div key={application._id} className="p-6 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all duration-300">
                  <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-6">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start gap-4 mb-4">
                        <div className="flex-shrink-0 w-14 h-14 rounded-lg overflow-hidden bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                          {application.job?.company?.company?.logo ? (
                            <img 
                              src={`http://localhost:5000${application.job.company.company.logo}`} 
                              alt={application.job.company.company.name || 'Company'} 
                              className="w-full h-full object-cover" 
                            />
                          ) : (
                            <FiBriefcase className="h-7 w-7 text-blue-600" />
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <h4 className="font-bold text-lg text-gray-900 truncate">{application.job?.title || 'Job Title'}</h4>
                          <p className="text-gray-700 truncate">{application.job?.company?.company?.name || application.job?.company?.name || 'Company Name'}</p>
                          
                          {/* Job details */}
                          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mt-2">
                            {application.job?.location && (
                              <div className="flex items-center">
                                <FiMapPin className="h-4 w-4 mr-1 text-gray-400" />
                                <span>{application.job.location}</span>
                              </div>
                            )}
                            {application.job?.salaryMin && application.job?.salaryMax && (
                              <div className="flex items-center">
                                <FiTag className="h-4 w-4 mr-1 text-gray-400" />
                                <span>₹{application.job.salaryMin.toLocaleString()} - ₹{application.job.salaryMax.toLocaleString()}</span>
                              </div>
                            )}
                            <div className="flex items-center">
                              <FiCalendar className="h-4 w-4 mr-1 text-gray-400" />
                              <span>Applied {formatAbsoluteDate(application.createdAt)}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      {application.coverLetter && (
                        <div className="mt-4">
                          <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                            <FiFileText className="mr-2" /> Cover Letter Preview
                          </h5>
                          <p className="text-gray-700 text-sm bg-gray-50 p-4 rounded-lg border border-gray-200 leading-relaxed">
                            {application.coverLetter.substring(0, 150)}...
                            <span className="text-blue-600 font-medium cursor-pointer ml-1" onClick={() => alert(application.coverLetter)}>read more</span>
                          </p>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex flex-col items-end gap-4">
                      <span className={`px-4 py-1.5 text-sm font-medium rounded-full ${
                        application.status === 'Pending' 
                          ? 'bg-yellow-100 text-yellow-800' 
                          : application.status === 'Interview' 
                            ? 'bg-blue-100 text-blue-800' 
                            : application.status === 'Accepted' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                      }`}>
                        {application.status}
                      </span>
                      
                      <div className="flex flex-wrap gap-2">
                        <button
                          onClick={() => {
                            // Navigate to job details page
                            window.location.href = `/jobs/${application.job?._id}`;
                          }}
                          className="flex items-center text-sm bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-2 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 shadow-sm"
                        >
                          <FiBriefcase className="mr-1.5" /> View Job
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-6">
                <FiBriefcase className="h-8 w-8 text-gray-600" />
              </div>
              <h4 className="text-xl font-medium text-gray-900 mb-2">No Applications Submitted Yet</h4>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">Start applying to jobs that match your skills and experience to build your career</p>
              <a href="/jobs" className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-lg hover:from-blue-700 hover:to-indigo-700 transition duration-300 shadow-md">
                <FiBriefcase className="mr-2" /> Browse Available Jobs
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobSeekerApplications;