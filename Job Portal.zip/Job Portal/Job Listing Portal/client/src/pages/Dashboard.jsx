import React, { useState, useEffect } from 'react';
import { FiBriefcase, FiUsers, FiFileText, FiSettings, FiUser, FiCheck, FiX, FiEdit, FiTrash2, FiDownload, FiSearch, FiFilter, FiMapPin, FiTag, FiCalendar, FiClock } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate, useLocation } from 'react-router-dom';
import { applicationsAPI, jobsAPI } from '../services/api';
import EmployerJobApplicationsSnapshot from '../components/EmployerJobApplicationsSnapshot';

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [allApplications, setAllApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedJob, setSelectedJob] = useState(null);
  const [jobApplications, setJobApplications] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(Date.now());
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  // Format the posted date to show relative time
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffMinutes < 60) {
      return `${diffMinutes} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else if (diffDays === 1) {
      return '1 day ago';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      const weeks = Math.floor(diffDays / 7);
      return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
    } else {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months > 1 ? 's' : ''} ago`;
    }
  };

  // Format the posted date to show relative time (alias for formatDate)
  const formatRelativeDate = (dateString) => {
    return formatDate(dateString);
  };

  // Format date as DD/MM/YYYY with zero-padding
  const formatAbsoluteDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  // Redirect to home page if user is not authenticated
  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
  }, [user, navigate]);

  // Fetch jobs or applications based on user role
  const fetchData = async () => {
    try {
      setLoading(true);
      setError(''); // Clear any previous errors
      
      if (user?.role === 'employer') {
        // Fetch employer's posted jobs
        try {
          const res = await jobsAPI.getJobsByUser();
          // Ensure we're working with fresh data by creating a new array
          setJobs([...(res.data || [])]);
          
          // Fetch all applications for employer's jobs
          const allJobIds = res.data.map(job => job._id);
          let allApps = [];
          for (const jobId of allJobIds) {
            try {
              const appRes = await applicationsAPI.getApplicationsByJob(jobId);
              allApps = [...allApps, ...appRes.data];
            } catch (appErr) {
              console.error(`Error fetching applications for job ${jobId}:`, appErr);
            }
          }
          setAllApplications(allApps);
        } catch (err) {
          console.error('Error fetching jobs:', err);
          setError('Failed to fetch jobs');
          setJobs([]); // Clear jobs on error
        }
      } else if (user?.role === 'jobseeker') {
        // Fetch job seeker's applications
        try {
          const res = await applicationsAPI.getMyApplications();
          // Filter out any applications where the job no longer exists
          const validApplications = (res.data || []).filter(app => app.job !== null);
          // Ensure we're working with fresh data by creating a new array
          setApplications([...validApplications]);
        } catch (err) {
          console.error('Error fetching applications:', err);
          setError('Failed to fetch applications');
          setApplications([]); // Clear applications on error
        }
      }
    } catch (err) {
      setError('Failed to fetch data');
      console.error('Error:', err);
      // Clear data on general error
      if (user?.role === 'employer') {
        setJobs([]);
      } else if (user?.role === 'jobseeker') {
        setApplications([]);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user, lastUpdated]);

  // Refresh data when window gains focus (e.g., when returning from job posting)
  useEffect(() => {
    const handleFocus = () => {
      if (user) {
        setLastUpdated(Date.now()); // Force refresh by updating timestamp
      }
    };

    window.addEventListener('focus', handleFocus);
    
    return () => {
      window.removeEventListener('focus', handleFocus);
    };
  }, [user]);

  // Refresh data when location changes (e.g., when navigating back from job posting)
  useEffect(() => {
    if (user) {
      setLastUpdated(Date.now()); // Force refresh by updating timestamp
    }
  }, [user, location.key]);

  // Refresh data when page is shown (e.g., when using browser back/forward buttons)
  useEffect(() => {
    const handlePageShow = (event) => {
      // Only refresh if it's a browser navigation (forward/back)
      if (event.persisted || (performance && performance.navigation && performance.navigation.type === 2)) {
        if (user) {
          setLastUpdated(Date.now()); // Force refresh by updating timestamp
        }
      }
    };

    window.addEventListener('pageshow', handlePageShow);
    
    return () => {
      window.removeEventListener('pageshow', handlePageShow);
    };
  }, [user]);

  // Additional safeguard: Refresh data when component remounts
  useEffect(() => {
    if (user) {
      // Small delay to ensure proper refresh when coming back from browser navigation
      const timer = setTimeout(() => {
        fetchData();
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [user]);

  // Filter applications based on search term and status for job seekers
  const filteredApplications = applications.filter(app => {
    const matchesSearch = searchTerm === '' ||
      app.job?.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.job?.company?.company?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.job?.company?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.status.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = filterStatus === 'all' || 
      app.status.toLowerCase() === filterStatus.toLowerCase();

    return matchesSearch && matchesStatus;
  });

  // Fetch applications for a specific job (Employer)
  const fetchJobApplications = async (jobId) => {
    // Navigate to the dedicated job applications page
    navigate(`/job-applications/${jobId}`);
  };

  // Update application status (Employer)
  const updateApplicationStatus = async (applicationId, status) => {
    try {
      const res = await applicationsAPI.updateApplicationStatus(applicationId, { status });
      
      // Update the application in state
      setJobApplications(prev => 
        prev.map(app => 
          app._id === applicationId ? { ...app, status: res.data.status } : app
        )
      );
      
      // Update all applications state
      setAllApplications(prev => 
        prev.map(app => 
          app._id === applicationId ? { ...app, status: res.data.status } : app
        )
      );
      
      // Also update in the main applications list if needed
      setApplications(prev => 
        prev.map(app => 
          app._id === applicationId ? { ...app, status: res.data.status } : app
        )
      );
    } catch (err) {
      console.error('Error updating application status:', err);
      setError('Failed to update application status');
    }
  };

  // Download applicant resume (Employer)
  const downloadResume = async (applicationId, applicantName) => {
    try {
      const res = await applicationsAPI.downloadResume(applicationId);
      
      // Create a blob URL and trigger download
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `resume-${applicantName || 'applicant'}.pdf`);
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error downloading resume:', err);
      // Show more specific error message
      if (err.response && err.response.status === 404) {
        setError('Resume file not found. The file may have been deleted or moved.');
      } else if (err.response && err.response.status === 401) {
        setError('You are not authorized to download this resume.');
      } else {
        setError('Failed to download resume. Please try again.');
      }
    }
  };

  const handleEditJob = (jobId) => {
    navigate(`/edit-job/${jobId}`);
  };

  const handleDeleteJob = async (jobId) => {
    if (window.confirm('Are you sure you want to delete this job?')) {
      try {
        await jobsAPI.deleteJob(jobId);
        setJobs(jobs.filter(job => job._id !== jobId));
        alert('Job deleted successfully');
      } catch (err) {
        console.error('Error deleting job:', err);
        setError('Failed to delete job');
      }
    }
  };

  // Show loading state
  if (loading) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  // Redirect to home if not authenticated
  if (!user) {
    return null; // Will be redirected by the useEffect above
  }

  // Show error if any
  if (error) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative mb-4">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-10">
        <div className="border-b border-gray-200 pb-4">
          <h1 className="text-3xl font-bold text-gray-900">{user?.role === 'employer' ? 'Employer Dashboard' : 'Job Seeker Dashboard'}</h1>
          <p className="text-xl text-gray-600 mt-2">Welcome back, {user?.name || 'User'}! Here's what's happening with your account today.</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden transform hover:-translate-y-1">
          <div className="p-6">
            <div className="flex items-center">
              <div className="p-4 bg-white bg-opacity-20 backdrop-blur-sm rounded-xl">
                <FiBriefcase className="h-8 w-8 text-white" />
              </div>
              <div className="ml-5">
                <p className="text-base font-medium text-blue-100">Total Applications</p>
                <p className="text-3xl font-bold text-white">{user?.role === 'employer' ? jobs.length : applications.length}</p>
              </div>
            </div>
          </div>
          <div className="px-6 py-3 bg-white bg-opacity-10 text-white text-sm font-medium">
            {user?.role === 'employer' ? 'Posted by you' : 'Submitted by you'}
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden transform hover:-translate-y-1">
          <div className="p-6">
            <div className="flex items-center">
              <div className="p-4 bg-white bg-opacity-20 backdrop-blur-sm rounded-xl">
                <FiUsers className="h-8 w-8 text-white" />
              </div>
              <div className="ml-5">
                <p className="text-base font-medium text-emerald-100">Applied Jobs</p>
                <p className="text-3xl font-bold text-white">{user?.role === 'employer' ? jobs.reduce((total, job) => total + (job.applicants ? job.applicants.length : 0), 0) : [...new Set(applications.map(app => app.job?._id))].filter(id => id !== undefined).length}</p>
              </div>
            </div>
          </div>
          <div className="px-6 py-3 bg-white bg-opacity-10 text-white text-sm font-medium">
            {user?.role === 'employer' ? 'For your jobs' : 'You applied to'}
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden transform hover:-translate-y-1">
          <div className="p-6">
            <div className="flex items-center">
              <div className="p-4 bg-white bg-opacity-20 backdrop-blur-sm rounded-xl">
                <FiFileText className="h-8 w-8 text-white" />
              </div>
              <div className="ml-5">
                <p className="text-base font-medium text-amber-100">Interviews</p>
                <p className="text-3xl font-bold text-white">{user?.role === 'employer' ? allApplications.length : applications.filter(app => app.status === 'Interview').length}</p>
              </div>
            </div>
          </div>
          <div className="px-6 py-3 bg-white bg-opacity-10 text-white text-sm font-medium">
            {user?.role === 'employer' ? 'Received for your jobs' : 'Interviews received'}
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-violet-500 to-purple-600 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden transform hover:-translate-y-1">
          <div className="p-6">
            <div className="flex items-center">
              <div className="p-4 bg-white bg-opacity-20 backdrop-blur-sm rounded-xl">
                <FiSettings className="h-8 w-8 text-white" />
              </div>
              <div className="ml-5">
                <p className="text-base font-medium text-violet-100">Success Rate</p>
                <p className="text-3xl font-bold text-white">
                  {user?.role === 'employer' && allApplications.length > 0 
                    ? `${Math.round((allApplications.filter(app => app.status !== 'Pending').length / allApplications.length) * 100)}%` 
                    : applications.length > 0 
                      ? `${Math.round((applications.filter(app => app.status === 'Accepted').length / applications.length) * 100)}%` 
                      : '0%'}
                </p>
              </div>
            </div>
          </div>
          <div className="px-6 py-3 bg-white bg-opacity-10 text-white text-sm font-medium">
            {user?.role === 'employer' ? 'Application responses' : 'Offers received'}
          </div>
        </div>
      </div>

      {/* Show job applications if a job is selected, otherwise show appropriate content */}
      {selectedJob ? (
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
              <div>
                <h3 className="text-2xl font-bold text-gray-900">
                  Applications for "{selectedJob.title}"
                </h3>
                <p className="text-gray-600 mt-1">Review and manage applicants for this position</p>
              </div>
              <button 
                onClick={() => navigate('/my-jobs')}
                className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-lg hover:from-blue-700 hover:to-indigo-700 transition duration-300 shadow-md"
              >
                <FiBriefcase className="mr-2" /> Back to Jobs
              </button>
            </div>
          </div>
          
          <div className="p-6">
            <div className="space-y-6">
              {jobApplications.length > 0 ? (
                jobApplications.map((application) => (
                  <div key={application._id} className="p-6 bg-gray-50 rounded-xl border border-gray-200 hover:shadow-md transition-shadow duration-200">
                    <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4">
                      <div className="flex-1">
                        <div className="flex items-center mb-3">
                          <div className="w-12 h-12 rounded-full mr-3 overflow-hidden">
                            {application.applicant?.profile?.avatar ? (
                              <img 
                                src={`http://localhost:5000${application.applicant.profile.avatar}`} 
                                alt={application.applicant.name || 'Applicant'} 
                                className="w-full h-full object-cover rounded-full" 
                              />
                            ) : (
                              <div className="w-full h-full bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                                <FiUser className="h-6 w-6 text-blue-600" />
                              </div>
                            )}
                          </div>
                          <div>
                            <h4 className="font-bold text-lg text-gray-900">{application.applicant?.name || 'Applicant'}</h4>
                            <p className="text-gray-600">{application.applicant?.email || 'Email not provided'}</p>
                          </div>
                        </div>
                        <div className="ml-15 md:ml-0">
                          <p className="text-sm text-gray-600 mb-2">
                            Applied {formatDate(application.createdAt)}
                          </p>
                          {application.coverLetter && (
                            <div className="mt-3">
                              <h5 className="font-medium text-gray-900 mb-1">Cover Letter:</h5>
                              <p className="text-gray-700 text-sm bg-white p-3 rounded-lg border border-gray-200">
                                {application.coverLetter}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-3">
                        <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                          application.status === 'Pending' 
                            ? 'bg-yellow-100 text-yellow-800' 
                            : application.status === 'Interview' 
                              ? 'bg-blue-100 text-blue-800' 
                              : application.status === 'Accepted' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-red-100 text-red-800'
                        }`}>
                          {application.status}
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {/* Always show status update buttons, regardless of current status */}
                          <button
                            onClick={() => updateApplicationStatus(application._id, 'Accepted')}
                            className={`flex items-center text-sm px-3 py-2 rounded-lg transition-colors duration-200 shadow-sm ${
                              application.status === 'Accepted' 
                                ? 'bg-green-700 text-white' 
                                : 'bg-green-600 text-white hover:bg-green-700'
                            }`}
                          >
                            <FiCheck className="mr-1" /> Accept
                          </button>
                          <button
                            onClick={() => updateApplicationStatus(application._id, 'Interview')}
                            className={`flex items-center text-sm px-3 py-2 rounded-lg transition-colors duration-200 shadow-sm ${
                              application.status === 'Interview' 
                                ? 'bg-blue-700 text-white' 
                                : 'bg-blue-600 text-white hover:bg-blue-700'
                            }`}
                          >
                            <FiUsers className="mr-1" /> Interview
                          </button>
                          <button
                            onClick={() => updateApplicationStatus(application._id, 'Rejected')}
                            className={`flex items-center text-sm px-3 py-2 rounded-lg transition-colors duration-200 shadow-sm ${
                              application.status === 'Rejected' 
                                ? 'bg-red-700 text-white' 
                                : 'bg-red-600 text-white hover:bg-red-700'
                            }`}
                          >
                            <FiX className="mr-1" /> Reject
                          </button>
                          <button
                            onClick={() => downloadResume(application._id, application.applicant?.name)}
                            className="flex items-center text-sm bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-3 py-2 rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all duration-200 shadow-sm"
                          >
                            <FiDownload className="mr-1" /> Resume
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12">
                  <div className="text-gray-400 text-5xl mb-4">📋</div>
                  <h4 className="text-xl font-medium text-gray-900 mb-2">No Applications Yet</h4>
                  <p className="text-gray-600">There are no applications for this job posting yet.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* For employers, show job applications snapshot */
        user?.role === 'employer' ? (
          <div className="grid grid-cols-1 gap-8">
            <EmployerJobApplicationsSnapshot />
          </div>
        ) : user?.role === 'jobseeker' ? (
          <div className="grid grid-cols-1 gap-8">
            {/* My Applications section for job seekers */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">My Applications</h2>
                    <p className="text-gray-600 mt-1">Track and manage your job applications</p>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row gap-3">
                    {/* Search */}
                    <div className="relative">
                      <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search applications..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none w-full sm:w-64"
                      />
                    </div>
                    
                    {/* Status Filter */}
                    <div className="relative">
                      <FiFilter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                      <select
                        value={filterStatus}
                        onChange={(e) => setFilterStatus(e.target.value)}
                        className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none appearance-none bg-white w-full sm:w-48"
                      >
                        <option value="all">All Statuses</option>
                        <option value="Pending">Pending</option>
                        <option value="Interview">Interview</option>
                        <option value="Accepted">Accepted</option>
                        <option value="Rejected">Rejected</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                {filteredApplications.length > 0 ? (
                  <div className="space-y-6">
                    {filteredApplications.map((application) => (
                      <div key={application._id} className="bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden group">
                        <div className="p-6">
                          <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-6">
                            <div className="flex-1 flex items-start gap-5">
                              <div className="flex-shrink-0 w-16 h-16 rounded-xl overflow-hidden bg-white flex items-center justify-center shadow-md border border-gray-200">
                                {application.job?.companyLogo ? (
                                  <img 
                                    src={`http://localhost:5000${application.job.companyLogo}`} 
                                    alt={application.job?.company?.name || application.job?.company?.company?.name || 'Company'} 
                                    className="w-12 h-12 object-contain rounded-md" 
                                  />
                                ) : (
                                  <FiBriefcase className="h-8 w-8 text-blue-600" />
                                )}
                              </div>
                              <div className="min-w-0 flex-1">
                                <div className="flex items-start justify-between gap-4">
                                  <div>
                                    <h4 className="font-bold text-xl text-gray-900 truncate group-hover:text-blue-600 transition-colors">
                                      {application.job?.title || 'Job Title'}
                                    </h4>
                                    <p className="text-lg text-gray-700 mt-1 truncate">
                                      {application.job?.company?.name || application.job?.company?.company?.name || application.job?.name || 'Company Name'}
                                    </p>
                                    
                                    {/* Job details */}
                                    <div className="flex flex-wrap items-center gap-5 text-sm text-gray-600 mt-3">
                                      {application.job?.location && (
                                        <div className="flex items-center gap-1.5">
                                          <FiMapPin className="h-4 w-4 text-gray-500" />
                                          <span>{application.job.location}</span>
                                        </div>
                                      )}
                                      {application.job?.salaryMin && application.job?.salaryMax && (
                                        <div className="flex items-center gap-1.5">
                                          <FiTag className="h-4 w-4 text-gray-500" />
                                          <span>₹{application.job.salaryMin.toLocaleString()} - ₹{application.job.salaryMax.toLocaleString()}</span>
                                        </div>
                                      )}
                                      <div className="flex items-center gap-1.5">
                                        <FiCalendar className="h-4 w-4 text-gray-500" />
                                        <span>Applied {formatDate(application.createdAt)}</span>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex-shrink-0">
                                    <span className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold ${
                                      application.status === 'Pending' 
                                        ? 'bg-amber-100 text-amber-800' 
                                        : application.status === 'Interview' 
                                          ? 'bg-blue-100 text-blue-800' 
                                          : application.status === 'Accepted' 
                                            ? 'bg-green-100 text-green-800' 
                                            : 'bg-rose-100 text-rose-800'
                                    }`}>
                                      {application.status}
                                    </span>
                                  </div>
                                </div>
                                
                                {application.coverLetter && (
                                  <div className="mt-5">
                                    <h5 className="font-semibold text-gray-800 mb-2 flex items-center gap-2">
                                      <FiFileText className="h-4 w-4" /> Cover Letter
                                    </h5>
                                    <div className="bg-gray-50 rounded-lg border border-gray-200 p-4">
                                      <p className="text-gray-700 leading-relaxed">
                                        {application.coverLetter.substring(0, 200)}
                                        {application.coverLetter.length > 200 && (
                                          <span className="text-blue-600 font-medium cursor-pointer ml-1" onClick={() => alert(application.coverLetter)}>... read more</span>
                                        )}
                                      </p>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                          
                          <div className="mt-6 pt-5 border-t border-gray-100 flex justify-end">
                            <button
                              onClick={() => {
                                // Navigate to job details page
                                window.location.href = `/jobs/${application.job?._id}`;
                              }}
                              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-md hover:shadow-lg"
                            >
                              <FiBriefcase className="h-4 w-4" /> View Job Details
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-16">
                    <div className="mx-auto inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-blue-100 to-indigo-100 mb-6">
                      <FiBriefcase className="h-10 w-10 text-blue-600" />
                    </div>
                    <h4 className="text-2xl font-bold text-gray-900 mb-3">No Applications Found</h4>
                    <p className="text-gray-600 text-lg mb-8 max-w-md mx-auto">You haven't submitted any job applications yet. Start exploring opportunities that match your skills!</p>
                    <a href="/jobs" className="inline-flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold rounded-xl hover:from-blue-700 hover:to-indigo-700 transition-all duration-300 shadow-lg hover:shadow-xl">
                      <FiBriefcase className="h-5 w-5" /> Browse Job Opportunities
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          {/* Removed Job Application Tracker section for job seekers */}
        )
      )}
      
      {/* Removed Contact Admin Form - Users can use the main Contact page to send messages to admin */}
    </div>
  );
};

export default Dashboard;