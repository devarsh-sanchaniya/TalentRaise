import React from 'react';
import { Link } from 'react-router-dom';
import { FiSearch, FiBriefcase, FiUsers, FiAward, FiChevronRight, FiUser, FiFileText, FiUpload, FiMessageSquare, FiMonitor, FiTrendingUp, FiDollarSign, FiHeart, FiBookOpen, FiShoppingBag } from 'react-icons/fi';
import { convertUsdToInr } from '../utils/currencyConverter';
import { motion } from 'framer-motion';

const Home = () => {
  const featuredJobs = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      salary: convertUsdToInr("₹12,00,000 - ₹15,00,000"),
      type: "Full-time",
      logo: "https://placehold.co/60x60"
    },
    {
      id: 2,
      title: "Product Manager",
      company: "InnovateCo",
      location: "Remote",
      salary: convertUsdToInr("₹11,00,000 - ₹14,00,000"),
      type: "Full-time",
      logo: "https://placehold.co/60x60"
    },
    {
      id: 3,
      title: "UX Designer",
      company: "DesignHub",
      location: "New York, NY",
      salary: convertUsdToInr("₹9,00,000 - ₹12,00,000"),
      type: "Full-time",
      logo: "https://placehold.co/60x60"
    }
  ];

  const categories = [
    { name: "Technology", count: "1,245", icon: <FiMonitor className="text-3xl text-primary-600 mx-auto mb-3" /> },
    { name: "Marketing", count: "892", icon: <FiTrendingUp className="text-3xl text-primary-600 mx-auto mb-3" /> },
    { name: "Finance", count: "634", icon: <FiDollarSign className="text-3xl text-primary-600 mx-auto mb-3" /> },
    { name: "Healthcare", count: "521", icon: <FiHeart className="text-3xl text-primary-600 mx-auto mb-3" /> },
    { name: "Education", count: "412", icon: <FiBookOpen className="text-3xl text-primary-600 mx-auto mb-3" /> },
    { name: "Sales", count: "736", icon: <FiShoppingBag className="text-3xl text-primary-600 mx-auto mb-3" /> }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative text-white py-32 md:py-40 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-900/90 to-secondary-900/90 z-0"></div>
        <div className="absolute inset-0 z-0" 
             style={{backgroundImage: 'url(https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80)', backgroundSize: 'cover', backgroundPosition: 'center', filter: 'blur(2px)'}}>
        </div>
        <div className="w-full px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <motion.h1 
              className="text-4xl md:text-6xl font-extrabold mb-6 leading-tight"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Find Your Dream Job with <span className="text-secondary-400">TalentRaise</span>
            </motion.h1>
            <motion.p 
              className="text-xl md:text-2xl mb-10 max-w-3xl mx-auto opacity-90"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              Connect with top employers and discover opportunities that match your skills and aspirations. Your career journey starts here.
            </motion.p>
            
            {/* Search Bar */}
            <motion.div 
              className="max-w-3xl mx-auto mb-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-2 flex flex-col sm:flex-row gap-2">
                <div className="flex-1 flex items-center">
                  <FiSearch className="h-5 w-5 text-gray-400 ml-4" />
                  <input
                    type="text"
                    placeholder="Job title, keywords, or company"
                    className="w-full px-4 py-4 text-gray-700 focus:outline-none rounded-2xl"
                  />
                </div>
                <div className="flex-1 flex items-center">
                  <FiBriefcase className="h-5 w-5 text-gray-400 ml-4" />
                  <input
                    type="text"
                    placeholder="Location"
                    className="w-full px-4 py-4 text-gray-700 focus:outline-none rounded-2xl"
                  />
                </div>
                <button className="bg-gradient-to-r from-primary-600 to-secondary-600 hover:from-primary-700 hover:to-secondary-700 text-white font-semibold py-4 px-8 rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-lg">
                  <span className="flex items-center">
                    <FiSearch className="mr-2" /> Search Jobs
                  </span>
                </button>
              </div>
            </motion.div>
            
            <motion.div 
              className="mt-8 flex flex-wrap justify-center gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <span className="bg-white/20 backdrop-blur-sm px-6 py-3 rounded-full text-sm font-medium flex items-center">
                <FiUsers className="mr-2" /> Trending: Remote Work
              </span>
              <span className="bg-white/20 backdrop-blur-sm px-6 py-3 rounded-full text-sm font-medium flex items-center">
                <FiBriefcase className="mr-2" /> 50,000+ Jobs Available
              </span>
              <span className="bg-white/20 backdrop-blur-sm px-6 py-3 rounded-full text-sm font-medium flex items-center">
                <FiAward className="mr-2" /> 10,000+ Companies Hiring
              </span>
            </motion.div>
          </div>
        </div>
        
        {/* Floating elements for visual enhancement */}
        <div className="absolute bottom-10 left-10 w-24 h-24 rounded-full bg-secondary-400/20 blur-xl animate-pulse"></div>
        <div className="absolute top-10 right-10 w-32 h-32 rounded-full bg-primary-400/20 blur-xl animate-pulse" style={{animationDelay: '1s'}}></div>
      </section>

      {/* Statistics Section */}
      <section className="py-16 bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="bg-white rounded-2xl shadow-xl p-8 text-center border border-gray-100 hover:shadow-2xl transition-all duration-300"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-xl flex items-center justify-center">
                  <FiBriefcase className="text-2xl text-white" />
                </div>
              </div>
              <div className="text-4xl font-bold text-primary-600 mb-2">50K+</div>
              <div className="text-gray-600 font-medium text-lg">Jobs Available</div>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-2xl shadow-xl p-8 text-center border border-gray-100 hover:shadow-2xl transition-all duration-300"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-xl flex items-center justify-center">
                  <FiUsers className="text-2xl text-white" />
                </div>
              </div>
              <div className="text-4xl font-bold text-primary-600 mb-2">10K+</div>
              <div className="text-gray-600 font-medium text-lg">Companies Hiring</div>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-2xl shadow-xl p-8 text-center border border-gray-100 hover:shadow-2xl transition-all duration-300"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-xl flex items-center justify-center">
                  <FiAward className="text-2xl text-white" />
                </div>
              </div>
              <div className="text-4xl font-bold text-primary-600 mb-2">2M+</div>
              <div className="text-gray-600 font-medium text-lg">Active Users</div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Platform Information Section */}
      <section className="py-20 bg-gradient-to-br from-white to-gray-50">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-stretch gap-16">
            {/* Left Side - Creative Visualization */}
            <motion.div 
              className="lg:w-1/2 w-full"
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
            >
              <div className="rounded-3xl overflow-hidden shadow-2xl bg-gradient-to-br from-primary-500 to-secondary-500 h-full flex items-center justify-center p-8 min-h-[500px] relative">
                {/* Decorative elements */}
                <div className="absolute top-10 left-10 w-24 h-24 rounded-full bg-white/10 backdrop-blur-sm"></div>
                <div className="absolute bottom-10 right-10 w-32 h-32 rounded-full bg-white/10 backdrop-blur-sm"></div>
                <div className="absolute top-1/2 left-10 w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm"></div>
                
                {/* Main visualization */}
                <div className="relative z-10 w-full max-w-md mx-auto">
                  <div className="flex justify-center mb-12">
                    <div className="relative">
                      {/* Connection lines */}
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-32">
                        <svg viewBox="0 0 200 100" className="w-full h-full">
                          <path d="M 20 50 Q 100 10, 180 50" stroke="rgba(255,255,255,0.7)" strokeWidth="2" fill="none" strokeDasharray="5,5" className="animate-pulse" />
                          <path d="M 20 50 Q 100 90, 180 50" stroke="rgba(255,255,255,0.7)" strokeWidth="2" fill="none" strokeDasharray="5,5" className="animate-pulse" style={{animationDelay: '0.5s'}} />
                        </svg>
                      </div>
                      
                      {/* Job seeker avatar */}
                      <div className="absolute -left-6 top-1/2 transform -translate-y-1/2 w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-lg">
                        <FiUser className="text-primary-600 text-2xl" />
                      </div>
                      
                      {/* Employer avatar */}
                      <div className="absolute -right-6 top-1/2 transform -translate-y-1/2 w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-lg">
                        <FiBriefcase className="text-secondary-600 text-2xl" />
                      </div>
                      
                      {/* Central connection point */}
                      <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center mx-auto shadow-xl animate-pulse">
                        <FiAward className="text-primary-600 text-3xl" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center text-white">
                    <h3 className="text-2xl font-bold mb-4">Talent Meets Opportunity</h3>
                    <p className="opacity-90">Connecting skilled professionals with innovative companies</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Right Side - Platform Information */}
            <motion.div 
              className="lg:w-1/2 w-full flex flex-col justify-center"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">Connecting Talent with <span className="text-primary-600">Opportunity</span></h2>
              <p className="text-gray-600 text-xl mb-10 leading-relaxed">
                TalentRaise is India's fastest-growing job portal platform, connecting thousands of job seekers with top employers across various industries.
              </p>
              
              <div className="space-y-8">
                <div className="flex items-start group">
                  <div className="flex-shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center mr-6 shadow-lg group-hover:shadow-xl transition-all duration-300">
                    <FiUsers className="text-2xl text-primary-600" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">For Job Seekers</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Access over 50,000 job opportunities, build your professional profile, and get matched with employers who value your skills.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start group">
                  <div className="flex-shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center mr-6 shadow-lg group-hover:shadow-xl transition-all duration-300">
                    <FiBriefcase className="text-2xl text-primary-600" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">For Employers</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Find the perfect candidates for your open positions with our advanced matching algorithms and recruitment tools.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start group">
                  <div className="flex-shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center mr-6 shadow-lg group-hover:shadow-xl transition-all duration-300">
                    <FiAward className="text-2xl text-primary-600" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-3">Why Choose Us</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Advanced AI matching, real-time analytics, and dedicated support to ensure success for both job seekers and employers.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Resume Building Section */}
      <section className="py-16 bg-gradient-to-br from-white to-gray-50">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-stretch gap-12">
            {/* Left Side - Resume Building Summary */}
            <div className="lg:w-1/2 w-full flex flex-col justify-center">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6 leading-tight">Build a Professional <span className="text-primary-600">Resume</span> That Stands Out</h2>
              <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                Create an impressive resume that highlights your skills, experience, and achievements. Our platform provides tools and templates to help you craft a resume that catches employers' attention and lands you interviews.
              </p>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary-100 flex items-center justify-center mt-1 mr-3">
                    <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span className="text-gray-700">Professional templates designed for various industries</span>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary-100 flex items-center justify-center mt-1 mr-3">
                    <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span className="text-gray-700">Various methods to optimize your content</span>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary-100 flex items-center justify-center mt-1 mr-3">
                    <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span className="text-gray-700">Easy-to-use editor with real-time preview</span>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary-100 flex items-center justify-center mt-1 mr-3">
                    <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span className="text-gray-700">Works seamlessly on all devices - desktop, tablet, and mobile</span>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary-100 flex items-center justify-center mt-1 mr-3">
                    <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span className="text-gray-700">Get real-time suggestions to improve your resume</span>
                </li>
                <li className="flex items-start">
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary-100 flex items-center justify-center mt-1 mr-3">
                    <svg className="w-3 h-3 text-primary-600" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span className="text-gray-700">Export in PDF format for easy sharing and printing</span>
                </li>
              </ul>
              <div className="flex flex-wrap gap-4">
                <Link to="/resume-builder" className="bg-gradient-to-r from-primary-600 to-secondary-600 hover:from-primary-700 hover:to-secondary-700 text-white font-bold py-3.5 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center">
                  Build Resume Now <FiChevronRight className="ml-2" />
                </Link>
                <Link to="/resume-info" className="bg-white text-primary-600 border border-primary-300 hover:bg-gray-50 font-bold py-3.5 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-md">
                  Learn More
                </Link>
              </div>
            </div>
            
            {/* Right Side - Resume Building Card */}
            <motion.div 
              className="lg:w-1/2 w-full"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <div className="bg-gradient-to-br from-white to-gray-50 rounded-3xl shadow-2xl p-8 h-full border border-gray-100">
                <div className="text-center mb-8">
                  <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <FiFileText className="text-4xl text-primary-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Professional Resume Builder</h3>
                  <p className="text-gray-600">Create your perfect resume in minutes</p>
                </div>
                
                <div className="space-y-6">
                  <div className="flex items-center p-4 bg-gray-50 rounded-xl">
                    <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-primary-100 flex items-center justify-center mr-4">
                      <span className="text-primary-600 font-bold">1</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">Login to Your Account</h4>
                      <p className="text-gray-600 text-sm">Login to create your resume according to your preferences</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center p-4 bg-gray-50 rounded-xl">
                    <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-primary-100 flex items-center justify-center mr-4">
                      <span className="text-primary-600 font-bold">2</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">Add Your Details</h4>
                      <p className="text-gray-600 text-sm">Fill in your experience and skills</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center p-4 bg-gray-50 rounded-xl">
                    <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-primary-100 flex items-center justify-center mr-4">
                      <span className="text-primary-600 font-bold">3</span>
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900">Download & Share</h4>
                      <p className="text-gray-600 text-sm">Get your resume in soft copy format</p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 pt-6 border-t border-gray-200">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-gray-600 font-medium">Resume Score</span>
                    <span className="text-primary-600 font-bold">100%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div className="bg-gradient-to-r from-primary-500 to-secondary-500 h-3 rounded-full" style={{ width: '100%' }}></div>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">Everyone can build resume as well above average!</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Categories Section */}
      <section className="py-20 bg-gradient-to-br from-white to-gray-50">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Browse by Category</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-6">
              Explore jobs across various industries and find the perfect opportunity for your career growth.
            </p>
            <div className="w-24 h-1 bg-gradient-to-r from-primary-500 to-secondary-500 mx-auto rounded-full"></div>
          </motion.div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {categories.map((category, index) => (
              <motion.div
                key={index}
                className="bg-white rounded-2xl shadow-xl p-8 text-center hover:shadow-2xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 border border-gray-100"
                whileHover={{ y: -10 }}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="flex justify-center mb-6">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center shadow-lg">
                    <div className="w-12 h-12 text-primary-600 flex items-center justify-center">
                      {category.icon}
                    </div>
                  </div>
                </div>
                <h3 className="font-bold text-xl text-gray-900 mb-2">{category.name}</h3>
                <p className="text-gray-500 font-medium">{category.count} jobs</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>


      {/* Success Stories/Testimonials */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Success Stories</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-6">
              Hear from job seekers who found their dream careers and employers who built great teams.
            </p>
            <div className="w-24 h-1 bg-gradient-to-r from-primary-500 to-secondary-500 mx-auto rounded-full"></div>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full px-4">
            {/* Job Seeker Testimonial */}
            <motion.div
              className="bg-white rounded-2xl shadow-xl p-6 hover:shadow-2xl transition-all duration-300 border border-gray-100 h-full"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="flex items-center mb-4">
                <div className="w-14 h-14 rounded-full mr-4 overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&h=200&q=80" 
                    alt="Priya Sharma" 
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-900">Priya Sharma</h3>
                  <p className="text-gray-600 text-sm">Software Engineer</p>
                </div>
              </div>
              <p className="text-gray-700 text-base mb-4 flex-grow">"TalentRaise helped me land my dream job at a top tech company. The platform's matching algorithm connected me with opportunities that perfectly matched my skills and career goals. Within 2 weeks of joining, I had 3 interview invitations!"</p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <FiAward key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
            </motion.div>
            
            {/* Employer Testimonial */}
            <motion.div
              className="bg-white rounded-2xl shadow-xl p-6 hover:shadow-2xl transition-all duration-300 border border-gray-100 h-full"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 0 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="flex items-center mb-4">
                <div className="w-14 h-14 rounded-full mr-4 overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&h=200&q=80" 
                    alt="Rajesh Kumar" 
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-900">Rajesh Kumar</h3>
                  <p className="text-gray-600 text-sm">HR Director, Tech Innovations Ltd.</p>
                </div>
              </div>
              <p className="text-gray-700 text-base mb-4 flex-grow">"We found exceptional talent through TalentRaise. The quality of candidates has improved dramatically, and our hiring time has reduced by 50%. The platform's screening tools helped us identify the best fits quickly and efficiently."</p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <FiAward key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
            </motion.div>
            
            {/* Third Testimonial - Another Job Seeker */}
            <motion.div
              className="bg-white rounded-2xl shadow-xl p-6 hover:shadow-2xl transition-all duration-300 border border-gray-100 h-full"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="flex items-center mb-4">
                <div className="w-14 h-14 rounded-full mr-4 overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&h=200&q=80" 
                    alt="Amit Patel" 
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
                <div>
                  <h3 className="font-bold text-lg text-gray-900">Amit Patel</h3>
                  <p className="text-gray-600 text-sm">Marketing Manager</p>
                </div>
              </div>
              <p className="text-gray-700 text-base mb-4 flex-grow">"After months of unsuccessful job hunting, I joined TalentRaise and got multiple offers within a month. The personalized job recommendations and career guidance made all the difference. I finally secured the position I was aiming for!"</p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <FiAward key={i} className="h-4 w-4 fill-current" />
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-gray-100">
        <div className="w-full px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-6">
                Simple steps to find your next career opportunity or hire the best talent.
              </p>
              <div className="w-24 h-1 bg-gradient-to-r from-primary-500 to-secondary-500 mx-auto rounded-full"></div>
            </motion.div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div 
              className="bg-white rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-xl flex items-center justify-center">
                  <FiUser className="text-2xl text-white" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">Create Account</h3>
              <p className="text-gray-600 text-center leading-relaxed">
                Sign up as a job seeker or employer to access our platform features.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-xl flex items-center justify-center">
                  <FiFileText className="text-2xl text-white" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">Upload Resume</h3>
              <p className="text-gray-600 text-center leading-relaxed">
                Upload your resume and profile information to showcase your skills and experience.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-xl flex items-center justify-center">
                  <FiSearch className="text-2xl text-white" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">Find Opportunities</h3>
              <p className="text-gray-600 text-center leading-relaxed">
                Search and apply for jobs or post openings to attract qualified candidates.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100"
              whileHover={{ y: -10 }}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-xl flex items-center justify-center">
                  <FiMessageSquare className="text-2xl text-white" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">Connect & Grow</h3>
              <p className="text-gray-600 text-center leading-relaxed">
                Engage with employers or candidates and advance your career journey.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-24 text-white overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-900/95 to-secondary-900/95 z-0"></div>
        <div className="absolute inset-0 z-0" 
             style={{backgroundImage: 'url(https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80)', backgroundSize: 'cover', backgroundPosition: 'center', filter: 'blur(2px)'}}>
        </div>
        <div className="w-full px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Take the Next Step?</h2>
            <p className="text-2xl mb-12 max-w-3xl mx-auto opacity-90">
              Join thousands of professionals who found their dream jobs through our platform.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-6">
              <Link to="/register" className="bg-gradient-to-r from-white to-gray-100 text-primary-600 hover:from-gray-100 hover:to-gray-200 font-bold py-4 px-10 rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-2xl flex items-center justify-center">
                <FiUser className="mr-2" /> Get Started Now
              </Link>
              <Link to="/post-job" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-bold py-4 px-10 rounded-2xl transition-all duration-300 transform hover:scale-105 flex items-center justify-center">
                <FiBriefcase className="mr-2" /> Post a Job
              </Link>
            </div>
          </motion.div>
        </div>
        
        {/* Floating elements for visual enhancement */}
        <div className="absolute bottom-10 left-10 w-32 h-32 rounded-full bg-secondary-400/20 blur-3xl animate-pulse"></div>
        <div className="absolute top-10 right-10 w-40 h-40 rounded-full bg-primary-400/20 blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
      </section>
    </div>
  );
};

export default Home;