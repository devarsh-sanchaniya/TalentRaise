import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { FiMapPin, FiClock, FiBriefcase, FiShare2, FiArrowLeft } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';
import { applicationsAPI } from '../services/api';
import ApplicationForm from '../components/ApplicationForm';
import axios from 'axios';

const JobDetails = () => {
  const { id } = useParams();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  // Format the posted date to show relative time
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffMinutes < 60) {
      return `${diffMinutes} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else if (diffDays === 1) {
      return '1 day ago';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      const weeks = Math.floor(diffDays / 7);
      return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
    } else {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months > 1 ? 's' : ''} ago`;
    }
  };

  useEffect(() => {
    const fetchJob = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`http://localhost:5000/api/jobs/${id}`);
        setJob(response.data);
      } catch (err) {
        setError('Failed to fetch job details');
        console.error('Error fetching job:', err);
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchJob();
    }
  }, [id]);

  const handleApply = () => {
    if (user?.role === 'jobseeker') {
      setShowApplicationForm(true);
    } else {
      alert('Only job seekers can apply for jobs. Please login as a job seeker.');
    }
  };

  if (loading) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center py-12">
          <div className="text-gray-400 text-6xl mb-4">⚠️</div>
          <h3 className="text-xl font-medium text-gray-900 mb-2">Job not found</h3>
          <p className="text-gray-600">The job you're looking for doesn't exist or has been removed.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
      <div className="fixed top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-indigo-600"></div>
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-6 mb-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Job Details</h1>
          <p className="text-lg text-gray-600">Find the perfect opportunity to advance your career</p>
        </div>
      </div>
      {/* Application Form Modal */}
      {showApplicationForm && (
        <ApplicationForm 
          job={job} 
          onClose={() => setShowApplicationForm(false)} 
        />
      )}

      {/* Back Button */}
      <button 
        onClick={() => navigate(-1)}
        className="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 hover:border-gray-400 transition duration-200 shadow-sm mb-6"
      >
        <FiArrowLeft className="mr-2" />
        Back to Jobs
      </button>

      {/* Job Header */}
      <div className="bg-white rounded-2xl shadow-lg mb-8 overflow-hidden">
        <div className="p-6 md:p-8">
          <div className="flex flex-col md:flex-row">
            <div className="flex-shrink-0 mb-6 md:mb-0 md:mr-8">
              <div className="bg-white border border-gray-200 rounded-2xl w-24 h-24 flex items-center justify-center shadow-md">
                {job.companyLogo ? (
                  <img 
                    src={`http://localhost:5000${job.companyLogo}`} 
                    alt={`${job.company?.name || 'Company'} logo`} 
                    className="w-16 h-16 object-contain rounded-md"
                  />
                ) : (
                  <FiBriefcase className="h-12 w-12 text-blue-600" />
                )}
              </div>
            </div>
            <div className="flex-grow">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-6">
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">{job.title}</h1>
                  <h2 className="text-2xl text-blue-600 font-semibold mb-4">{job.company?.company?.name || job.company?.name || job.employer?.name || 'Company Name'}</h2>
                </div>
                <div className="flex space-x-3 mt-4 md:mt-0">
                  <button className="p-3 rounded-full bg-gray-100 text-gray-600 hover:bg-blue-100 hover:text-blue-600 transition duration-300 shadow-sm">
                    <FiShare2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <FiMapPin className="mr-3 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-500">Location</p>
                    <p className="font-medium">{job.location}</p>
                  </div>
                </div>
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <FiBriefcase className="mr-3 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-500">Salary</p>
                    <p className="font-medium">{job.formattedSalary || 'Not specified'}</p>
                  </div>
                </div>
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <FiClock className="mr-3 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-500">Type</p>
                    <p className="font-medium">{job.employmentType}</p>
                  </div>
                </div>
                <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                  <FiBriefcase className="mr-3 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-500">Experience</p>
                    <p className="font-medium">{job.experienceLevel}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-8 pt-6 border-t border-gray-200 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <span className="text-gray-600">Posted {formatDate(job.createdAt)}</span>
            </div>
            {user?.role !== 'employer' && (
              <div className="flex flex-wrap gap-3">
                <button 
                  className="px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-lg hover:from-blue-700 hover:to-indigo-700 transition duration-300 shadow-md"
                  onClick={handleApply}
                >
                  Apply Now
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2">
          {/* Job Description */}
          <div className="bg-white rounded-2xl shadow-lg mb-8">
            <div className="p-6 md:p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 pb-2 border-b border-gray-200">Job Description</h2>
              <p className="text-gray-700 mb-8 leading-relaxed text-lg break-words">
                {job.description}
              </p>
              
              {job.responsibilities && job.responsibilities.length > 0 && (
                <>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4 pt-4 border-t border-gray-100">Responsibilities</h3>
                  <ul className="space-y-4 mb-8">
                    {job.responsibilities.map((responsibility, index) => (
                      <li key={index} className="flex items-start">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-3 mt-0.5">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </span>
                        <span className="text-gray-700 text-lg break-words">{responsibility}</span>
                      </li>
                    ))}
                  </ul>
                </>
              )}
              
              {job.requirements && job.requirements.length > 0 && (
                <>
                  <h3 className="text-xl font-semibold text-gray-900 mb-4 pt-4 border-t border-gray-100">Requirements</h3>
                  <ul className="space-y-4">
                    {job.requirements.map((requirement, index) => (
                      <li key={index} className="flex items-start">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mr-3 mt-0.5">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                        </span>
                        <span className="text-gray-700 text-lg break-words">{requirement}</span>
                      </li>
                    ))}
                  </ul>
                </>
              )}
            </div>
          </div>
          
          {/* Skills */}
          {job.skills && job.skills.length > 0 && (
            <div className="bg-white rounded-2xl shadow-lg mb-8">
              <div className="p-6 md:p-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 pb-2 border-b border-gray-200">Required Skills</h2>
                <div className="flex flex-wrap gap-3">
                  {job.skills.map((skill, index) => (
                    <span key={index} className="px-4 py-2 bg-gradient-to-r from-blue-50 to-indigo-50 text-blue-700 rounded-full font-medium border border-blue-200">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Sidebar */}
        <div>
          {/* Company Info */}
          <div className="bg-white rounded-2xl shadow-lg mb-8">
            <div className="p-6 md:p-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6 pb-2 border-b border-gray-200">About the Company</h2>
              <div className="mb-6">
                <div>
                  <h3 className="font-bold text-lg text-gray-900 break-words">{job.company?.company?.name || job.company?.name || 'Company Name'}</h3>
                  <p className="text-gray-600 text-sm break-words">{job.company?.company?.location || job.company?.location || 'Location not specified'}</p>
                </div>
              </div>
              <p className="text-gray-700 mb-6 leading-relaxed break-words">
                {job.company?.company?.description || job.company?.description || 'No company description available.'}
              </p>
              {(job.company?.company?.website || job.company?.website) && (
                <div className="mb-6">
                  <a 
                    href={job.company?.company?.website || job.company?.website} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-lg hover:from-blue-700 hover:to-indigo-700 transition duration-300 shadow-sm"
                  >
                    <FiBriefcase className="mr-2" />
                    Visit Company Website
                  </a>
                </div>
              )}
              <div className="space-y-3 text-sm pt-4 border-t border-gray-100">
                <div className="flex justify-between">
                  <span className="text-gray-600">Industry</span>
                  <span className="font-medium">{job.company?.company?.industry || job.company?.industry || job.category || 'Not specified'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Company Size</span>
                  <span className="font-medium">{job.company?.company?.size || job.company?.size || 'Not specified'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Founded</span>
                  <span className="font-medium">{job.company?.company?.founded ? new Date(job.company.company.founded).getFullYear() : job.company?.founded ? new Date(job.company.founded).getFullYear() : 'Not specified'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default JobDetails;