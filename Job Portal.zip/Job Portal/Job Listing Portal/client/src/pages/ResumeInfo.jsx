import React from 'react';
import { Link } from 'react-router-dom';
import { FiCheck, FiStar, FiShield, FiUsers, FiDownload, FiSmartphone, FiGlobe, FiClock, FiAward, FiBarChart, FiFileText, FiUser, FiBriefcase, FiTrendingUp } from 'react-icons/fi';

const ResumeInfo = () => {
  const features = [
    {
      icon: <FiFileText className="text-3xl text-primary-600" />,
      title: "Professional Templates",
      description: "Choose from dozens of professionally designed templates that stand out to recruiters"
    },
    {
      icon: <FiShield className="text-3xl text-primary-600" />,
      title: "ATS Compatible",
      description: "Our resumes pass through Applicant Tracking Systems with ease"
    },
    {
      icon: <FiStar className="text-3xl text-primary-600" />,
      title: "User friendly",
      description: "Get real-time suggestions to improve your resume content"
    },
    {
      icon: <FiDownload className="text-3xl text-primary-600" />,
      title: "Download",
      description: "Export in PDF format for easy sharing and printing"
    },
    {
      icon: <FiSmartphone className="text-3xl text-primary-600" />,
      title: "Mobile Friendly",
      description: "Create and edit your resume from any device, anywhere"
    },
    {
      icon: <FiTrendingUp className="text-3xl text-primary-600" />,
      title: "Fast Response",
      description: "See how your resume stands out to recruiters with our fast response feature. Get more interview calls and job offers."
    }
  ];

  const testimonials = [
    {
      name: "Rajesh Kumar",
      role: "Software Engineer",
      quote: "My resume got 3x more interview calls after using this builder. Highly recommended!",
      rating: 5
    },
    {
      name: "Priya Sharma",
      role: "Marketing Manager",
      quote: "The templates are beautiful and ATS-friendly. Got hired within 2 weeks!",
      rating: 5
    },
    {
      name: "Amit Patel",
      role: "Product Designer",
      quote: "Finally a resume builder that understands Indian market requirements.",
      rating: 4
    }
  ];

  const stats = [
    { value: "50K+", label: "Resumes Created" },
    { value: "95%", label: "Interview Success Rate" },
    { value: "10K+", label: "Positive Response" },
    { value: "24/7", label: "Support Available" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Hero Section */}
      <section className="relative py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary-900/90 to-secondary-900/90 z-0"></div>
        <div className="absolute inset-0 z-0" 
             style={{backgroundImage: 'url(https://images.unsplash.com/photo-1498050108700-8a0de37db8aa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1920&q=80)', backgroundSize: 'cover', backgroundPosition: 'center', filter: 'blur(2px)'}}>
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Build the Perfect <span className="text-secondary-300">Resume</span>
          </h1>
          <p className="text-xl text-white/90 mb-10 max-w-3xl mx-auto leading-relaxed">
            Create professional, ATS-optimized resumes that get you noticed by employers and land more interviews.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/resume-builder" className="bg-gradient-to-r from-primary-600 to-secondary-600 hover:from-primary-700 hover:to-secondary-700 text-white font-bold py-4 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center">
              <FiFileText className="mr-2" /> Create Your Resume Now
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-primary-600 mb-2">{stat.value}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose Our <span className="text-primary-600">Resume Builder</span></h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We've helped thousands of job seekers create winning resumes that get noticed by employers and HR systems.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 border border-gray-100 transform hover:-translate-y-2">
                <div className="w-16 h-16 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-2xl flex items-center justify-center mb-6">
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How Our <span className="text-primary-600">Resume Builder</span> Works</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Create a professional resume in just a few simple steps
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">1</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Choose Template</h3>
              <p className="text-gray-600">Select from hundreds of professional templates</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">2</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Add Your Info</h3>
              <p className="text-gray-600">Enter your work experience and skills</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">3</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Customize</h3>
              <p className="text-gray-600">Personalize colors, fonts, and layout</p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">4</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Download</h3>
              <p className="text-gray-600">Save in multiple formats and share</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">What Our <span className="text-primary-600">Users Say</span></h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join thousands of satisfied job seekers who found success with our resume builder
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <FiStar key={i} className={`w-5 h-5 ${i < testimonial.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />
                  ))}
                </div>
                <p className="text-gray-700 italic mb-6">"{testimonial.quote}"</p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-primary-100 to-secondary-100 rounded-full flex items-center justify-center mr-4">
                    <FiUser className="text-primary-600" />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900">{testimonial.name}</div>
                    <div className="text-gray-600 text-sm">{testimonial.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tips Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Pro Tips for a <span className="text-primary-600">Winning Resume</span></h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Expert advice to make your resume stand out from the crowd
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <FiCheck className="text-primary-600 mr-3" /> Essential Elements
              </h3>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <FiCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-gray-700"><strong>Contact Information:</strong> Include your phone, email, and LinkedIn profile</span>
                </li>
                <li className="flex items-start">
                  <FiCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-gray-700"><strong>Professional Summary:</strong> Write a compelling 2-3 sentence summary</span>
                </li>
                <li className="flex items-start">
                  <FiCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-gray-700"><strong>Work Experience:</strong> Use action verbs and quantify achievements</span>
                </li>
                <li className="flex items-start">
                  <FiCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-gray-700"><strong>Skills Section:</strong> Match keywords from job descriptions</span>
                </li>
                <li className="flex items-start">
                  <FiCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-gray-700"><strong>Education:</strong> Include relevant degrees and certifications</span>
                </li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <FiAward className="text-primary-600 mr-3" /> Best Practices
              </h3>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <FiCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-gray-700"><strong>Length:</strong> Keep to 1-2 pages maximum</span>
                </li>
                <li className="flex items-start">
                  <FiCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-gray-700"><strong>Format:</strong> Use PDF to preserve formatting</span>
                </li>
                <li className="flex items-start">
                  <FiCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-gray-700"><strong>Keywords:</strong> Include industry-specific terms</span>
                </li>
                <li className="flex items-start">
                  <FiCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-gray-700"><strong>Proofreading:</strong> Check for spelling and grammar errors</span>
                </li>
                <li className="flex items-start">
                  <FiCheck className="text-green-500 mt-1 mr-3 flex-shrink-0" />
                  <span className="text-gray-700"><strong>Customization:</strong> Tailor each resume to specific jobs</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary-900 to-secondary-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Create Your Perfect Resume?</h2>
          <p className="text-xl mb-10 max-w-3xl mx-auto opacity-90">
            Join thousands of successful job seekers who landed their dream jobs with our resume builder
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <Link to="/resume-builder" className="bg-white text-primary-600 hover:bg-gray-100 font-bold py-4 px-10 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center">
              <FiFileText className="mr-2" /> Start Building Now
            </Link>
            <Link to="/contact" className="bg-transparent border-2 border-white text-white hover:bg-white/10 font-bold py-4 px-10 rounded-xl transition-all duration-300 flex items-center justify-center">
              <FiUsers className="mr-2" /> Contact Support
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ResumeInfo;