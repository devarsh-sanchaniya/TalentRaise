import React, { useState, useEffect } from 'react';
import { FiSearch, FiFilter, FiEye, FiTrash2, FiUser, FiLock, FiUnlock, FiMail, FiPhone, FiMapPin, FiEdit, FiCheck, FiX } from 'react-icons/fi';
import AdminLayout from '../../components/admin/AdminLayout';
import { adminAPI } from '../../services/api';

const Users = () => {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [loading, setLoading] = useState(true);
  const [editingUser, setEditingUser] = useState(null);
  const [editFormData, setEditFormData] = useState({});

  // Fetch real users
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        setLoading(true);
        const response = await adminAPI.getAllUsers();
        console.log('Fetched users:', response.data);
        setUsers(response.data);
        setFilteredUsers(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching users:', error);
        setLoading(false);
        // Show empty state if API call fails
        setUsers([]);
        setFilteredUsers([]);
      }
    };

    fetchUsers();
  }, []);

  // Filter users based on search term and role
  useEffect(() => {
    console.log('Filter effect triggered with:', { users, searchTerm, filterRole });
    let result = users;
    
    if (searchTerm) {
      result = result.filter(user => 
        (user.name && user.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (user.email && user.email.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    if (filterRole !== 'all') {
      console.log('Filtering by role:', filterRole);
      result = result.filter(user => {
        console.log('Comparing user role:', user.role, 'with filter:', filterRole, 'result:', user.role === filterRole);
        return user.role === filterRole;
      });
    }
    
    console.log('Filtered result:', result);
    setFilteredUsers(result);
  }, [searchTerm, filterRole, users]);

  const handleDeleteUser = async (userId) => {
    if (window.confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      try {
        await adminAPI.deleteUser(userId);
        setUsers(users.filter(user => user._id !== userId));
        setFilteredUsers(filteredUsers.filter(user => user._id !== userId));
        alert('User deleted successfully');
      } catch (error) {
        console.error('Error deleting user:', error);
        alert('Error deleting user. Please try again.');
      }
    }
  };

  const handleBlockUser = async (userId) => {
    try {
      const response = await adminAPI.blockUser(userId);
      // Update the user in the state
      setUsers(users.map(user => 
        user._id === userId ? {...user, isActive: !user.isActive} : user
      ));
      setFilteredUsers(filteredUsers.map(user => 
        user._id === userId ? {...user, isActive: !user.isActive} : user
      ));
      alert(response.data.message);
    } catch (error) {
      console.error('Error blocking user:', error);
      alert('Error updating user status. Please try again.');
    }
  };

  const handleApproveCompany = async (userId) => {
    try {
      const response = await adminAPI.approveCompany(userId);
      // Update the user in the state
      setUsers(users.map(user => 
        user._id === userId ? response.data : user
      ));
      setFilteredUsers(filteredUsers.map(user => 
        user._id === userId ? response.data : user
      ));
      alert('Company approved successfully');
    } catch (error) {
      console.error('Error approving company:', error);
      alert('Error approving company. Please try again.');
    }
  };

  const getStatusClass = (status) => {
    return status === 'active' 
      ? 'bg-green-100 text-green-800' 
      : 'bg-red-100 text-red-800';
  };

  const getActivityStatusClass = (isOnline) => {
    return isOnline 
      ? 'bg-green-100 text-green-800' 
      : 'bg-gray-100 text-gray-800';
  };

  const getRoleClass = (role) => {
    switch(role) {
      case 'employer':
        return 'bg-blue-100 text-blue-800';
      case 'jobseeker':
        return 'bg-purple-100 text-purple-800';
      case 'admin':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getApprovalClass = (isApproved) => {
    return isApproved 
      ? 'bg-green-100 text-green-800' 
      : 'bg-yellow-100 text-yellow-800';
  };

  const startEditing = (user) => {
    setEditingUser(user._id);
    setEditFormData({
      name: user.name,
      email: user.email,
      phone: user.profile?.phone || '',
      location: user.profile?.location || ''
    });
  };

  const cancelEditing = () => {
    setEditingUser(null);
    setEditFormData({});
  };

  const saveUser = async (userId) => {
    try {
      const userData = {
        name: editFormData.name,
        email: editFormData.email,
        profile: {
          phone: editFormData.phone,
          location: editFormData.location
        }
      };
      const response = await adminAPI.updateUser(userId, userData);
      // Update the user in the state
      setUsers(users.map(user => 
        user._id === userId ? response.data : user
      ));
      setFilteredUsers(filteredUsers.map(user => 
        user._id === userId ? response.data : user
      ));
      setEditingUser(null);
      alert('User updated successfully');
    } catch (error) {
      console.error('Error updating user:', error);
      alert('Error updating user. Please try again.');
    }
  };

  const handleInputChange = (e) => {
    setEditFormData({
      ...editFormData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">User Management</h1>
        </div>
        <div className="mt-8">
          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            {/* Filters and search */}
            <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiSearch className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="text"
                      className="focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                      placeholder="Search users..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <FiFilter className="h-5 w-5 text-gray-400 mr-2" />
                    <select
                      className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      value={filterRole}
                      onChange={(e) => setFilterRole(e.target.value)}
                    >
                      <option value="all">All Roles</option>
                      <option value="jobseeker">Job Seekers</option>
                      <option value="employer">Employers</option>
                      <option value="admin">Admins</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Users table */}
            <div className="overflow-x-auto">
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
                </div>
              ) : filteredUsers.length === 0 ? (
                <div className="text-center py-12">
                  <FiUser className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-2 text-sm font-medium text-gray-900">No users found</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Try adjusting your search or filter criteria.
                  </p>
                </div>
              ) : (
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        User
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Role
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Contact
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Company
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Joined
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Activity
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredUsers.map((user) => (
                      <tr key={user._id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          {editingUser === user._id ? (
                            <div className="flex flex-col space-y-2">
                              <input
                                type="text"
                                name="name"
                                value={editFormData.name}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Name"
                              />
                              <input
                                type="email"
                                name="email"
                                value={editFormData.email}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Email"
                              />
                            </div>
                          ) : (
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-10 w-10">
                                {user.profile?.avatar ? (
                                  <img 
                                    src={`http://localhost:5000${user.profile.avatar}`} 
                                    alt={user.name} 
                                    className="h-10 w-10 rounded-full object-cover"
                                  />
                                ) : (
                                  <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                    <FiUser className="h-6 w-6 text-gray-500" />
                                  </div>
                                )}
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{user.name}</div>
                                <div className="text-sm text-gray-500">{user.email}</div>
                              </div>
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getRoleClass(user.role)}`}>
                            {user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {editingUser === user._id ? (
                            <div className="flex flex-col space-y-2">
                              <input
                                type="text"
                                name="phone"
                                value={editFormData.phone}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Phone"
                              />
                              <input
                                type="text"
                                name="location"
                                value={editFormData.location}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Location"
                              />
                            </div>
                          ) : (
                            <div className="flex flex-col">
                              {user.profile?.phone && (
                                <div className="flex items-center">
                                  <FiPhone className="h-4 w-4 mr-1" />
                                  <span>{user.profile.phone}</span>
                                </div>
                              )}
                              {user.profile?.location && (
                                <div className="flex items-center">
                                  <FiMapPin className="h-4 w-4 mr-1" />
                                  <span>{user.profile.location}</span>
                                </div>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {user.role === 'employer' && (
                            <div className="flex flex-col">
                              <div className="text-sm font-medium text-gray-900">
                                {user.company?.name || 'N/A'}
                              </div>
                              <div className="flex items-center mt-1">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getApprovalClass(user.company?.isApproved)}`}>
                                  {user.company?.isApproved ? 'Approved' : 'Pending'}
                                </span>
                              </div>
                              {user.company?.isApproved === false && (
                                <button
                                  onClick={() => handleApproveCompany(user._id)}
                                  className="mt-1 inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                                >
                                  Approve
                                </button>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(user.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getActivityStatusClass(user.isActive)}`}>
                            {user.isActive ? 'Online' : 'Offline'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default Users;