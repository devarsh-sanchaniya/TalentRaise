import React, { useState, useEffect } from 'react';
import { FiSearch, FiFilter, FiEye, FiTrash2, FiBriefcase, FiXCircle, FiMapPin, FiEdit, FiCheck, FiX } from 'react-icons/fi';
import AdminLayout from '../../components/admin/AdminLayout';
import { adminAPI } from '../../services/api';

const Jobs = () => {
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [loading, setLoading] = useState(true);
  const [editingJob, setEditingJob] = useState(null);
  const [editFormData, setEditFormData] = useState({});

  // Fetch real jobs
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setLoading(true);
        const response = await adminAPI.getAllJobs();
        setJobs(response.data);
        setFilteredJobs(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching jobs:', error);
        setLoading(false);
        // Show empty state if API call fails
        setJobs([]);
        setFilteredJobs([]);
      }
    };

    fetchJobs();
  }, []);

  // Filter jobs based on search term and status
  useEffect(() => {
    let result = jobs;
    
    if (searchTerm) {
      result = result.filter(job => 
        (job.title && job.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (job.company?.name && job.company.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (job.company?.company?.name && job.company.company.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (job.location && job.location.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    if (filterStatus !== 'all') {
      result = result.filter(job => {
        if (filterStatus === 'active') {
          return job.isActive === true;
        } else if (filterStatus === 'closed') {
          return job.isActive === false;
        }
        return true;
      });
    }
    
    setFilteredJobs(result);
  }, [searchTerm, filterStatus, jobs]);

  const handleDeleteJob = async (jobId) => {
    if (window.confirm('Are you sure you want to delete this job? This action cannot be undone.')) {
      try {
        await adminAPI.deleteJob(jobId);
        setJobs(jobs.filter(job => job._id !== jobId));
        setFilteredJobs(filteredJobs.filter(job => job._id !== jobId));
        alert('Job deleted successfully');
      } catch (error) {
        console.error('Error deleting job:', error);
        alert('Error deleting job. Please try again.');
      }
    }
  };

  const handleCloseJob = async (jobId) => {
    if (window.confirm('Are you sure you want to close this job?')) {
      try {
        const response = await adminAPI.closeJob(jobId);
        // Update the job in the state
        setJobs(jobs.map(job => 
          job._id === jobId ? {...job, isActive: false} : job
        ));
        setFilteredJobs(filteredJobs.map(job => 
          job._id === jobId ? {...job, isActive: false} : job
        ));
        alert(response.data.message);
      } catch (error) {
        console.error('Error closing job:', error);
        alert('Error closing job. Please try again.');
      }
    }
  };

  const getStatusClass = (isActive) => {
    return isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  };

  const getTypeClass = (type) => {
    switch (type) {
      case 'Full-time':
        return 'bg-blue-100 text-blue-800';
      case 'Part-time':
        return 'bg-purple-100 text-purple-800';
      case 'Contract':
        return 'bg-green-100 text-green-800';
      case 'Internship':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const startEditing = (job) => {
    setEditingJob(job._id);
    setEditFormData({
      title: job.title,
      location: job.location,
      salaryMin: job.salaryMin || '',
      salaryMax: job.salaryMax || ''
    });
  };

  const cancelEditing = () => {
    setEditingJob(null);
    setEditFormData({});
  };

  const saveJob = async (jobId) => {
    try {
      const jobData = {
        title: editFormData.title,
        location: editFormData.location,
        salaryMin: editFormData.salaryMin,
        salaryMax: editFormData.salaryMax
      };
      const response = await adminAPI.updateJob(jobId, jobData);
      // Update the job in the state
      setJobs(jobs.map(job => 
        job._id === jobId ? response.data : job
      ));
      setFilteredJobs(filteredJobs.map(job => 
        job._id === jobId ? response.data : job
      ));
      setEditingJob(null);
      alert('Job updated successfully');
    } catch (error) {
      console.error('Error updating job:', error);
      alert('Error updating job. Please try again.');
    }
  };

  const handleInputChange = (e) => {
    setEditFormData({
      ...editFormData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Job Management</h1>
        </div>
        <div className="mt-8">
          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            {/* Filters and search */}
            <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiSearch className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="text"
                      className="focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                      placeholder="Search jobs..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    <FiFilter className="h-5 w-5 text-gray-400 mr-2" />
                    <select
                      className="block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      value={filterStatus}
                      onChange={(e) => setFilterStatus(e.target.value)}
                    >
                      <option value="all">All Statuses</option>
                      <option value="active">Active</option>
                      <option value="closed">Closed</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Jobs table */}
            <div className="overflow-x-auto">
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
                </div>
              ) : filteredJobs.length === 0 ? (
                <div className="text-center py-12">
                  <FiBriefcase className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-2 text-sm font-medium text-gray-900">No jobs found</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Try adjusting your search or filter criteria.
                  </p>
                </div>
              ) : (
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Job
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Company
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Details
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Posted
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Applicants
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredJobs.map((job) => (
                      <tr key={job._id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          {editingJob === job._id ? (
                            <div className="flex flex-col space-y-2">
                              <input
                                type="text"
                                name="title"
                                value={editFormData.title}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Job Title"
                              />
                              <input
                                type="text"
                                name="location"
                                value={editFormData.location}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Location"
                              />
                            </div>
                          ) : (
                            <div>
                              <div className="text-sm font-medium text-gray-900">{job.title}</div>
                              <div className="flex items-center mt-1">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getTypeClass(job.employmentType)}`}>
                                  {job.employmentType}
                                </span>
                              </div>
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          <div className="inline-block h-10 w-10 flex items-center justify-center">
                            {job.companyLogo ? (
                              <img 
                                className="h-10 w-10 rounded-md object-cover"
                                src={`http://localhost:5000${job.companyLogo}`} 
                                alt={`${job.company?.name || 'Company'} logo`} 
                              />
                            ) : (
                              <div className="h-10 w-10 rounded-md bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                                <FiBriefcase className="h-5 w-5 text-blue-600" />
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {editingJob === job._id ? (
                            <div className="flex flex-col space-y-2">
                              <input
                                type="number"
                                name="salaryMin"
                                value={editFormData.salaryMin}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Min Salary"
                              />
                              <input
                                type="number"
                                name="salaryMax"
                                value={editFormData.salaryMax}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Max Salary"
                              />
                            </div>
                          ) : (
                            <div className="flex flex-col">
                              <div className="flex items-center">
                                <FiMapPin className="h-4 w-4 mr-1" />
                                <span>{job.location}</span>
                              </div>
                              {(job.salaryMin || job.salaryMax) && (
                                <div className="flex items-center mt-1">
                                  <span className="h-4 w-4 mr-1">₹</span>
                                  <span>
                                    {job.salaryMin ? `₹${job.salaryMin.toLocaleString()}` : ''}
                                    {job.salaryMin && job.salaryMax ? ' - ' : ''}
                                    {job.salaryMax ? `₹${job.salaryMax.toLocaleString()}` : ''}
                                  </span>
                                </div>
                              )}
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(job.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <div className="flex items-center">
                            <FiBriefcase className="h-4 w-4 mr-1" />
                            <span>{job.applicants ? job.applicants.length : 0} applicants</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClass(job.isActive)}`}>
                            {job.isActive ? 'Active' : 'Closed'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default Jobs;