import React, { useState, useEffect } from 'react';
import { FiBarChart2, FiUsers, FiBriefcase, FiFileText, FiTrendingUp, FiCalendar, FiDownload, FiRefreshCw, FiPrinter } from 'react-icons/fi';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import AdminLayout from '../../components/admin/AdminLayout';
import { adminAPI } from '../../services/api';

const SystemReports = () => {
  const [reports, setReports] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastUpdated, setLastUpdated] = useState(new Date());

  useEffect(() => {
    const fetchReports = async () => {
      try {
        setLoading(true);
        const response = await adminAPI.getSystemReports();
        setReports(response.data);
        setError('');
        setLastUpdated(new Date());
      } catch (err) {
        console.error('Error fetching system reports:', err);
        setError('Failed to fetch system reports');
      } finally {
        setLoading(false);
      }
    };

    fetchReports();

    // Refresh reports every 30 seconds
    const interval = setInterval(fetchReports, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = async () => {
    try {
      setLoading(true);
      const response = await adminAPI.getSystemReports();
      setReports(response.data);
      setError('');
      setLastUpdated(new Date());
    } catch (err) {
      console.error('Error fetching system reports:', err);
      setError('Failed to fetch system reports');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const generatePDF = async () => {
    if (!reports) return;
    
    try {
      // Get the report content element
      const reportElement = document.querySelector('.report-content');
      
      if (!reportElement) {
        // Create a temporary element to capture the report data
        const tempDiv = document.createElement('div');
        tempDiv.className = 'p-6 bg-white';
        tempDiv.innerHTML = `
          <h1 class="text-2xl font-bold text-gray-900 mb-6">Growth Details (Last 30 Days)</h1>
          <table class="min-w-full border-collapse">
            <thead>
              <tr class="bg-gray-100">
                <th class="border px-4 py-2 text-left">Date</th>
                <th class="border px-4 py-2 text-left">Users</th>
                <th class="border px-4 py-2 text-left">Employers</th>
                <th class="border px-4 py-2 text-left">Job Seekers</th>
                <th class="border px-4 py-2 text-left">Jobs</th>
                <th class="border px-4 py-2 text-left">Applications</th>
              </tr>
            </thead>
            <tbody>
              ${reports.userGrowth.slice(-30).map((day, i) => {
                const jobDay = reports.jobGrowth.find(j => j._id === day._id) || { count: 0 };
                const appDay = reports.applicationGrowth.find(a => a._id === day._id) || { count: 0 };
                const dateObj = new Date(day._id);
                const formattedDate = `${String(dateObj.getDate()).padStart(2, '0')}/${String(dateObj.getMonth() + 1).padStart(2, '0')}/${dateObj.getFullYear()}`;
                return `
                  <tr class="${i % 2 === 0 ? 'bg-gray-50' : 'bg-white'}">
                    <td class="border px-4 py-2">${formatDate(day._id)}</td>
                    <td class="border px-4 py-2">${day.count}</td>
                    <td class="border px-4 py-2">${day.employers}</td>
                    <td class="border px-4 py-2">${day.jobSeekers}</td>
                    <td class="border px-4 py-2">${jobDay.count}</td>
                    <td class="border px-4 py-2">${appDay.count}</td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
        `;
        document.body.appendChild(tempDiv);
        
        // Use html2canvas to capture the content
        const canvas = await html2canvas(tempDiv);
        document.body.removeChild(tempDiv);
        
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const imgWidth = 210; // A4 width in mm
        const pageHeight = 297; // A4 height in mm
        const imgHeight = canvas.height * imgWidth / canvas.width;
        let heightLeft = imgHeight;
        let position = 0;
        
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
        
        // Add additional pages if content is longer
        while (heightLeft >= 0) {
          position = heightLeft - imgHeight;
          pdf.addPage();
          pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;
        }
        
        pdf.save(`system-reports-${new Date().toISOString().split('T')[0]}.pdf`);
      }
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Error generating PDF. Please try again.');
    }
  };

  if (loading && !reports) {
    return (
      <AdminLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
            </div>
          </div>
        </div>
      </AdminLayout>
    );
  }

  if (error && !reports) {
    return (
      <AdminLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            <div className="bg-red-50 border border-red-200 rounded-lg p-6">
              <p className="text-red-800">{error}</p>
            </div>
          </div>
        </div>
      </AdminLayout>
    );
  }

  if (!reports) {
    return (
      <AdminLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6">
              <p className="text-yellow-800">No reports data available.</p>
            </div>
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">System Reports</h1>
              <p className="mt-1 text-sm text-gray-500">Analytics and insights for the platform</p>
            </div>
            <div className="flex items-center space-x-3">
              <div className="text-xs text-gray-500">
                Last updated: {lastUpdated.toLocaleTimeString()}
              </div>
              <button
                onClick={handleRefresh}
                disabled={loading}
                className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-all duration-200 disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <FiRefreshCw className="mr-1 h-3 w-3 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <FiRefreshCw className="mr-1 h-3 w-3" />
                    Refresh
                  </>
                )}
              </button>
              <button
                onClick={generatePDF}
                className="inline-flex items-center px-4 py-1.5 border border-gray-300 shadow-sm text-xs font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-all duration-200"
              >
                <FiPrinter className="mr-1 h-3 w-3" />
                Export PDF
              </button>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mb-8">
            <div className="bg-white overflow-hidden rounded-2xl shadow-lg border border-gray-100 p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-12 w-12 rounded-xl bg-blue-100 flex items-center justify-center shadow-md">
                  <FiUsers className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Total Users</p>
                  <p className="text-2xl font-bold text-gray-900">{reports.totals.totalUsers}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white overflow-hidden rounded-2xl shadow-lg border border-gray-100 p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-12 w-12 rounded-xl bg-green-100 flex items-center justify-center shadow-md">
                  <FiBriefcase className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Total Jobs</p>
                  <p className="text-2xl font-bold text-gray-900">{reports.totals.totalJobs}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white overflow-hidden rounded-2xl shadow-lg border border-gray-100 p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-12 w-12 rounded-xl bg-purple-100 flex items-center justify-center shadow-md">
                  <FiFileText className="h-6 w-6 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Total Applications</p>
                  <p className="text-2xl font-bold text-gray-900">{reports.totals.totalApplications}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white overflow-hidden rounded-2xl shadow-lg border border-gray-100 p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-12 w-12 rounded-xl bg-yellow-100 flex items-center justify-center shadow-md">
                  <FiBarChart2 className="h-6 w-6 text-yellow-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">Active Jobs</p>
                  <p className="text-2xl font-bold text-gray-900">{reports.totals.activeJobs}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Weekly Stats */}
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-3 mb-8">
            <div className="bg-white overflow-hidden rounded-2xl shadow-lg border border-gray-100 p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10 rounded-lg bg-blue-500 flex items-center justify-center">
                  <FiUsers className="h-5 w-5 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">New Registrations (7d)</p>
                  <p className="text-xl font-bold text-gray-900">{reports.weeklyStats.newUserRegistrations}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white overflow-hidden rounded-2xl shadow-lg border border-gray-100 p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10 rounded-lg bg-green-500 flex items-center justify-center">
                  <FiBriefcase className="h-5 w-5 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">New Job Posts (7d)</p>
                  <p className="text-xl font-bold text-gray-900">{reports.weeklyStats.newJobPosts}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white overflow-hidden rounded-2xl shadow-lg border border-gray-100 p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 h-10 w-10 rounded-lg bg-purple-500 flex items-center justify-center">
                  <FiFileText className="h-5 w-5 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">New Applications (7d)</p>
                  <p className="text-xl font-bold text-gray-900">{reports.weeklyStats.newApplications}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Growth Charts */}
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-3 mb-8">
            {/* User Growth */}
            <div className="bg-white shadow overflow-hidden rounded-2xl p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                <FiUsers className="mr-2 h-5 w-5 text-blue-600" />
                User Growth (Last 30 Days)
              </h3>
              <div className="space-y-4">
                {reports.userGrowth.slice(-7).map((day, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">{formatDate(day._id)}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ width: `${Math.min(100, (day.count / Math.max(1, Math.max(...reports.userGrowth.map(u => u.count)))) * 100)}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium text-gray-900 w-8">{day.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Job Growth */}
            <div className="bg-white shadow overflow-hidden rounded-2xl p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                <FiBriefcase className="mr-2 h-5 w-5 text-green-600" />
                Job Posts (Last 30 Days)
              </h3>
              <div className="space-y-4">
                {reports.jobGrowth.slice(-7).map((day, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">{formatDate(day._id)}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-600 h-2 rounded-full" 
                          style={{ width: `${Math.min(100, (day.count / Math.max(1, Math.max(...reports.jobGrowth.map(j => j.count)))) * 100)}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium text-gray-900 w-8">{day.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Application Growth */}
            <div className="bg-white shadow overflow-hidden rounded-2xl p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                <FiFileText className="mr-2 h-5 w-5 text-purple-600" />
                Applications (Last 30 Days)
              </h3>
              <div className="space-y-4">
                {reports.applicationGrowth.slice(-7).map((day, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">{formatDate(day._id)}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-purple-600 h-2 rounded-full" 
                          style={{ width: `${Math.min(100, (day.count / Math.max(1, Math.max(...reports.applicationGrowth.map(a => a.count)))) * 100)}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium text-gray-900 w-8">{day.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Detailed Growth Data */}
          <div className="bg-white shadow overflow-hidden rounded-2xl">
            <div className="px-6 py-5 border-b border-gray-100 flex justify-between items-center">
              <h3 className="text-lg font-bold text-gray-900">Growth Details (Last 30 Days)</h3>
              <div className="text-xs text-gray-500">Auto-refreshes every 30 seconds</div>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">New Users</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">New Employers</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">New Job Seekers</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">New Jobs</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">New Applications</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {reports.userGrowth.slice(-10).reverse().map((day, index) => {
                    const jobDay = reports.jobGrowth.find(j => j._id === day._id) || { count: 0 };
                    const appDay = reports.applicationGrowth.find(a => a._id === day._id) || { count: 0 };
                    
                    return (
                      <tr key={index}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{formatDate(day._id)}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{day.count}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{day.employers}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{day.jobSeekers}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{jobDay.count}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{appDay.count}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default SystemReports;