import React, { useState, useEffect } from 'react';
import { FiUsers, FiBriefcase, FiFileText, FiActivity, FiRefreshCw, FiUser, FiCheckCircle } from 'react-icons/fi';
import AdminLayout from '../../components/admin/AdminLayout';
import { adminAPI } from '../../services/api';

const AllActivities = () => {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const itemsPerPage = 20; // Number of activities per page

  useEffect(() => {
    fetchActivities();
  }, [currentPage]);

  // Ensure we always have a loading state transition
  useEffect(() => {
    if (loading && activities.length === 0) {
      // Loading state is handled by the loading indicator
    }
  }, [loading, activities.length]);

  const fetchActivities = async () => {
    try {
      setLoading(true);
      setError('');
      
      // Get all activities by fetching more data than the dashboard shows
      const response = await adminAPI.getRecentActivities();
      
      // Handle API response - check if data exists and is an array
      let activitiesData = [];
      if (response && response.data) {
        activitiesData = Array.isArray(response.data) ? response.data : [];
      } else {
        // Fallback: if response.data doesn't exist, the data might be directly in response
        activitiesData = Array.isArray(response) ? response : [];
      }
      
      setActivities(activitiesData);
    } catch (err) {
      console.error('Error fetching activities:', err);
      setError('Failed to fetch activities');
      setActivities([]); // Ensure activities is reset on error
    } finally {
      setLoading(false);
    }
  };

  // Function to get icon based on activity type
  const getActivityIcon = (type) => {
    switch (type) {
      case 'user_registration':
        return <FiUser className="h-6 w-6 text-green-600" />;
      case 'job_posted':
        return <FiBriefcase className="h-6 w-6 text-blue-600" />;
      case 'application_submitted':
        return <FiFileText className="h-6 w-6 text-purple-600" />;
      default:
        return <FiActivity className="h-6 w-6 text-gray-600" />;
    }
  };

  // Function to get color class based on activity type
  const getActivityColor = (type) => {
    switch (type) {
      case 'user_registration':
        return 'bg-gradient-to-br from-green-100 to-green-200';
      case 'job_posted':
        return 'bg-gradient-to-br from-blue-100 to-blue-200';
      case 'application_submitted':
        return 'bg-gradient-to-br from-purple-100 to-purple-200';
      default:
        return 'bg-gradient-to-br from-gray-100 to-gray-200';
    }
  };

  // Function to format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading && activities.length === 0) {
    return (
      <AdminLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
            </div>
          </div>
        </div>
      </AdminLayout>
    );
  }

  if (error && activities.length === 0) {
    return (
      <AdminLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            <div className="bg-red-50 border border-red-200 rounded-lg p-6">
              <p className="text-red-800">{error}</p>
              <button
                onClick={fetchActivities}
                className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700"
              >
                <FiRefreshCw className="mr-2 h-4 w-4" />
                Retry
              </button>
            </div>
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">All Recent Activities</h1>
              <p className="mt-1 text-sm text-gray-500">Complete activity log for the platform</p>
            </div>
            <button
              onClick={fetchActivities}
              disabled={loading}
              className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-all duration-200 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <FiRefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Loading...
                </>
              ) : (
                <>
                  <FiRefreshCw className="mr-2 h-4 w-4" />
                  Refresh
                </>
              )}
            </button>
          </div>

          <div className="bg-white shadow overflow-hidden rounded-2xl">
            <div className="px-6 py-5 border-b border-gray-100">
              <h3 className="text-lg font-bold text-gray-900">Activity Feed</h3>
              <p className="text-sm text-gray-500 mt-1">Showing {activities.length} most recent activities</p>
            </div>
            
            {loading && activities.length > 0 ? (
              <div className="px-6 py-4 border-b border-gray-100 flex justify-center">
                <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-primary-600"></div>
              </div>
            ) : null}
            
            <div className="overflow-x-auto">
              <ul className="divide-y divide-gray-100">
                {activities.length === 0 ? (
                  <li className="py-12 text-center">
                    <FiActivity className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-lg font-medium text-gray-900">No activities</h3>
                    <p className="mt-1 text-gray-500">No recent activities to display.</p>
                  </li>
                ) : (
                  activities.map((activity, index) => (
                    <li key={index} className="py-4 px-6 hover:bg-gray-50 transition-colors duration-150">
                      <div className="flex items-center space-x-4">
                        <div className="flex-shrink-0">
                          <div className={`h-12 w-12 rounded-xl flex items-center justify-center shadow-md ${getActivityColor(activity.type)}`}>
                            {getActivityIcon(activity.type)}
                          </div>
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-base font-bold text-gray-900 truncate">{activity.title}</p>
                          <p className="text-sm text-gray-600 truncate">{activity.description}</p>
                          <div className="mt-1 flex items-center">
                            <span className="text-xs text-gray-500">{formatDate(activity.timestamp)}</span>
                            {activity.user && (
                              <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                {activity.user.role}
                              </span>
                            )}
                            {activity.job && (
                              <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                Job
                              </span>
                            )}
                            {activity.application && (
                              <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                Application
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </li>
                  ))
                )}
              </ul>
            </div>
            
            {/* Pagination would go here if we had more data */}
            {activities.length > 0 && (
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-gray-700">
                    Showing <span className="font-medium">1</span> to <span className="font-medium">{activities.length}</span> of{' '}
                    <span className="font-medium">{activities.length}</span> activities
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1}
                      className="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50"
                    >
                      Previous
                    </button>
                    <button
                      onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                      disabled={currentPage === totalPages}
                      className="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50"
                    >
                      Next
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AllActivities;