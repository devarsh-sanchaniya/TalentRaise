import React, { useState, useEffect } from 'react';
import { FiUsers, FiBriefcase, FiFileText, FiBarChart2, FiUserCheck, FiUserPlus, FiDollarSign, FiTrendingUp, FiActivity, FiMail, FiUser, FiCheckCircle, FiClipboard, FiChevronRight } from 'react-icons/fi';
import AdminLayout from '../../components/admin/AdminLayout';
import { adminAPI } from '../../services/api';
import { messagesAPI } from '../../services/api';
import { Link, useNavigate } from 'react-router-dom';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalJobs: 0,
    totalApplications: 0,
    activeJobs: 0,
    totalEmployers: 0,
    totalJobSeekers: 0
  });
  const [recentActivity, setRecentActivity] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activityLoading, setActivityLoading] = useState(true);
  const [unreadMessageCount, setUnreadMessageCount] = useState(0);
  const navigate = useNavigate();

  // Fetch real admin statistics
  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await adminAPI.getStats();
        setStats(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching admin stats:', error);
        // Fallback to mock data if API call fails
        setStats({
          totalUsers: 0,
          totalJobs: 0,
          totalApplications: 0,
          activeJobs: 0,
          totalEmployers: 0,
          totalJobSeekers: 0
        });
        setLoading(false);
      }
    };

    fetchStats();
    
    // Refresh stats every 30 seconds
    const interval = setInterval(fetchStats, 30000);
    return () => clearInterval(interval);
  }, []);

  // Fetch recent activities
  useEffect(() => {
    const fetchRecentActivities = async () => {
      try {
        const response = await adminAPI.getRecentActivities();
        setRecentActivity(response.data);
        setActivityLoading(false);
      } catch (error) {
        console.error('Error fetching recent activities:', error);
        // Fallback to empty array if API call fails
        setRecentActivity([]);
        setActivityLoading(false);
      }
    };

    fetchRecentActivities();
    
    // Refresh activities every 30 seconds
    const interval = setInterval(fetchRecentActivities, 30000);
    return () => clearInterval(interval);
  }, []);

  // Fetch unread message count
  useEffect(() => {
    const fetchMessageCount = async () => {
      try {
        const response = await messagesAPI.getMessageCount();
        setUnreadMessageCount(response.data.count);
      } catch (error) {
        console.error('Error fetching message count:', error);
      }
    };

    fetchMessageCount();
    
    // Refresh every 30 seconds
    const interval = setInterval(fetchMessageCount, 30000);
    return () => clearInterval(interval);
  }, []);

  // Function to get icon based on activity type
  const getActivityIcon = (type) => {
    switch (type) {
      case 'user_registration':
        return <FiUser className="h-6 w-6 text-green-600" />;
      case 'job_posted':
        return <FiBriefcase className="h-6 w-6 text-blue-600" />;
      case 'application_submitted':
        return <FiFileText className="h-6 w-6 text-purple-600" />;
      default:
        return <FiActivity className="h-6 w-6 text-gray-600" />;
    }
  };

  // Function to get color class based on activity type
  const getActivityColor = (type) => {
    switch (type) {
      case 'user_registration':
        return 'bg-gradient-to-br from-green-100 to-green-200';
      case 'job_posted':
        return 'bg-gradient-to-br from-blue-100 to-blue-200';
      case 'application_submitted':
        return 'bg-gradient-to-br from-purple-100 to-purple-200';
      default:
        return 'bg-gradient-to-br from-gray-100 to-gray-200';
    }
  };

  // Function to format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now - date) / 1000);

    if (diffInSeconds < 60) {
      return 'Just now';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes}m ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours}h ago`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days}d ago`;
    }
  };

  // Stat cards data
  const statCards = [
    {
      title: 'Total Users',
      value: stats.totalUsers,
      icon: <FiUsers className="h-6 w-6 text-primary-600" />,
      color: 'bg-primary-100',
      description: 'Registered users'
    },
    {
      title: 'Employers',
      value: stats.totalEmployers,
      icon: <FiUserCheck className="h-6 w-6 text-blue-600" />,
      color: 'bg-blue-100',
      description: 'Active employers'
    },
    {
      title: 'Job Seekers',
      value: stats.totalJobSeekers,
      icon: <FiUserPlus className="h-6 w-6 text-purple-600" />,
      color: 'bg-purple-100',
      description: 'Active job seekers'
    },
    {
      title: 'Total Jobs',
      value: stats.totalJobs,
      icon: <FiBriefcase className="h-6 w-6 text-primary-600" />,
      color: 'bg-primary-100',
      description: 'Posted jobs'
    },
    {
      title: 'Applications',
      value: stats.totalApplications,
      icon: <FiFileText className="h-6 w-6 text-primary-600" />,
      color: 'bg-primary-100',
      description: 'Submitted applications'
    },
    {
      title: 'Active Jobs',
      value: stats.activeJobs,
      icon: <FiBarChart2 className="h-6 w-6 text-primary-600" />,
      color: 'bg-primary-100',
      description: 'Currently available'
    }
  ];

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          {loading && (
            <div className="flex justify-center items-center h-32">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
            </div>
          )}
          {!loading && (
            /* Stats cards */
            <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {statCards.map((card, index) => (
                <div key={index} className="bg-white overflow-hidden rounded-2xl shadow-lg border border-gray-100 transform transition-all duration-300 hover:scale-[1.02] hover:shadow-xl">
                  <div className="px-6 py-6 sm:p-6">
                    <div className="flex items-center">
                      <div className={`flex-shrink-0 ${card.color} rounded-xl p-4 shadow-md`}>
                        {card.icon}
                      </div>
                      <div className="ml-6 w-0 flex-1">
                        <dl>
                          <dt className="text-base font-medium text-gray-500 truncate">{card.title}</dt>
                          <dd className="flex items-baseline">
                            <div className="text-3xl font-bold text-gray-900">{card.value}</div>
                          </dd>
                          <dd className="text-sm text-gray-500 mt-1">{card.description}</dd>
                        </dl>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {!loading && (
            <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-2">
              {/* Recent Activity */}
              <div className="bg-white shadow overflow-hidden rounded-2xl">
                <div className="px-6 py-5 sm:px-6 border-b border-gray-100">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl leading-6 font-bold text-gray-900">Recent Activity</h3>
                      <p className="mt-1 max-w-2xl text-sm text-gray-500">Latest actions on the platform</p>
                    </div>
                    <div className="bg-gradient-to-r from-primary-100 to-secondary-100 rounded-full px-3 py-1">
                      <span className="text-primary-800 font-bold text-sm">LIVE</span>
                    </div>
                  </div>
                </div>
                <div className="px-6 py-5">
                  <div className="flow-root">
                    <ul className="divide-y divide-gray-100">
                      {activityLoading ? (
                        <li className="py-8 text-center">
                          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary-600 mx-auto"></div>
                          <p className="mt-2 text-sm text-gray-500">Loading recent activities...</p>
                        </li>
                      ) : recentActivity.length === 0 ? (
                        <li className="py-8 text-center">
                          <FiActivity className="h-12 w-12 text-gray-400 mx-auto" />
                          <p className="mt-2 text-sm text-gray-500">No recent activities</p>
                        </li>
                      ) : (
                        recentActivity.slice(0, 5).map((activity, index) => (  // Show only first 5 activities on dashboard
                          <li key={index} className="py-4">
                            <div className="flex items-center space-x-4">
                              <div className="flex-shrink-0">
                                <div className={`h-12 w-12 rounded-xl flex items-center justify-center shadow-md ${getActivityColor(activity.type)}`}>
                                  {getActivityIcon(activity.type)}
                                </div>
                              </div>
                              <div className="min-w-0 flex-1">
                                <p className="text-base font-bold text-gray-900 truncate">{activity.title}</p>
                                <p className="text-sm text-gray-600 truncate">{activity.description}</p>
                              </div>
                              <div>
                                <p className="text-sm text-gray-500 font-medium">{formatDate(activity.timestamp)}</p>
                              </div>
                            </div>
                          </li>
                        ))
                      )}
                    </ul>
                  </div>
                  <div className="mt-6 text-center">
                    <Link 
                      to="/admin/activity" 
                      className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-lg text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-all duration-300"
                    >
                      View All Activity
                      <FiChevronRight className="ml-2 h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </div>

              {/* System Overview */}
              <div className="bg-white shadow overflow-hidden rounded-2xl">
                <div className="px-6 py-5 sm:px-6 border-b border-gray-100">
                  <h3 className="text-xl leading-6 font-bold text-gray-900">System Overview</h3>
                  <p className="mt-1 max-w-2xl text-sm text-gray-500">Platform performance metrics</p>
                </div>
                <div className="px-6 py-5">
                  <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                    <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-5 rounded-xl border border-blue-100">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-lg bg-blue-500 flex items-center justify-center">
                          <FiTrendingUp className="h-5 w-5 text-white" />
                        </div>
                        <h4 className="ml-3 text-base font-bold text-blue-900">Employer Growth</h4>
                      </div>
                      <p className="mt-3 text-sm text-blue-800">
                        +5% increase in employer registrations this month
                      </p>
                    </div>
                    <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-5 rounded-xl border border-purple-100">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-lg bg-purple-500 flex items-center justify-center">
                          <FiUserPlus className="h-5 w-5 text-white" />
                        </div>
                        <h4 className="ml-3 text-base font-bold text-purple-900">Job Seeker Engagement</h4>
                      </div>
                      <p className="mt-3 text-sm text-purple-800">
                        +15% increase in job applications this week
                      </p>
                    </div>
                    <div className="bg-gradient-to-br from-green-50 to-green-100 p-5 rounded-xl border border-green-100">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-lg bg-green-500 flex items-center justify-center">
                          <FiDollarSign className="h-5 w-5 text-white" />
                        </div>
                        <h4 className="ml-3 text-base font-bold text-green-900">Platform Activity</h4>
                      </div>
                      <p className="mt-3 text-sm text-green-800">
                        {stats.activeJobs} active jobs currently available to job seekers
                      </p>
                    </div>
                    <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-5 rounded-xl border border-yellow-100">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-lg bg-yellow-500 flex items-center justify-center">
                          <FiActivity className="h-5 w-5 text-white" />
                        </div>
                        <h4 className="ml-3 text-base font-bold text-yellow-900">System Health</h4>
                      </div>
                      <p className="mt-3 text-sm text-yellow-800">
                        All systems operational - 99.9% uptime
                      </p>
                    </div>
                  </div>
                  
                  <div className="mt-8">
                    <h4 className="text-base font-bold text-gray-900 mb-4">Quick Actions</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <Link to="/admin/users" className="inline-flex items-center justify-center px-4 py-3 border border-gray-300 shadow-sm text-sm font-bold rounded-xl text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-all duration-300 transform hover:scale-[1.02]">
                        View All Users
                      </Link>
                      <Link to="/admin/jobs" className="inline-flex items-center justify-center px-4 py-3 border border-gray-300 shadow-sm text-sm font-bold rounded-xl text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-all duration-300 transform hover:scale-[1.02]">
                        Manage Jobs
                      </Link>
                      <Link to="/admin/applications" className="inline-flex items-center justify-center px-4 py-3 border border-gray-300 shadow-sm text-sm font-bold rounded-xl text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-all duration-300 transform hover:scale-[1.02]">
                        Review Applications
                      </Link>
                      <Link to="/admin/reports" className="inline-flex items-center justify-center px-4 py-3 border border-gray-300 shadow-sm text-sm font-bold rounded-xl text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-all duration-300 transform hover:scale-[1.02]">
                        System Reports
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Floating Message Button */}
      <div className="fixed bottom-6 right-6 z-10">
        <Link 
          to="/admin/messages"
          className="relative inline-flex items-center justify-center p-4 bg-blue-600 text-white rounded-full shadow-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200 transform hover:scale-105"
        >
          <FiMail className="h-6 w-6" />
          {unreadMessageCount > 0 && (
            <span className="absolute -top-2 -right-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
              {unreadMessageCount}
            </span>
          )}
        </Link>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboard;