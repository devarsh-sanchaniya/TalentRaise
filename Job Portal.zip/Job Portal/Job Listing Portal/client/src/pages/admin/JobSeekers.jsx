import React, { useState, useEffect } from 'react';
import { FiSearch, FiFilter, FiEye, FiTrash2, FiUser, FiFileText, FiCheck, FiX, FiEdit } from 'react-icons/fi';
import AdminLayout from '../../components/admin/AdminLayout';
import { adminAPI } from '../../services/api';

const JobSeekers = () => {
  const [jobSeekers, setJobSeekers] = useState([]);
  const [filteredJobSeekers, setFilteredJobSeekers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [editingJobSeeker, setEditingJobSeeker] = useState(null);
  const [editFormData, setEditFormData] = useState({});

  // Fetch real job seekers
  useEffect(() => {
    const fetchJobSeekers = async () => {
      try {
        setLoading(true);
        const response = await adminAPI.getAllUsers();
        // Filter only job seekers
        const jobSeekerList = response.data.filter(user => user.role === 'jobseeker');
        setJobSeekers(jobSeekerList);
        setFilteredJobSeekers(jobSeekerList);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching job seekers:', error);
        setLoading(false);
        setJobSeekers([]);
        setFilteredJobSeekers([]);
      }
    };

    fetchJobSeekers();
  }, []);

  // Filter job seekers based on search term
  useEffect(() => {
    let result = jobSeekers;
    
    if (searchTerm) {
      result = result.filter(jobSeeker => 
        (jobSeeker.name && jobSeeker.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (jobSeeker.email && jobSeeker.email.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    setFilteredJobSeekers(result);
  }, [searchTerm, jobSeekers]);

  const handleDeleteJobSeeker = async (jobSeekerId) => {
    if (window.confirm('Are you sure you want to delete this job seeker? This will also delete all their applications.')) {
      try {
        await adminAPI.deleteUser(jobSeekerId);
        setJobSeekers(jobSeekers.filter(jobSeeker => jobSeeker._id !== jobSeekerId));
        setFilteredJobSeekers(filteredJobSeekers.filter(jobSeeker => jobSeeker._id !== jobSeekerId));
        alert('Job seeker deleted successfully');
      } catch (error) {
        console.error('Error deleting job seeker:', error);
        alert('Error deleting job seeker. Please try again.');
      }
    }
  };

  const handleBlockJobSeeker = async (jobSeekerId) => {
    try {
      const response = await adminAPI.blockUser(jobSeekerId);
      // Update the job seeker in the state
      setJobSeekers(jobSeekers.map(jobSeeker => 
        jobSeeker._id === jobSeekerId ? {...jobSeeker, isActive: !jobSeeker.isActive} : jobSeeker
      ));
      setFilteredJobSeekers(filteredJobSeekers.map(jobSeeker => 
        jobSeeker._id === jobSeekerId ? {...jobSeeker, isActive: !jobSeeker.isActive} : jobSeeker
      ));
      alert(response.data.message);
    } catch (error) {
      console.error('Error blocking job seeker:', error);
      alert('Error updating job seeker status. Please try again.');
    }
  };

  const getStatusClass = (status) => {
    return status === 'active' 
      ? 'bg-green-100 text-green-800' 
      : 'bg-red-100 text-red-800';
  };

  const getActivityStatusClass = (isOnline) => {
    return isOnline 
      ? 'bg-green-100 text-green-800' 
      : 'bg-gray-100 text-gray-800';
  };

  const startEditing = (jobSeeker) => {
    setEditingJobSeeker(jobSeeker._id);
    setEditFormData({
      name: jobSeeker.name,
      email: jobSeeker.email
    });
  };

  const cancelEditing = () => {
    setEditingJobSeeker(null);
    setEditFormData({});
  };

  const saveJobSeeker = async (jobSeekerId) => {
    try {
      const userData = {
        name: editFormData.name,
        email: editFormData.email
      };
      const response = await adminAPI.updateUser(jobSeekerId, userData);
      // Update the job seeker in the state
      setJobSeekers(jobSeekers.map(jobSeeker => 
        jobSeeker._id === jobSeekerId ? response.data : jobSeeker
      ));
      setFilteredJobSeekers(filteredJobSeekers.map(jobSeeker => 
        jobSeeker._id === jobSeekerId ? response.data : jobSeeker
      ));
      setEditingJobSeeker(null);
      alert('Job seeker updated successfully');
    } catch (error) {
      console.error('Error updating job seeker:', error);
      alert('Error updating job seeker. Please try again.');
    }
  };

  const handleInputChange = (e) => {
    setEditFormData({
      ...editFormData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Job Seeker Management</h1>
        </div>
        <div className="mt-8">
          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            {/* Filters and search */}
            <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiSearch className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="text"
                      className="focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                      placeholder="Search job seekers..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>
            
            {/* Job Seekers table */}
            <div className="overflow-x-auto">
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
                </div>
              ) : filteredJobSeekers.length === 0 ? (
                <div className="text-center py-12">
                  <FiUser className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-2 text-sm font-medium text-gray-900">No job seekers found</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Try adjusting your search criteria.
                  </p>
                </div>
              ) : (
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Job Seeker
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Applications
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Joined
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Activity
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredJobSeekers.map((jobSeeker) => (
                      <tr key={jobSeeker._id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          {editingJobSeeker === jobSeeker._id ? (
                            <div className="flex flex-col space-y-2">
                              <input
                                type="text"
                                name="name"
                                value={editFormData.name}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Name"
                              />
                              <input
                                type="email"
                                name="email"
                                value={editFormData.email}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Email"
                              />
                            </div>
                          ) : (
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-10 w-10">
                                {jobSeeker.profile?.avatar ? (
                                  <img 
                                    src={`http://localhost:5000${jobSeeker.profile.avatar}`} 
                                    alt={jobSeeker.name} 
                                    className="h-10 w-10 rounded-full object-cover"
                                  />
                                ) : (
                                  <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                    <FiUser className="h-6 w-6 text-gray-500" />
                                  </div>
                                )}
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{jobSeeker.name}</div>
                                <div className="text-sm text-gray-500">{jobSeeker.email}</div>
                              </div>
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <div className="flex items-center">
                            <FiFileText className="h-4 w-4 mr-1" />
                            <span>{jobSeeker.applicationsCount || 0} applications</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(jobSeeker.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getActivityStatusClass(jobSeeker.isActive)}`}>
                            {jobSeeker.isActive ? 'Online' : 'Offline'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default JobSeekers;