import React, { useState, useEffect } from 'react';
import { FiSearch, FiFilter, FiEye, FiTrash2, FiUser, FiBriefcase, FiCheck, FiX, FiEdit } from 'react-icons/fi';
import AdminLayout from '../../components/admin/AdminLayout';
import { adminAPI } from '../../services/api';

const Employers = () => {
  const [employers, setEmployers] = useState([]);
  const [filteredEmployers, setFilteredEmployers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [editingEmployer, setEditingEmployer] = useState(null);
  const [editFormData, setEditFormData] = useState({});

  // Fetch real employers
  useEffect(() => {
    const fetchEmployers = async () => {
      try {
        setLoading(true);
        const response = await adminAPI.getAllUsers();
        // Filter only employers
        const employerList = response.data.filter(user => user.role === 'employer');
        setEmployers(employerList);
        setFilteredEmployers(employerList);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching employers:', error);
        setLoading(false);
        setEmployers([]);
        setFilteredEmployers([]);
      }
    };

    fetchEmployers();
  }, []);

  // Filter employers based on search term
  useEffect(() => {
    let result = employers;
    
    if (searchTerm) {
      result = result.filter(employer => 
        (employer.name && employer.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (employer.email && employer.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (employer.company && employer.company.name && employer.company.name.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    setFilteredEmployers(result);
  }, [searchTerm, employers]);

  const handleDeleteEmployer = async (employerId) => {
    if (window.confirm('Are you sure you want to delete this employer? This will also delete all their jobs and applications.')) {
      try {
        await adminAPI.deleteUser(employerId);
        setEmployers(employers.filter(employer => employer._id !== employerId));
        setFilteredEmployers(filteredEmployers.filter(employer => employer._id !== employerId));
        alert('Employer deleted successfully');
      } catch (error) {
        console.error('Error deleting employer:', error);
        alert('Error deleting employer. Please try again.');
      }
    }
  };

  const handleBlockEmployer = async (employerId) => {
    try {
      const response = await adminAPI.blockUser(employerId);
      // Update the employer in the state
      setEmployers(employers.map(employer => 
        employer._id === employerId ? {...employer, isActive: !employer.isActive} : employer
      ));
      setFilteredEmployers(filteredEmployers.map(employer => 
        employer._id === employerId ? {...employer, isActive: !employer.isActive} : employer
      ));
      alert(response.data.message);
    } catch (error) {
      console.error('Error blocking employer:', error);
      alert('Error updating employer status. Please try again.');
    }
  };

  const handleApproveCompany = async (employerId) => {
    try {
      const response = await adminAPI.approveCompany(employerId);
      // Update the employer in the state
      setEmployers(employers.map(employer => 
        employer._id === employerId ? response.data : employer
      ));
      setFilteredEmployers(filteredEmployers.map(employer => 
        employer._id === employerId ? response.data : employer
      ));
      alert('Company approved successfully');
    } catch (error) {
      console.error('Error approving company:', error);
      alert('Error approving company. Please try again.');
    }
  };

  const getStatusClass = (status) => {
    return status === 'active' 
      ? 'bg-green-100 text-green-800' 
      : 'bg-red-100 text-red-800';
  };

  const getActivityStatusClass = (isOnline) => {
    return isOnline 
      ? 'bg-green-100 text-green-800' 
      : 'bg-gray-100 text-gray-800';
  };

  const getApprovalClass = (isApproved) => {
    return isApproved 
      ? 'bg-green-100 text-green-800' 
      : 'bg-yellow-100 text-yellow-800';
  };

  const startEditing = (employer) => {
    setEditingEmployer(employer._id);
    setEditFormData({
      name: employer.name,
      email: employer.email,
      companyName: employer.company?.name || '',
      companyIndustry: employer.company?.industry || ''
    });
  };

  const cancelEditing = () => {
    setEditingEmployer(null);
    setEditFormData({});
  };

  const saveEmployer = async (employerId) => {
    try {
      const userData = {
        name: editFormData.name,
        email: editFormData.email,
        company: {
          name: editFormData.companyName,
          industry: editFormData.companyIndustry
        }
      };
      const response = await adminAPI.updateUser(employerId, userData);
      // Update the employer in the state
      setEmployers(employers.map(employer => 
        employer._id === employerId ? response.data : employer
      ));
      setFilteredEmployers(filteredEmployers.map(employer => 
        employer._id === employerId ? response.data : employer
      ));
      setEditingEmployer(null);
      alert('Employer updated successfully');
    } catch (error) {
      console.error('Error updating employer:', error);
      alert('Error updating employer. Please try again.');
    }
  };

  const handleInputChange = (e) => {
    setEditFormData({
      ...editFormData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Employer Management</h1>
        </div>
        <div className="mt-8">
          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            {/* Filters and search */}
            <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="relative rounded-md shadow-sm">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <FiSearch className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="text"
                      className="focus:ring-primary-500 focus:border-primary-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                      placeholder="Search employers..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </div>
            
            {/* Employers table */}
            <div className="overflow-x-auto">
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
                </div>
              ) : filteredEmployers.length === 0 ? (
                <div className="text-center py-12">
                  <FiUser className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-2 text-sm font-medium text-gray-900">No employers found</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Try adjusting your search criteria.
                  </p>
                </div>
              ) : (
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Employer
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Company
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Jobs Posted
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Joined
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Approval Status
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Activity
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredEmployers.map((employer) => (
                      <tr key={employer._id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          {editingEmployer === employer._id ? (
                            <div className="flex flex-col space-y-2">
                              <input
                                type="text"
                                name="name"
                                value={editFormData.name}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Name"
                              />
                              <input
                                type="email"
                                name="email"
                                value={editFormData.email}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Email"
                              />
                            </div>
                          ) : (
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-10 w-10">
                                {employer.profile?.avatar ? (
                                  <img 
                                    src={`http://localhost:5000${employer.profile.avatar}`} 
                                    alt={employer.name} 
                                    className="h-10 w-10 rounded-full object-cover"
                                  />
                                ) : (
                                  <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                                    <FiUser className="h-6 w-6 text-gray-500" />
                                  </div>
                                )}
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{employer.name}</div>
                                <div className="text-sm text-gray-500">{employer.email}</div>
                              </div>
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {editingEmployer === employer._id ? (
                            <div className="flex flex-col space-y-2">
                              <input
                                type="text"
                                name="companyName"
                                value={editFormData.companyName}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Company Name"
                              />
                              <input
                                type="text"
                                name="companyIndustry"
                                value={editFormData.companyIndustry}
                                onChange={handleInputChange}
                                className="focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                                placeholder="Industry"
                              />
                            </div>
                          ) : (
                            <div>
                              <div className="text-sm font-medium text-gray-900">
                                {employer.company?.name || 'N/A'}
                              </div>
                              <div className="text-sm text-gray-500">
                                {employer.company?.industry || 'N/A'}
                              </div>
                            </div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <div className="flex items-center">
                            <FiBriefcase className="h-4 w-4 mr-1" />
                            <span>{employer.jobsCount || 0} jobs</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(employer.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex flex-col">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getApprovalClass(employer.company?.isApproved)}`}>
                              {employer.company?.isApproved ? 'Approved' : 'Pending'}
                            </span>
                            {employer.company?.isApproved === false && (
                              <button
                                onClick={() => handleApproveCompany(employer._id)}
                                className="mt-1 inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                              >
                                Approve
                              </button>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getActivityStatusClass(employer.isActive)}`}>
                            {employer.isActive ? 'Online' : 'Offline'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default Employers;