import React, { useState, useRef, useEffect } from 'react';
import { FiUser, FiMail, FiPhone, FiMapPin, FiBriefcase, FiCamera, FiSave, FiX, FiTrash2 } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
  const { user, updateProfile, deleteProfile } = useAuth();
  const navigate = useNavigate();
  const [profileData, setProfileData] = useState({
    name: '',
    email: '',
    phone: '',
    location: '',
    bio: '',
    role: '',
    // Job seeker fields
    experience: '',
    skills: '',
    // Company fields for employers
    companyName: '',
    companyDescription: '',
    companyIndustry: '',
    companyWebsite: '',
    companyLocation: '',
    companySize: '',
    companyFounded: ''
  });

  const [profileImage, setProfileImage] = useState(null);
  const [previewImage, setPreviewImage] = useState(null);
  const fileInputRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  // Redirect to home page if user is not authenticated
  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
  }, [user, navigate]);

  useEffect(() => {
    if (user) {
      setProfileData({
        name: user.name || '',
        email: user.email || '',
        phone: user.profile?.phone || '',
        location: user.profile?.location || '',
        bio: user.profile?.bio || '',
        role: user.role || '',
        // Job seeker fields
        experience: (user.jobSeekerProfile?.experience && Array.isArray(user.jobSeekerProfile.experience) && user.jobSeekerProfile.experience[0]) ? user.jobSeekerProfile.experience[0].description || '' : user.jobSeekerProfile?.experience || '',
        skills: Array.isArray(user.jobSeekerProfile?.skills) ? user.jobSeekerProfile.skills.join(', ') : user.jobSeekerProfile?.skills || '',
        // Company fields for employers
        companyName: user.company?.name || '',
        companyDescription: user.company?.description || '',
        companyIndustry: user.company?.industry || '',
        companyWebsite: user.company?.website || '',
        companyLocation: user.company?.location || '',
        companySize: user.company?.size || '',
        companyFounded: user.company?.founded ? new Date(user.company.founded).getFullYear().toString() : ''
      });
      if (user.profile?.avatar) {
        setPreviewImage(`http://localhost:5000${user.profile.avatar}`);
      }
    }
  }, [user, user?.profile, user?.company]);

  // Update form when user profile data changes
  useEffect(() => {
    if (success && user) {
      setProfileData({
        name: user.name || '',
        email: user.email || '',
        phone: user.profile?.phone || '',
        location: user.profile?.location || '',
        bio: user.profile?.bio || '',
        role: user.role || '',
        // Job seeker fields
        experience: (user.jobSeekerProfile?.experience && Array.isArray(user.jobSeekerProfile.experience) && user.jobSeekerProfile.experience[0]) ? user.jobSeekerProfile.experience[0].description || '' : user.jobSeekerProfile?.experience || '',
        skills: Array.isArray(user.jobSeekerProfile?.skills) ? user.jobSeekerProfile.skills.join(', ') : user.jobSeekerProfile?.skills || '',
        // Company fields for employers
        companyName: user.company?.name || '',
        companyDescription: user.company?.description || '',
        companyIndustry: user.company?.industry || '',
        companyWebsite: user.company?.website || '',
        companyLocation: user.company?.location || '',
        companySize: user.company?.size || '',
        companyFounded: user.company?.founded ? new Date(user.company.founded).getFullYear().toString() : ''
      });
      if (user.profile?.avatar) {
        setPreviewImage(`http://localhost:5000${user.profile.avatar}`);
      }
    }
  }, [user, success]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfileData({ ...profileData, [name]: value });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setProfileImage(file);
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current.click();
  };

  const removeImage = () => {
    setProfileImage(null);
    setPreviewImage(user?.profile?.avatar ? `http://localhost:5000${user.profile.avatar}` : null);
    fileInputRef.current.value = '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');
    
    // Prepare form data for submission
    const formDataToSend = new FormData();
    formDataToSend.append('name', profileData.name);
    formDataToSend.append('email', profileData.email);
    formDataToSend.append('phone', profileData.phone);
    formDataToSend.append('location', profileData.location);
    formDataToSend.append('bio', profileData.bio);
    
    // Add job seeker fields
    if (profileData.role === 'jobseeker') {
      formDataToSend.append('profile[experience]', profileData.experience);
      formDataToSend.append('profile[skills]', profileData.skills);
    }
    
    // Add company data for employers
    if (profileData.role === 'employer') {
      formDataToSend.append('companyName', profileData.companyName);
      formDataToSend.append('companyDescription', profileData.companyDescription);
      formDataToSend.append('companyIndustry', profileData.companyIndustry);
      formDataToSend.append('companyWebsite', profileData.companyWebsite);
      formDataToSend.append('companyLocation', profileData.companyLocation);
      formDataToSend.append('companySize', profileData.companySize);
      if (profileData.companyFounded) {
        formDataToSend.append('companyFounded', profileData.companyFounded);
      }
    }
    
    if (profileImage) {
      formDataToSend.append('profileImage', profileImage);
    }
    
    try {
      const response = await updateProfile(formDataToSend);
      if (response.success) {
        setSuccess('Profile updated successfully!');
      } else {
        setError(response.message);
      }
    } catch (err) {
      setError('An error occurred while updating profile');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProfile = async () => {
    if (window.confirm('Are you sure you want to delete your profile? This action cannot be undone.')) {
      setDeleting(true);
      try {
        const response = await deleteProfile();
        if (response.success) {
          // User is automatically redirected to home page after deletion
        } else {
          setError(response.message);
        }
      } catch (err) {
        setError('An error occurred while deleting profile');
      } finally {
        setDeleting(false);
      }
    }
  };

  // Redirect to home if not authenticated
  if (!user) {
    return null; // Will be redirected by the useEffect above
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Profile Settings</h1>
        <p className="text-gray-600 mt-2">Manage your profile information and settings</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Picture Section */}
        <div className="lg:col-span-1">
          <div className="card p-6 h-full">
            <h2 className="text-xl font-bold text-gray-900 mb-6 pb-3 border-b border-gray-100">Profile Picture</h2>
            
            <div className="flex flex-col items-center">
              <div className="relative mb-8">
                <div 
                  className="w-32 h-32 rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 border-2 border-dashed border-primary-300 flex items-center justify-center cursor-pointer overflow-hidden mx-auto"
                  onClick={triggerFileSelect}
                >
                  {previewImage ? (
                    <img src={previewImage} alt="Preview" className="w-full h-full object-cover" />
                  ) : (
                    <div className="bg-white rounded-full p-3">
                      <FiUser className="h-10 w-10 text-primary-600" />
                    </div>
                  )}
                </div>
                
                <button
                  type="button"
                  className="absolute bottom-2 right-2 bg-primary-600 rounded-full p-2 text-white shadow-md hover:shadow-lg transition-all duration-300"
                  onClick={triggerFileSelect}
                >
                  <FiCamera className="h-4 w-4" />
                </button>
                
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageChange}
                />
              </div>
              
              <div className="w-full space-y-3">
                <button
                  type="button"
                  className="w-full btn-primary py-2.5 flex items-center justify-center"
                  onClick={triggerFileSelect}
                >
                  <FiCamera className="mr-2" /> Change Photo
                </button>
                
                <button
                  type="button"
                  className="w-full px-4 py-2.5 border border-gray-300 text-gray-700 font-medium rounded-lg transition duration-300 hover:bg-gray-50"
                  onClick={removeImage}
                >
                  <FiX className="mr-2" /> Remove Photo
                </button>
              </div>
            </div>
            
            <div className="mt-8 pt-4 border-t border-gray-100">
              <h3 className="text-lg font-bold text-gray-900 mb-3">Account Status</h3>
              <div className="flex items-center justify-between bg-green-50 p-3 rounded-lg border border-green-200">
                <div className="flex items-center">
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500 mr-2"></div>
                  <span className="font-medium text-gray-800">Active</span>
                </div>
                <span className="text-xs text-green-600 font-medium">Verified</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Profile Information Section */}
        <div className="lg:col-span-2">
          <div className="card p-6">
            <div className="flex justify-between items-center mb-6 pb-3 border-b border-gray-100">
              <h2 className="text-xl font-bold text-gray-900">Profile Information</h2>
              <div className="px-3 py-1 bg-primary-100 rounded-full">
                <span className="text-primary-800 font-bold text-xs uppercase">{profileData.role}</span>
              </div>
            </div>
            
            {error && (
              <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
                <div className="flex-shrink-0 mr-3">
                  <svg className="h-5 w-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div className="text-red-700">{error}</div>
              </div>
            )}
            
            {success && (
              <div className="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4">
                <div className="flex-shrink-0 mr-3">
                  <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div className="text-green-700">{success}</div>
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={profileData.name}
                    onChange={handleInputChange}
                    className="input-field"
                    required
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={profileData.email}
                    onChange={handleInputChange}
                    className="input-field"
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={profileData.phone}
                    onChange={handleInputChange}
                    className="input-field"
                  />
                </div>
                
                <div>
                  <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                    Location
                  </label>
                  <input
                    type="text"
                    id="location"
                    name="location"
                    value={profileData.location}
                    onChange={handleInputChange}
                    className="input-field"
                    placeholder="City, Country"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="bio" className="block text-sm font-medium text-gray-700 mb-1">
                    Bio
                  </label>
                  <textarea
                    id="bio"
                    name="bio"
                    rows={4}
                    value={profileData.bio}
                    onChange={handleInputChange}
                    className="input-field"
                    placeholder="Tell us about yourself..."
                  ></textarea>
                </div>
              </div>
              

              
              {/* Company Information for Employers */}
              {profileData.role === 'employer' && (
                <div className="mt-8 pt-6 border-t border-gray-200">
                  <h3 className="text-xl font-bold text-gray-900 mb-4 pb-2 border-b border-gray-100">Company Information</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="md:col-span-2">
                      <label htmlFor="companyName" className="block text-sm font-medium text-gray-700 mb-1">
                        Company Name *
                      </label>
                      <input
                        type="text"
                        id="companyName"
                        name="companyName"
                        value={profileData.companyName}
                        onChange={handleInputChange}
                        className="input-field"
                        required
                      />
                    </div>
                    
                    <div className="md:col-span-2">
                      <label htmlFor="companyDescription" className="block text-sm font-medium text-gray-700 mb-1">
                        Company Description
                      </label>
                      <textarea
                        id="companyDescription"
                        name="companyDescription"
                        rows={4}
                        value={profileData.companyDescription}
                        onChange={handleInputChange}
                        className="input-field"
                        placeholder="Describe your company..."
                      ></textarea>
                    </div>
                    
                    <div>
                      <label htmlFor="companyIndustry" className="block text-sm font-medium text-gray-700 mb-1">
                        Industry
                      </label>
                      <input
                        type="text"
                        id="companyIndustry"
                        name="companyIndustry"
                        value={profileData.companyIndustry}
                        onChange={handleInputChange}
                        className="input-field"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="companyWebsite" className="block text-sm font-medium text-gray-700 mb-1">
                        Website
                      </label>
                      <input
                        type="url"
                        id="companyWebsite"
                        name="companyWebsite"
                        value={profileData.companyWebsite}
                        onChange={handleInputChange}
                        className="input-field"
                        placeholder="https://example.com"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="companyLocation" className="block text-sm font-medium text-gray-700 mb-1">
                        Company Location
                      </label>
                      <input
                        type="text"
                        id="companyLocation"
                        name="companyLocation"
                        value={profileData.companyLocation}
                        onChange={handleInputChange}
                        className="input-field"
                        placeholder="City, Country"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="companySize" className="block text-sm font-medium text-gray-700 mb-1">
                        Company Size
                      </label>
                      <select
                        id="companySize"
                        name="companySize"
                        value={profileData.companySize}
                        onChange={handleInputChange}
                        className="input-field"
                      >
                        <option value="">Select size</option>
                        <option value="1-10">1-10 employees</option>
                        <option value="11-50">11-50 employees</option>
                        <option value="51-200">51-200 employees</option>
                        <option value="201-500">201-500 employees</option>
                        <option value="501-1000">501-1000 employees</option>
                        <option value="1000+">1000+ employees</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="companyFounded" className="block text-sm font-medium text-gray-700 mb-1">
                        Founded Year
                      </label>
                      <input
                        type="number"
                        id="companyFounded"
                        name="companyFounded"
                        min="1900"
                        max={new Date().getFullYear()}
                        value={profileData.companyFounded}
                        onChange={handleInputChange}
                        className="input-field"
                      />
                    </div>
                  </div>
                </div>
              )}
              
              <div className="mt-8 flex flex-col sm:flex-row sm:space-x-4 space-y-3 sm:space-y-0">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 btn-primary flex items-center justify-center"
                >
                  {loading ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Saving Changes...
                    </>
                  ) : (
                    <>
                      <FiSave className="mr-2" />
                      Save Changes
                    </>
                  )}
                </button>
                
                <button
                  type="button"
                  onClick={handleDeleteProfile}
                  disabled={deleting}
                  className="flex-1 px-6 py-3 border border-red-600 text-red-600 font-medium rounded-lg transition duration-300 hover:bg-red-50"
                >
                  {deleting ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-red-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Deleting...
                    </>
                  ) : (
                    <>
                      <FiTrash2 className="mr-2" />
                      Delete Profile
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;