import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { jobsAPI } from '../services/api';
import { applicationsAPI } from '../services/api';
import { FiUser, FiDownload, FiCheck, FiUsers, FiX, FiMail, FiClock, FiCalendar, FiFileText, FiSearch, FiFilter } from 'react-icons/fi';

const AllApplications = () => {
  const { user } = useAuth();
  const [jobs, setJobs] = useState([]);
  const [allApplications, setAllApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  // Format date as DD/MM/YYYY with zero-padding
  const formatAbsoluteDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  // Format the posted date to show relative time
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (diffMinutes < 60) {
      return `${diffMinutes} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else if (diffDays === 1) {
      return '1 day ago';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      const weeks = Math.floor(diffDays / 7);
      return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
    } else {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months > 1 ? 's' : ''} ago`;
    }
  };

  // Fetch jobs and all applications
  useEffect(() => {
    const fetchAllData = async () => {
      try {
        setLoading(true);
        setError('');
        
        if (user?.role === 'employer') {
          // Fetch employer's jobs
          const jobsRes = await jobsAPI.getJobsByUser();
          const userJobs = jobsRes.data || [];
          setJobs(userJobs);

          // Fetch all applications for all jobs
          let allApps = [];
          for (const job of userJobs) {
            try {
              const appRes = await applicationsAPI.getApplicationsByJob(job._id);
              const jobApps = appRes.data.map(app => ({
                ...app,
                jobTitle: job.title,
                jobCompany: job.company?.company?.name || job.company?.name || 'Your Company'
              }));
              allApps = [...allApps, ...jobApps];
            } catch (appErr) {
              console.error(`Error fetching applications for job ${job._id}:`, appErr);
            }
          }
          setAllApplications(allApps);
        }
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to fetch data');
        setAllApplications([]);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchAllData();
    }
  }, [user]);

  // Filter applications based on search term and status
  const filteredApplications = allApplications.filter(app => {
    const matchesSearch = searchTerm === '' ||
      app.applicant?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.applicant?.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.jobTitle?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.jobCompany?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = filterStatus === 'all' || 
      app.status.toLowerCase() === filterStatus.toLowerCase();

    return matchesSearch && matchesStatus;
  });

  // Update application status
  const updateApplicationStatus = async (applicationId, status, index) => {
    try {
      const res = await applicationsAPI.updateApplicationStatus(applicationId, { status });
      
      // Update the application in state
      setAllApplications(prev => 
        prev.map((app, idx) => 
          idx === index ? { ...app, status: res.data.status } : app
        )
      );
      
      alert('Application status updated successfully');
    } catch (err) {
      console.error('Error updating application status:', err);
      setError('Failed to update application status. Please try again.');
    }
  };

  // Download applicant resume
  const downloadResume = async (applicationId, applicantName) => {
    try {
      const res = await applicationsAPI.downloadResume(applicationId);
      
      // Create a blob URL and trigger download
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `resume-${applicantName || 'applicant'}.pdf`);
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error downloading resume:', err);
      // Show more specific error message
      if (err.response && err.response.status === 404) {
        setError('Resume file not found. The file may have been deleted or moved.');
      } else if (err.response && err.response.status === 401) {
        setError('You are not authorized to download this resume.');
      } else {
        setError('Failed to download resume. Please try again.');
      }
    }
  };

  if (!user) {
    return null; // Will be redirected by protection logic
  }

  if (loading) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative mb-4">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-8 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="mb-8">
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">All Applications</h1>
                <p className="text-gray-600 mt-2">Review and manage all applications received for your jobs</p>
              </div>
            </div>
          </div>
        </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl text-white shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center justify-center min-h-[120px]">
          <div className="text-2xl font-bold mb-1">{allApplications.length}</div>
          <div className="text-xs uppercase tracking-wide text-blue-100 text-center">Total Applications</div>
        </div>
        
        <div className="p-4 bg-gradient-to-br from-green-500 to-green-600 rounded-xl text-white shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center justify-center min-h-[120px]">
          <div className="text-2xl font-bold mb-1">{allApplications.filter(app => app.status.toLowerCase() === 'accepted').length}</div>
          <div className="text-xs uppercase tracking-wide text-green-100 text-center">Accepted</div>
        </div>
        
        <div className="p-4 bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl text-white shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center justify-center min-h-[120px]">
          <div className="text-2xl font-bold mb-1">{allApplications.filter(app => app.status.toLowerCase() === 'interview').length}</div>
          <div className="text-xs uppercase tracking-wide text-amber-100 text-center">In Interview</div>
        </div>
        
        <div className="p-4 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl text-white shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center justify-center min-h-[120px]">
          <div className="text-2xl font-bold mb-1">{allApplications.filter(app => app.status.toLowerCase() === 'pending').length}</div>
          <div className="text-xs uppercase tracking-wide text-purple-100 text-center">Pending</div>
        </div>
      </div>
      
      {/* Search and Filter Section */}
      <div className="mb-8">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-6 border-b border-gray-200 bg-gray-50">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Application Management</h3>
                <p className="text-gray-600 text-sm mt-1">Filter and review all job applications</p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3">
                {/* Search */}
                <div className="relative">
                  <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search applicants, jobs..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none w-full sm:w-64 transition-all duration-200"
                  />
                </div>
                
                {/* Status Filter */}
                <div className="relative">
                  <FiFilter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value)}
                    className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none appearance-none bg-white w-full sm:w-48 transition-all duration-200"
                  >
                    <option value="all">All Statuses</option>
                    <option value="Pending">Pending</option>
                    <option value="Interview">Interview</option>
                    <option value="Accepted">Accepted</option>
                    <option value="Rejected">Rejected</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Applications Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full divide-y divide-gray-200">
            <thead className="bg-gradient-to-r from-gray-50 to-gray-100 border-b border-gray-200">
              <tr>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Applicant</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Job Applied</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Company</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Applied Date</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Status</th>
                <th className="text-left py-4 px-6 text-sm font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredApplications.length > 0 ? (
                filteredApplications.map((application, index) => (
                  <tr key={application._id} className="hover:bg-gray-50 transition-colors duration-200">
                    <td className="py-4 px-6">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 w-10 h-10 rounded-lg overflow-hidden bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center mr-3">
                          {application.applicant?.profile?.avatar ? (
                            <img 
                              src={`http://localhost:5000${application.applicant.profile.avatar}`} 
                              alt={application.applicant.name || 'Applicant'} 
                              className="w-full h-full object-cover" 
                            />
                          ) : (
                            <FiUser className="h-5 w-5 text-blue-600" />
                          )}
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900">{application.applicant?.name || 'Applicant'}</div>
                          <div className="text-sm text-gray-600 truncate max-w-xs">{application.applicant?.email || 'Email not provided'}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="font-medium text-gray-900 truncate max-w-xs">{application.jobTitle}</div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-sm text-gray-900 truncate max-w-xs">{application.jobCompany}</div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="text-sm text-gray-900">{formatDate(application.createdAt)}</div>
                    </td>
                    <td className="py-4 px-6">
                      <span className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-semibold ${
                        application.status === 'Pending' 
                          ? 'bg-yellow-100 text-yellow-800' 
                          : application.status === 'Interview' 
                            ? 'bg-blue-100 text-blue-800' 
                            : application.status === 'Accepted' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                      }`}>
                        {application.status}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex flex-wrap gap-1">
                        <button
                          onClick={() => updateApplicationStatus(application._id, 'Accepted', allApplications.findIndex(app => app._id === application._id))}
                          className={`text-xs px-2.5 py-1 rounded-md transition-colors duration-200 ${
                            application.status === 'Accepted' 
                              ? 'bg-green-700 text-white' 
                              : 'bg-green-100 text-green-700 hover:bg-green-200'
                          }`}
                        >
                          Accept
                        </button>
                        <button
                          onClick={() => updateApplicationStatus(application._id, 'Interview', allApplications.findIndex(app => app._id === application._id))}
                          className={`text-xs px-2.5 py-1 rounded-md transition-colors duration-200 ${
                            application.status === 'Interview' 
                              ? 'bg-blue-700 text-white' 
                              : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                          }`}
                        >
                          Interview
                        </button>
                        <button
                          onClick={() => updateApplicationStatus(application._id, 'Rejected', allApplications.findIndex(app => app._id === application._id))}
                          className={`text-xs px-2.5 py-1 rounded-md transition-colors duration-200 ${
                            application.status === 'Rejected' 
                              ? 'bg-red-700 text-white' 
                              : 'bg-red-100 text-red-700 hover:bg-red-200'
                          }`}
                        >
                          Reject
                        </button>
                        <button
                          onClick={() => downloadResume(application._id, application.applicant?.name)}
                          className="flex items-center text-xs bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-2 py-1 rounded-md hover:from-purple-700 hover:to-indigo-700 transition-all duration-200"
                          title="Download Resume"
                        >
                          <FiDownload />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="py-16 px-6 text-center text-gray-500">
                    <div className="flex flex-col items-center justify-center">
                      <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-6">
                        <FiUsers className="w-8 h-8 text-gray-600" />
                      </div>
                      <p className="text-lg font-medium text-gray-900 mb-2">No applications found</p>
                      <p className="text-sm text-gray-600 max-w-md mx-auto">Try adjusting your search or filter criteria to find the applications you're looking for</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Footer Summary */}
      <div className="mt-6 p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 text-sm text-gray-600">
          <div>
            Showing <span className="font-semibold text-gray-900">{filteredApplications.length}</span> of <span className="font-semibold text-gray-900">{allApplications.length}</span> applications
          </div>
          <div className="flex flex-wrap gap-3">
            <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
              <FiCheck className="w-3 h-3 mr-1.5" /> {allApplications.filter(app => app.status.toLowerCase() === 'accepted').length} Accepted
            </span>
            <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
              <FiUsers className="w-3 h-3 mr-1.5" /> {allApplications.filter(app => app.status.toLowerCase() === 'interview').length} Interview
            </span>
            <span className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
              <FiClock className="w-3 h-3 mr-1.5" /> {allApplications.filter(app => app.status.toLowerCase() === 'pending').length} Pending
            </span>
          </div>
        </div>
      </div>
    </div>
    </div>
  );
};

export default AllApplications;