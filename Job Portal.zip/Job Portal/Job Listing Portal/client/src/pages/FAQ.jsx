import React, { useState } from 'react';
import { FiChevronDown, FiChevronUp, FiMail, FiPhone, FiClock, FiMapPin } from 'react-icons/fi';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const toggleAccordion = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "How do I create an account on TalentRaise?",
      answer: "To create an account, click on the 'Register' button in the top right corner of our homepage. You can choose to register as either a Job Seeker or an Employer. Fill in your details, verify your email address, and you're ready to start using our platform."
    },
    {
      question: "How can I search for jobs?",
      answer: "After logging in as a Job Seeker, visit the 'Find Jobs' page where you can browse through available positions. You can filter jobs by location, job type, experience level, and salary range. You can also use the search bar to find specific roles or companies."
    },
    {
      question: "How do I apply for a job?",
      answer: "Once you find a job you're interested in, click on the job listing to view details. Then click the 'Apply Now' button. You'll need to upload your resume and optionally add a cover letter. Make sure your profile is complete to increase your chances of getting noticed."
    },
    {
      question: "How long does it take to hear back after applying?",
      answer: "Response times vary by employer, but most companies review applications within 1-2 weeks. Some may respond faster, especially for urgent positions. You can check the status of your applications in your dashboard."
    },
    {
      question: "How do I post a job as an employer?",
      answer: "After logging in as an Employer, go to your dashboard and click 'Post a Job'. Fill in the job details including title, description, requirements, location, and salary. Once submitted, your job will be reviewed and published within 24 hours."
    },
    {
      question: "What makes a good job posting?",
      answer: "A good job posting includes a clear job title, detailed description of responsibilities, required qualifications, salary range (if possible), benefits, and company culture information. Be specific about expectations and provide information about growth opportunities."
    },
    {
      question: "How can I contact candidates who applied to my job?",
      answer: "In your employer dashboard, go to the 'Applications' section for each job posting. You can view all applicants, download their resumes, and contact them directly through our messaging system. You can also update the status of each application."
    },
    {
      question: "Is there a cost to use TalentRaise?",
      answer: "Job seekers can use TalentRaise completely free. For employers, we offer various pricing plans depending on your hiring needs. Check our pricing page for detailed information on our plans and features."
    },
    {
      question: "How do I update my profile information?",
      answer: "Log in to your account and go to your dashboard. Click on 'Profile' in the sidebar menu to update your personal information, upload a new profile picture, or modify your resume. Changes are saved automatically."
    },
    {
      question: "What should I include in my resume?",
      answer: "Your resume should include your contact information, professional summary, work experience with dates and responsibilities, education, skills, and any relevant certifications. Tailor your resume for each application to highlight relevant experience."
    }
  ];

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-16">
      {/* Header */}
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
          Find answers to common questions about using TalentRaise. Can't find what you're looking for? 
          Our support team is here to help.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* FAQ Content */}
        <div>
          <div className="space-y-5">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-0.5">
                <button
                  className="flex justify-between items-center w-full p-7 text-left bg-white hover:bg-gray-50 transition duration-300 rounded-2xl"
                  onClick={() => toggleAccordion(index)}
                >
                  <h3 className="text-xl font-bold text-gray-900 pr-4">{faq.question}</h3>
                  {openIndex === index ? (
                    <FiChevronUp className="h-6 w-6 text-primary-600 flex-shrink-0" />
                  ) : (
                    <FiChevronDown className="h-6 w-6 text-primary-600 flex-shrink-0" />
                  )}
                </button>
                {openIndex === index && (
                  <div className="px-7 pb-7 pt-0 bg-white -mt-3">
                    <p className="text-gray-600 leading-relaxed text-lg">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>

        </div>

        {/* Office Image and Contact Info */}
        <div>
          <div className="sticky top-24">
            <div className="rounded-2xl w-full h-[450px] mb-8 overflow-hidden shadow-2xl bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center relative">
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent z-10"></div>
              <img 
                src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80" 
                alt="Team Collaboration Meeting" 
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.parentElement.innerHTML = '<div class="text-center p-8"><div class="text-7xl mb-6">👥</div><p class="text-gray-500 text-2xl font-bold">Team Collaboration</p></div>';
                }}
              />
              <div className="absolute bottom-6 left-6 z-20">
                <h3 className="text-2xl font-bold text-white mb-2">Our Team</h3>
                <p className="text-white/90 text-lg">Dedicated to helping you succeed</p>
              </div>
            </div>
            
            <div className="bg-white rounded-2xl shadow-xl p-9 border border-gray-100">
              <h3 className="text-3xl font-bold text-gray-900 mb-7 pb-4 border-b border-gray-100">Contact Information</h3>
              
              <div className="space-y-8">
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center mr-5 shadow-md">
                    <FiClock className="h-7 w-7 text-primary-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xl text-gray-900 mb-2">Office Hours</h4>
                    <p className="text-gray-600 text-lg">Monday - Saturday: 9:00 AM - 6:00 PM (IST)</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center mr-5 shadow-md">
                    <FiMapPin className="h-7 w-7 text-primary-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xl text-gray-900 mb-2">Address</h4>
                    <p className="text-gray-600 text-lg">123 Career Avenue, Suite 100<br />Mumbai, Maharashtra 400001</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 flex items-center justify-center mr-5 shadow-md">
                    <FiPhone className="h-7 w-7 text-primary-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xl text-gray-900 mb-2">Contact</h4>
                    <p className="text-gray-600 text-lg mb-2">Phone: +91 98765 43210</p>
                    <p className="text-gray-600 text-lg">Email: support@talentraise.com</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FAQ;