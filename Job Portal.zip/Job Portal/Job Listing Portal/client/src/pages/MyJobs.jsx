import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { jobsAPI } from '../services/api';
import { applicationsAPI } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { FiEdit, FiTrash2, FiUsers, FiMapPin, FiBriefcase, FiDollarSign, FiClock, FiCalendar } from 'react-icons/fi';

const MyJobs = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Format the posted date to show relative time
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (diffMinutes < 60) {
      return `${diffMinutes} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else if (diffDays === 1) {
      return '1 day ago';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      const weeks = Math.floor(diffDays / 7);
      return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
    } else {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months > 1 ? 's' : ''} ago`;
    }
  };

  // Format date as DD/MM/YYYY with zero-padding
  const formatAbsoluteDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  // Fetch jobs
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        setLoading(true);
        setError('');
        
        if (user?.role === 'employer') {
          const res = await jobsAPI.getJobsByUser();
          setJobs(res.data || []);
        }
      } catch (err) {
        console.error('Error fetching jobs:', err);
        setError('Failed to fetch jobs');
        setJobs([]);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchJobs();
    }
  }, [user]);

  const handleEditJob = (jobId) => {
    navigate(`/edit-job/${jobId}`);
  };

  const handleDeleteJob = async (jobId) => {
    if (window.confirm('Are you sure you want to delete this job?')) {
      try {
        await jobsAPI.deleteJob(jobId);
        setJobs(jobs.filter(job => job._id !== jobId));
        alert('Job deleted successfully');
      } catch (err) {
        console.error('Error deleting job:', err);
        setError('Failed to delete job');
      }
    }
  };

  const fetchJobApplications = async (jobId) => {
    navigate(`/job-applications/${jobId}`);
  };

  if (!user) {
    return null; // Will be redirected by protection logic
  }

  if (loading) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative mb-4">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-8 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="mb-8">
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-200">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">My Jobs</h1>
                <p className="text-gray-600 mt-2">Manage your job postings and track applications</p>
              </div>
              <a 
                href="/post-job" 
                className="inline-flex items-center px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-md"
              >
                <FiBriefcase className="mr-2" />
                Post New Job
              </a>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl text-white shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center justify-center min-h-[140px]">
            <div className="text-2xl font-bold mb-1">{jobs.length}</div>
            <div className="text-xs uppercase tracking-wide text-blue-100 text-center">Total Jobs</div>
          </div>
          
          <div className="p-4 bg-gradient-to-br from-green-500 to-green-600 rounded-xl text-white shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center justify-center min-h-[140px]">
            <div className="text-2xl font-bold mb-1">{jobs.reduce((total, job) => total + (job.applicants ? job.applicants.length : 0), 0)}</div>
            <div className="text-xs uppercase tracking-wide text-green-100 text-center">Total Applicants</div>
          </div>
          
          <div className="p-4 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl text-white shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center justify-center min-h-[140px]">
            <div className="text-2xl font-bold mb-1">{jobs.filter(job => job.isActive).length}</div>
            <div className="text-xs uppercase tracking-wide text-purple-100 text-center">Active Jobs</div>
          </div>
          
          <div className="p-4 bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl text-white shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col items-center justify-center min-h-[140px]">
            <div className="text-2xl font-bold mb-1">{jobs.filter(job => job.applicants && job.applicants.length > 0).length}</div>
            <div className="text-xs uppercase tracking-wide text-amber-100 text-center">Jobs with Applicants</div>
          </div>
        </div>
        
        <div className="mb-8">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-6 border-b border-gray-200 bg-gray-50">
              <h3 className="text-xl font-semibold text-gray-900">Your Job Postings</h3>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider min-w-[120px]">Job Title</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider min-w-[100px]">Company</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider min-w-[80px]">Location</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider min-w-[80px]">Type</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider min-w-[70px]">Level</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider min-w-[100px]">Salary</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider min-w-[90px]">Posted</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider min-w-[80px]">Applicants</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider min-w-[70px]">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider min-w-[90px]">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {jobs.length > 0 ? (
                    jobs.map((job) => (
                      <tr key={job._id} className="hover:bg-gray-50 transition-colors duration-150">
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900 truncate max-w-xs">{job.title}</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900 truncate max-w-xs">{job.company?.company?.name || job.company?.name || 'Your Company'}</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900 flex items-center">
                            <FiMapPin className="h-4 w-4 mr-1 text-gray-500" />
                            {job.location}
                          </div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{job.employmentType}</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{job.experienceLevel}</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {job.salaryMin && job.salaryMax ? `₹${job.salaryMin.toLocaleString()} - ₹${job.salaryMax.toLocaleString()}/yr` : 'Not specified'}
                          </div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{formatDate(job.createdAt)}</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="flex items-center">
                            <FiUsers className="h-4 w-4 mr-1 text-blue-600" />
                            <span className="text-sm font-medium text-blue-900">{job.applicants ? job.applicants.length : 0}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            job.isActive 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {job.isActive ? 'Active' : 'Closed'}
                          </span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm font-medium">
                          <div className="flex space-x-1">
                            <button 
                              onClick={() => handleEditJob(job._id)}
                              className="text-blue-600 hover:text-blue-900 transition-colors duration-150 p-1"
                              title="Edit Job"
                            >
                              <FiEdit className="h-4 w-4" />
                            </button>
                            <button 
                              onClick={() => handleDeleteJob(job._id)}
                              className="text-red-600 hover:text-red-900 transition-colors duration-150 p-1"
                              title="Delete Job"
                            >
                              <FiTrash2 className="h-4 w-4" />
                            </button>
                            <button 
                              onClick={() => fetchJobApplications(job._id)}
                              className="text-green-600 hover:text-green-900 transition-colors duration-150 p-1"
                              title="View Applications"
                            >
                              <FiUsers className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="10" className="px-6 py-12 text-center">
                        <div className="flex flex-col items-center justify-center">
                          <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
                            <FiBriefcase className="h-8 w-8 text-gray-600" />
                          </div>
                          <h4 className="text-lg font-medium text-gray-900 mb-2">No Jobs Posted Yet</h4>
                          <p className="text-gray-600 mb-4">Get started by creating your first job listing to attract top talent</p>
                          <a href="/post-job" className="inline-flex items-center px-4 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors duration-200">
                            <FiBriefcase className="mr-2" />
                            Create Your First Job
                          </a>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MyJobs;