import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { jobsAPI } from '../services/api';
import { applicationsAPI } from '../services/api';
import { FiUser, FiDownload, FiCheck, FiUsers, FiX, FiMail, FiClock, FiCalendar, FiFileText, FiBriefcase, FiArrowLeft } from 'react-icons/fi';

const JobApplications = () => {
  const { jobId } = useParams();
  const { user } = useAuth();
  const [job, setJob] = useState(null);
  const [jobApplications, setJobApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Format the posted date to show relative time
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

    if (diffMinutes < 60) {
      return `${diffMinutes} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else if (diffDays === 1) {
      return '1 day ago';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      const weeks = Math.floor(diffDays / 7);
      return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
    } else {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months > 1 ? 's' : ''} ago`;
    }
  };

  // Fetch job and applications
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError('');
        
        if (user?.role === 'employer') {
          // Fetch the specific job
          const jobsRes = await jobsAPI.getJobsByUser();
          const jobDetail = jobsRes.data.find(j => j._id === jobId);
          setJob(jobDetail);

          // Fetch applications for this job
          const appRes = await applicationsAPI.getApplicationsByJob(jobId);
          setJobApplications(appRes.data || []);
        }
      } catch (err) {
        console.error('Error fetching data:', err);
        setError('Failed to fetch data');
        setJobApplications([]);
      } finally {
        setLoading(false);
      }
    };

    if (user && jobId) {
      fetchData();
    }
  }, [user, jobId]);

  // Update application status
  const updateApplicationStatus = async (applicationId, status) => {
    try {
      const res = await applicationsAPI.updateApplicationStatus(applicationId, { status });
      
      // Update the application in state
      setJobApplications(prev => 
        prev.map(app => 
          app._id === applicationId ? { ...app, status: res.data.status } : app
        )
      );
      
      alert('Application status updated successfully');
    } catch (err) {
      console.error('Error updating application status:', err);
      setError('Failed to update application status. Please try again.');
    }
  };

  // Download applicant resume
  const downloadResume = async (applicationId, applicantName) => {
    try {
      const res = await applicationsAPI.downloadResume(applicationId);
      
      // Create a blob URL and trigger download
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `resume-${applicantName || 'applicant'}.pdf`);
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error downloading resume:', err);
      // Show more specific error message
      if (err.response && err.response.status === 404) {
        setError('Resume file not found. The file may have been deleted or moved.');
      } else if (err.response && err.response.status === 401) {
        setError('You are not authorized to download this resume.');
      } else {
        setError('Failed to download resume. Please try again.');
      }
    }
  };

  if (!user) {
    return null; // Will be redirected by protection logic
  }

  if (loading) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative mb-4">
          {error}
        </div>
      </div>
    );
  }

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <button 
          onClick={() => window.history.back()}
          className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-gray-600 to-gray-700 text-white font-medium rounded-lg hover:from-gray-700 hover:to-gray-800 transition duration-300 shadow-md mb-4"
        >
          <FiArrowLeft className="mr-2" /> Back to Jobs
        </button>
        <h1 className="text-3xl font-bold text-gray-900">Applications for "{job?.title}"</h1>
        <p className="text-xl text-gray-600 mt-2">Review and manage applicants for this position</p>
      </div>

      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="p-6">
          {jobApplications.length > 0 ? (
            <div className="space-y-6">
              {jobApplications.map((application) => (
                <div key={application._id} className="p-6 bg-gradient-to-r from-white to-gray-50 rounded-xl border-l-4 border-teal-500 shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-0.5">
                  <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-4">
                    <div className="flex-1">
                      <div className="flex items-center mb-3">
                        <div className="w-12 h-12 rounded-full mr-3 overflow-hidden">
                          {application.applicant?.profile?.avatar ? (
                            <img 
                              src={`http://localhost:5000${application.applicant.profile.avatar}`} 
                              alt={application.applicant.name || 'Applicant'} 
                              className="w-full h-full object-cover rounded-full" 
                            />
                          ) : (
                            <div className="w-full h-full bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                              <FiUser className="h-6 w-6 text-blue-600" />
                            </div>
                          )}
                        </div>
                        <div>
                          <h4 className="font-bold text-lg text-gray-900">{application.applicant?.name || 'Applicant'}</h4>
                          <p className="text-gray-600">{application.applicant?.email || 'Email not provided'}</p>
                        </div>
                      </div>
                      <div className="ml-15 md:ml-0">
                        <p className="text-sm text-gray-600 mb-2">
                          Applied {formatDate(application.createdAt)}
                        </p>
                        {application.coverLetter && (
                          <div className="mt-3">
                            <h5 className="font-medium text-gray-900 mb-1">Cover Letter:</h5>
                            <p className="text-gray-700 text-sm bg-white p-3 rounded-lg border border-gray-200">
                              {application.coverLetter}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-3">
                      <span className={`px-3 py-1 text-sm font-medium rounded-full ${
                        application.status === 'Pending' 
                          ? 'bg-yellow-100 text-yellow-800' 
                          : application.status === 'Interview' 
                            ? 'bg-blue-100 text-blue-800' 
                            : application.status === 'Accepted' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                      }`}>
                        {application.status}
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {/* Always show status update buttons, regardless of current status */}
                        <button
                          onClick={() => updateApplicationStatus(application._id, 'Accepted')}
                          className={`flex items-center text-sm px-3 py-2 rounded-lg transition-colors duration-200 shadow-sm ${
                            application.status === 'Accepted' 
                              ? 'bg-green-700 text-white' 
                              : 'bg-green-600 text-white hover:bg-green-700'
                          }`}
                        >
                          <FiCheck className="mr-1" /> Accept
                        </button>
                        <button
                          onClick={() => updateApplicationStatus(application._id, 'Interview')}
                          className={`flex items-center text-sm px-3 py-2 rounded-lg transition-colors duration-200 shadow-sm ${
                            application.status === 'Interview' 
                              ? 'bg-blue-700 text-white' 
                              : 'bg-blue-600 text-white hover:bg-blue-700'
                          }`}
                        >
                          <FiUsers className="mr-1" /> Interview
                        </button>
                        <button
                          onClick={() => updateApplicationStatus(application._id, 'Rejected')}
                          className={`flex items-center text-sm px-3 py-2 rounded-lg transition-colors duration-200 shadow-sm ${
                            application.status === 'Rejected' 
                              ? 'bg-red-700 text-white' 
                              : 'bg-red-600 text-white hover:bg-red-700'
                          }`}
                        >
                          <FiX className="mr-1" /> Reject
                        </button>
                        <button
                          onClick={() => downloadResume(application._id, application.applicant?.name)}
                          className="flex items-center text-sm bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-3 py-2 rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all duration-200 shadow-sm"
                        >
                          <FiDownload className="mr-1" /> Resume
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-gray-400 text-5xl mb-4">📋</div>
              <h4 className="text-xl font-medium text-gray-900 mb-2">No Applications Yet</h4>
              <p className="text-gray-600">There are no applications for this job posting yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobApplications;