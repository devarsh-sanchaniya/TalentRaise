import React, { useState } from 'react';
import { FiMail, FiPhone, FiMapPin, FiClock, FiSend } from 'react-icons/fi';
import { messagesAPI } from '../services/api';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('');
    
    try {
      // Send message to admin with structured content
      await messagesAPI.sendMessage({
        subject: formData.subject,
        content: `**From:** ${formData.name}
**Email:** ${formData.email}

**Message:**
${formData.message}`
      });
      
      setIsSubmitting(false);
      setSubmitStatus('success');
      // Reset form
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      });
      
      // Clear success message after 5 seconds
      setTimeout(() => {
        setSubmitStatus('');
      }, 5000);
    } catch (error) {
      console.error('Error sending message:', error);
      setIsSubmitting(false);
      setSubmitStatus('error');
      
      // Clear error message after 5 seconds
      setTimeout(() => {
        setSubmitStatus('');
      }, 5000);
    }
  };

  const contactInfo = [
    {
      icon: <FiMail className="h-6 w-6 text-white" />,
      title: "Email Us",
      content: "support@talentraise.com",
      description: "We'll respond within 24 hours"
    },
    {
      icon: <FiPhone className="h-6 w-6 text-white" />,
      title: "Call Us",
      content: "+91 98765 43210",
      description: "Mon-Sat from 9am to 6pm (IST)"
    },
    {
      icon: <FiMapPin className="h-6 w-6 text-white" />,
      title: "Visit Us",
      content: "123 Career Avenue",
      description: "Mumbai, Maharashtra 400001"
    },
    {
      icon: <FiClock className="h-6 w-6 text-white" />,
      title: "Business Hours",
      content: "Monday - Saturday",
      description: "9:00 AM - 6:00 PM (IST)"
    }
  ];

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Contact Us</h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Have questions about our platform? Need assistance with your account? 
          Our team is here to help you every step of the way.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* Contact Information */}
        <div>
          <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl shadow-lg p-6 text-white h-full">
            <h2 className="text-2xl font-bold mb-6">Get In Touch</h2>
            
            <div className="space-y-6">
              {contactInfo.map((info, index) => (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0 bg-white/20 p-3 rounded-full mr-4">
                    {info.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{info.title}</h3>
                    <p className="font-medium mb-1">{info.content}</p>
                    <p className="text-blue-100 text-sm">{info.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div>
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-5">Send us a Message</h2>
            
            {submitStatus === 'success' && (
              <div className="mb-5 p-3 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-green-800 font-medium">
                  Thank you for your message! We'll get back to you soon.
                </p>
              </div>
            )}
            
            {submitStatus === 'error' && (
              <div className="mb-5 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-800 font-medium">
                  Sorry, there was an error sending your message. Please try again.
                </p>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  placeholder="Enter your full name"
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  placeholder="Enter your email address"
                />
              </div>
              
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                  Subject
                </label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  placeholder="What is this regarding?"
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={4}
                  value={formData.message}
                  onChange={handleChange}
                  required
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                  placeholder="Type your message here..."
                ></textarea>
              </div>
              
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex items-center justify-center px-4 py-2.5 bg-gradient-to-r from-primary-600 to-secondary-600 text-white font-medium rounded-lg hover:from-primary-700 hover:to-secondary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-70"
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Sending...
                  </>
                ) : (
                  <>
                    <FiSend className="mr-2" />
                    Send Message
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">Frequently Asked Questions</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white rounded-lg shadow-md p-5">
            <h3 className="text-base font-bold text-gray-900 mb-2">How long does it take to get a response?</h3>
            <p className="text-gray-600 text-sm">
              We typically respond to all inquiries within 24 business hours. For urgent matters, 
              please call our support line during business hours.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-5">
            <h3 className="text-base font-bold text-gray-900 mb-2">Do you offer technical support?</h3>
            <p className="text-gray-600 text-sm">
              Yes, our technical support team is available to help with any platform-related issues. 
              Simply contact us through this form or call our support line.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-5">
            <h3 className="text-base font-bold text-gray-900 mb-2">Can I schedule a demo?</h3>
            <p className="text-gray-600 text-sm">
              Absolutely! We'd be happy to show you around our platform. Just mention "Demo Request" 
              in the subject line and we'll set up a time that works for you.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-5">
            <h3 className="text-base font-bold text-gray-900 mb-2">Do you have a mobile app?</h3>
            <p className="text-gray-600 text-sm">
              Our platform is fully responsive and works great on mobile devices. We're also working 
              on dedicated mobile apps for iOS and Android, coming soon!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;