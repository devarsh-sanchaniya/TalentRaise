import React, { useState, useEffect } from 'react';
import { FiPlus, FiX, FiCamera } from 'react-icons/fi';
import { useNavigate, useParams } from 'react-router-dom';
import { jobsAPI } from '../services/api';
import { useAuth } from '../contexts/AuthContext';

const EditJob = () => {
  const [jobData, setJobData] = useState({
    title: '',
    description: '',
    location: '',
    employmentType: 'Full-time',
    experienceLevel: 'Mid',
    salaryMin: '',
    salaryMax: '',
    salaryPeriod: 'Yearly',
    category: 'Technology',
    skills: [],
    requirements: [''],
    responsibilities: [''],
    isActive: true
  });
  
  const [newSkill, setNewSkill] = useState('');
  const [companyLogo, setCompanyLogo] = useState(null);
  const [previewLogo, setPreviewLogo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  
  const navigate = useNavigate();
  const { id } = useParams();
  const { user } = useAuth();

  useEffect(() => {
    const fetchJob = async () => {
      try {
        setLoading(true);
        const response = await jobsAPI.getJobById(id);
        
        const job = response.data;
        setJobData({
          title: job.title || '',
          description: job.description || '',
          location: job.location || '',
          employmentType: job.employmentType || 'Full-time',
          experienceLevel: job.experienceLevel || 'Mid',
          salaryMin: job.salaryMin || '',
          salaryMax: job.salaryMax || '',
          salaryPeriod: job.salaryPeriod || 'Yearly',
          category: job.category || 'Technology',
          skills: job.skills || [],

          requirements: job.requirements || [''],
          responsibilities: job.responsibilities || [''],
          isActive: job.isActive !== undefined ? job.isActive : true
        });
        
        // Set the company logo if it exists
        if (job.companyLogo) {
          setPreviewLogo(`http://localhost:5000${job.companyLogo}`);
        }
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to fetch job details.');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchJob();
    }
  }, [id]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setJobData({ 
      ...jobData, 
      [name]: type === 'checkbox' ? checked : value 
    });
  };

  const handleArrayChange = (index, value, field) => {
    const newArray = [...jobData[field]];
    newArray[index] = value;
    setJobData({ ...jobData, [field]: newArray });
  };

  const addArrayItem = (field) => {
    setJobData({ ...jobData, [field]: [...jobData[field], ''] });
  };

  const removeArrayItem = (index, field) => {
    const newArray = [...jobData[field]];
    newArray.splice(index, 1);
    setJobData({ ...jobData, [field]: newArray });
  };

  const addSkill = () => {
    if (newSkill.trim() && !jobData.skills.includes(newSkill.trim())) {
      setJobData({ ...jobData, skills: [...jobData.skills, newSkill.trim()] });
      setNewSkill('');
    }
  };

  const removeSkill = (index) => {
    const newSkills = [...jobData.skills];
    newSkills.splice(index, 1);
    setJobData({ ...jobData, skills: newSkills });
  };

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setCompanyLogo(file);
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewLogo(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerLogoSelect = () => {
    document.getElementById('companyLogoInput').click();
  };

  const removeLogo = () => {
    setCompanyLogo(null);
    setPreviewLogo(null);
    document.getElementById('companyLogoInput').value = '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setSuccess('');

    try {
      // Prepare form data for submission
      const formData = new FormData();
      
      // Append job data
      Object.keys(jobData).forEach(key => {
        if (key !== 'companyLogo') { // Don't double add companyLogo
          if (Array.isArray(jobData[key])) {
            jobData[key].forEach((item, index) => {
              if (item.trim() !== '') {
                formData.append(`${key}[${index}]`, item);
              }
            });
          } else {
            if (jobData[key] !== '') {
              formData.append(key, jobData[key]);
            }
          }
        }
      });
      
      // Add company logo if selected (for updates)
      if (companyLogo) {
        formData.append('companyLogo', companyLogo);
      }
      
      // Remove empty array items by filtering before sending
      const filteredRequirements = jobData.requirements.filter(req => req.trim() !== '');
      const filteredResponsibilities = jobData.responsibilities.filter(resp => resp.trim() !== '');
      
      // Clear and re-add filtered arrays
      for (let i = 0; i < filteredRequirements.length; i++) {
        formData.append('requirements', filteredRequirements[i]);
      }
      for (let i = 0; i < filteredResponsibilities.length; i++) {
        formData.append('responsibilities', filteredResponsibilities[i]);
      }

      const response = await jobsAPI.updateJob(id, formData);
      
      setSuccess('Job updated successfully!');
      // Redirect to job details page after successful update
      setTimeout(() => {
        navigate(`/jobs/${response.data._id}`);
      }, 2000);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update job. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const employmentTypes = ['Full-time', 'Part-time', 'Contract', 'Freelance', 'Internship'];
  const experienceLevels = ['Entry', 'Mid', 'Senior', 'Executive'];
  const categories = ['Technology', 'Marketing', 'Finance', 'Healthcare', 'Education', 'Sales', 'HR', 'Operations'];
  const periods = ['Hourly', 'Daily', 'Weekly', 'Monthly', 'Yearly'];

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Edit Job</h1>
        <p className="text-gray-600 mt-2">Update the details below to modify your job listing</p>
      </div>

      <div className="card">
        <div className="p-6">
          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative">
              {error}
            </div>
          )}
          
          {success && (
            <div className="mb-6 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded relative">
              {success} Redirecting to job details...
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="md:col-span-2">
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                  Job Title *
                </label>
                <input
                  type="text"
                  id="title"
                  name="title"
                  required
                  value={jobData.title}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="e.g. Senior Frontend Developer"
                />
              </div>
              
              <div className="md:col-span-2">
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                  Job Description *
                </label>
                <textarea
                  id="description"
                  name="description"
                  required
                  rows={6}
                  value={jobData.description}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="Describe the role, responsibilities, and what makes this position exciting..."
                ></textarea>
              </div>
              
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                  Location *
                </label>
                <input
                  type="text"
                  id="location"
                  name="location"
                  required
                  value={jobData.location}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="e.g. San Francisco, CA or Remote"
                />
              </div>
              
              <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
                  Category *
                </label>
                <select
                  id="category"
                  name="category"
                  required
                  value={jobData.category}
                  onChange={handleChange}
                  className="input-field"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label htmlFor="employmentType" className="block text-sm font-medium text-gray-700 mb-1">
                  Employment Type *
                </label>
                <select
                  id="employmentType"
                  name="employmentType"
                  required
                  value={jobData.employmentType}
                  onChange={handleChange}
                  className="input-field"
                >
                  {employmentTypes.map((type) => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label htmlFor="experienceLevel" className="block text-sm font-medium text-gray-700 mb-1">
                  Experience Level *
                </label>
                <select
                  id="experienceLevel"
                  name="experienceLevel"
                  required
                  value={jobData.experienceLevel}
                  onChange={handleChange}
                  className="input-field"
                >
                  {experienceLevels.map((level) => (
                    <option key={level} value={level}>{level}</option>
                  ))}
                </select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="salaryMin" className="block text-sm font-medium text-gray-700 mb-1">
                    Minimum Salary
                  </label>
                  <input
                    type="number"
                    id="salaryMin"
                    name="salaryMin"
                    value={jobData.salaryMin}
                    onChange={handleChange}
                    className="input-field"
                    placeholder="e.g. 80000"
                  />
                </div>
                
                <div>
                  <label htmlFor="salaryMax" className="block text-sm font-medium text-gray-700 mb-1">
                    Maximum Salary
                  </label>
                  <input
                    type="number"
                    id="salaryMax"
                    name="salaryMax"
                    value={jobData.salaryMax}
                    onChange={handleChange}
                    className="input-field"
                    placeholder="e.g. 120000"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="salaryPeriod" className="block text-sm font-medium text-gray-700 mb-1">
                  Salary Period
                </label>
                <select
                  id="salaryPeriod"
                  name="salaryPeriod"
                  value={jobData.salaryPeriod}
                  onChange={handleChange}
                  className="input-field"
                >
                  {periods.map((period) => (
                    <option key={period} value={period}>{period}</option>
                  ))}
                </select>
              </div>
              
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="isActive"
                  name="isActive"
                  checked={jobData.isActive}
                  onChange={handleChange}
                  className="h-4 w-4 text-primary-600 border-gray-300 rounded"
                />
                <label htmlFor="isActive" className="ml-2 block text-sm text-gray-700">
                  Job is Active
                </label>
              </div>
              
              {/* Company Logo Upload */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Company Logo
                </label>
                <div className="flex items-center space-x-4">
                  <div 
                    className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary-100 to-secondary-100 border-2 border-dashed border-primary-300 flex items-center justify-center cursor-pointer"
                    onClick={triggerLogoSelect}
                  >
                    {previewLogo ? (
                      <img src={previewLogo} alt="Preview" className="w-12 h-12 rounded-lg object-contain" />
                    ) : (
                      <FiCamera className="h-6 w-6 text-primary-600" />
                    )}
                  </div>
                  
                  <div className="flex flex-col space-y-2">
                    <input
                      id="companyLogoInput"
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={handleLogoChange}
                    />
                    <button
                      type="button"
                      className="px-4 py-2 bg-primary-600 text-white text-sm font-medium rounded-lg hover:bg-primary-700 transition duration-300"
                      onClick={triggerLogoSelect}
                    >
                      {previewLogo ? 'Change Logo' : 'Upload Logo'}
                    </button>
                    
                    {previewLogo && (
                      <button
                        type="button"
                        className="px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition duration-300"
                        onClick={removeLogo}
                      >
                        Remove Logo
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-1">Upload a company logo that represents your brand</p>
              </div>

              
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Skills
                </label>
                <div className="flex">
                  <input
                    type="text"
                    value={newSkill}
                    onChange={(e) => setNewSkill(e.target.value)}
                    className="input-field flex-grow"
                    placeholder="Add a skill"
                  />
                  <button
                    type="button"
                    onClick={addSkill}
                    className="ml-2 btn-primary px-4"
                  >
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap gap-2 mt-3">
                  {jobData.skills.map((skill, index) => (
                    <span key={index} className="bg-primary-100 text-primary-800 px-3 py-1 rounded-full text-sm flex items-center">
                      {skill}
                      <button
                        type="button"
                        onClick={() => removeSkill(index)}
                        className="ml-2 text-primary-800 hover:text-primary-900"
                      >
                        <FiX className="h-4 w-4" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Requirements */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-3">
                <label className="block text-sm font-medium text-gray-700">
                  Job Requirements *
                </label>
                <button
                  type="button"
                  onClick={() => addArrayItem('requirements')}
                  className="text-primary-600 hover:text-primary-700 flex items-center text-sm"
                >
                  <FiPlus className="h-4 w-4 mr-1" /> Add Requirement
                </button>
              </div>
              <div className="space-y-3">
                {jobData.requirements.map((req, index) => (
                  <div key={index} className="flex items-center">
                    <input
                      type="text"
                      value={req}
                      onChange={(e) => handleArrayChange(index, e.target.value, 'requirements')}
                      className="input-field flex-grow"
                      placeholder={`Requirement ${index + 1}`}
                    />
                    {jobData.requirements.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeArrayItem(index, 'requirements')}
                        className="ml-2 p-2 text-red-600 hover:text-red-800"
                      >
                        <FiX className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            {/* Responsibilities */}
            <div className="mb-8">
              <div className="flex justify-between items-center mb-3">
                <label className="block text-sm font-medium text-gray-700">
                  Job Responsibilities *
                </label>
                <button
                  type="button"
                  onClick={() => addArrayItem('responsibilities')}
                  className="text-primary-600 hover:text-primary-700 flex items-center text-sm"
                >
                  <FiPlus className="h-4 w-4 mr-1" /> Add Responsibility
                </button>
              </div>
              <div className="space-y-3">
                {jobData.responsibilities.map((resp, index) => (
                  <div key={index} className="flex items-center">
                    <input
                      type="text"
                      value={resp}
                      onChange={(e) => handleArrayChange(index, e.target.value, 'responsibilities')}
                      className="input-field flex-grow"
                      placeholder={`Responsibility ${index + 1}`}
                    />
                    {jobData.responsibilities.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeArrayItem(index, 'responsibilities')}
                        className="ml-2 p-2 text-red-600 hover:text-red-800"
                      >
                        <FiX className="h-5 w-5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex justify-end space-x-4">
              <button
                type="button"
                onClick={() => navigate('/dashboard')}
                className="btn-outline px-8 py-3"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="btn-primary px-8 py-3 flex items-center"
              >
                {saving ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Saving...
                  </>
                ) : (
                  'Update Job'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditJob;