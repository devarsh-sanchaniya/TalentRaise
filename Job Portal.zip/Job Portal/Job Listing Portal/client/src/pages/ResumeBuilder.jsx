import React, { useState } from 'react';
import { FiUser, FiBook, FiBriefcase, FiStar, FiDownload, FiSave, FiArrowLeft, FiEye, FiPrinter } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { createRoot } from 'react-dom/client';
import ResumePreview from '../components/ResumePreview';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const ResumeBuilder = () => {
  // State for resume data
  const [resumeData, setResumeData] = useState({
    personal: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      location: '',
      linkedin: '',
      github: '',
      headline: '',
      summary: ''
    },
    education: [],
    experience: [],
    skills: [],
    projects: [],
    certifications: [],
    activities: []
  });

  // State for form sections
  const [currentSection, setCurrentSection] = useState('personal');

  // Add new education entry
  const addEducation = () => {
    setResumeData({
      ...resumeData,
      education: [
        ...resumeData.education,
        {
          id: Date.now(),
          institution: '',
          degree: '',
          fieldOfStudy: '',
          startDate: '',
          endDate: '',
          description: ''
        }
      ]
    });
  };

  // Add new experience entry
  const addExperience = () => {
    setResumeData({
      ...resumeData,
      experience: [
        ...resumeData.experience,
        {
          id: Date.now(),
          company: '',
          position: '',
          startDate: '',
          endDate: '',
          description: ''
        }
      ]
    });
  };

  // Add new skill
  const addSkill = () => {
    setResumeData({
      ...resumeData,
      skills: [
        ...resumeData.skills,
        {
          id: Date.now(),
          name: '',
          level: 'Beginner' // Beginner, Intermediate, Advanced
        }
      ]
    });
  };

  // Update personal info
  const updatePersonalInfo = (field, value) => {
    setResumeData({
      ...resumeData,
      personal: {
        ...resumeData.personal,
        [field]: value
      }
    });
  };

  // Update education entry
  const updateEducation = (id, field, value) => {
    setResumeData({
      ...resumeData,
      education: resumeData.education.map(edu =>
        edu.id === id ? { ...edu, [field]: value } : edu
      )
    });
  };

  // Update experience entry
  const updateExperience = (id, field, value) => {
    setResumeData({
      ...resumeData,
      experience: resumeData.experience.map(exp =>
        exp.id === id ? { ...exp, [field]: value } : exp
      )
    });
  };

  // Update skill
  const updateSkill = (id, field, value) => {
    setResumeData({
      ...resumeData,
      skills: resumeData.skills.map(skill =>
        skill.id === id ? { ...skill, [field]: value } : skill
      )
    });
  };

  // Remove education entry
  const removeEducation = (id) => {
    setResumeData({
      ...resumeData,
      education: resumeData.education.filter(edu => edu.id !== id)
    });
  };

  // Remove experience entry
  const removeExperience = (id) => {
    setResumeData({
      ...resumeData,
      experience: resumeData.experience.filter(exp => exp.id !== id)
    });
  };

  // Remove skill
  const removeSkill = (id) => {
    setResumeData({
      ...resumeData,
      skills: resumeData.skills.filter(skill => skill.id !== id)
    });
  };
  
  // Add new project entry
  const addProject = () => {
    setResumeData({
      ...resumeData,
      projects: [
        ...resumeData.projects,
        {
          id: Date.now(),
          title: '',
          description: '',
          technologies: ''
        }
      ]
    });
  };
  
  // Update project entry
  const updateProject = (id, field, value) => {
    setResumeData({
      ...resumeData,
      projects: resumeData.projects.map(proj =>
        proj.id === id ? { ...proj, [field]: value } : proj
      )
    });
  };
  
  // Remove project entry
  const removeProject = (id) => {
    setResumeData({
      ...resumeData,
      projects: resumeData.projects.filter(proj => proj.id !== id)
    });
  };
  
  // Add new certification entry
  const addCertification = () => {
    setResumeData({
      ...resumeData,
      certifications: [
        ...resumeData.certifications,
        {
          id: Date.now(),
          name: '',
          issuer: '',
          dateObtained: '',
          credentialId: ''
        }
      ]
    });
  };
  
  // Update certification entry
  const updateCertification = (id, field, value) => {
    setResumeData({
      ...resumeData,
      certifications: resumeData.certifications.map(cert =>
        cert.id === id ? { ...cert, [field]: value } : cert
      )
    });
  };
  
  // Remove certification entry
  const removeCertification = (id) => {
    setResumeData({
      ...resumeData,
      certifications: resumeData.certifications.filter(cert => cert.id !== id)
    });
  };
  
  // Add new activity entry
  const addActivity = () => {
    setResumeData({
      ...resumeData,
      activities: [
        ...resumeData.activities,
        {
          id: Date.now(),
          title: '',
          organization: '',
          description: '',
          date: ''
        }
      ]
    });
  };
  
  // Update activity entry
  const updateActivity = (id, field, value) => {
    setResumeData({
      ...resumeData,
      activities: resumeData.activities.map(activity =>
        activity.id === id ? { ...activity, [field]: value } : activity
      )
    });
  };
  
  // Remove activity entry
  const removeActivity = (id) => {
    setResumeData({
      ...resumeData,
      activities: resumeData.activities.filter(activity => activity.id !== id)
    });
  };

  // Save resume function
  const saveResume = () => {
    // In a real app, this would save to the backend
    console.log('Saving resume:', resumeData);
    alert('Resume saved successfully!');
  };

  // Export resume function
  const exportResume = async () => {
    try {
      // Create a temporary div to hold the resume content for printing
      const printElement = document.createElement('div');
      printElement.style.position = 'absolute';
      printElement.style.left = '-9999px';
      printElement.style.top = '-9999px';
      printElement.style.width = '210mm'; // A4 width
      printElement.style.minHeight = '297mm'; // A4 height
      printElement.style.padding = '15mm';
      printElement.style.boxSizing = 'border-box';
      printElement.style.background = 'white';
      printElement.style.fontSize = '14px'; // Match the font size in the HTML
      
      // Create a container div for the resume preview
      const resumeContainer = document.createElement('div');
      resumeContainer.style.width = '100%';
      resumeContainer.style.maxWidth = '210mm';
      resumeContainer.style.height = 'auto';
      resumeContainer.style.overflow = 'hidden';
      
      printElement.appendChild(resumeContainer);
      document.body.appendChild(printElement);
      
      // Use createRoot to render the component
      const root = createRoot(resumeContainer);
      root.render(<ResumePreview resumeData={resumeData} className="resume-preview-for-pdf" />);
      
      // Wait for the element to render
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Generate the PDF
      const canvas = await html2canvas(resumeContainer, { 
        scale: 2, // Use scale 2 instead of 3 to reduce file size and potential issues
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff',
        scrollX: 0,
        scrollY: 0,
        // Ensure proper rendering
        logging: false,
        width: resumeContainer.scrollWidth,
        height: resumeContainer.scrollHeight,
        onclone: (clonedDoc) => {
          // Apply additional styles to ensure Tailwind-like appearance in PDF
          const allElements = clonedDoc.querySelectorAll('*');
          allElements.forEach(el => {
            // Ensure Tailwind styles are properly applied as inline styles
            if (el.classList.contains('bg-white')) el.style.backgroundColor = '#ffffff';
            if (el.classList.contains('border-gray-200')) el.style.borderColor = '#e5e7eb';
            if (el.classList.contains('text-gray-900')) el.style.color = '#111827';
            if (el.classList.contains('text-gray-700')) el.style.color = '#374151';
            if (el.classList.contains('text-gray-600')) el.style.color = '#4b5563';
            if (el.classList.contains('text-primary-600')) el.style.color = '#2563eb';
            if (el.classList.contains('text-blue-600')) el.style.color = '#2563eb';
            // Removed blue colors to comply with requirement of no blue highlighting in skill section
            // if (el.classList.contains('text-blue-800')) el.style.color = '#1e40af';
            // if (el.classList.contains('bg-blue-100')) el.style.backgroundColor = '#dbeafe';
            // if (el.classList.contains('border-blue-500')) el.style.borderColor = '#3b82f6';
            
            // Border styles
            if (el.classList.contains('border')) el.style.border = '1px solid';
            if (el.classList.contains('border-b')) el.style.borderBottom = '1px solid';
            if (el.classList.contains('border-l-4')) {
              el.style.borderLeft = '4px solid';
              el.style.borderLeftColor = '#3b82f6';
            }
            if (el.classList.contains('border-b-2')) {
              el.style.borderBottom = '2px solid';
              // Use different colors depending on the section
              if (el.classList.contains('border-gray-300')) {
                el.style.borderBottomColor = '#d1d5db';
              } else {
                el.style.borderBottomColor = '#3b82f6';
              }
            }
            
            // Rounded styles
            if (el.classList.contains('rounded-full')) el.style.borderRadius = '9999px';
            if (el.classList.contains('rounded-xl')) el.style.borderRadius = '0.75rem';
            if (el.classList.contains('rounded-2xl')) el.style.borderRadius = '1rem';
            
            // Typography
            if (el.classList.contains('font-bold')) el.style.fontWeight = 'bold';
            if (el.classList.contains('font-medium')) el.style.fontWeight = '500';
            if (el.classList.contains('font-semibold')) el.style.fontWeight = '600';
            if (el.classList.contains('text-sm')) el.style.fontSize = '0.875rem';
            if (el.classList.contains('text-base')) el.style.fontSize = '1rem';
            if (el.classList.contains('text-lg')) el.style.fontSize = '1.125rem';
            if (el.classList.contains('text-xl')) el.style.fontSize = '1.25rem';
            if (el.classList.contains('text-2xl')) el.style.fontSize = '1.5rem';
            if (el.classList.contains('text-3xl')) el.style.fontSize = '1.875rem';
            
            // Spacing
            if (el.classList.contains('m-0')) el.style.margin = '0';
            if (el.classList.contains('my-0')) {
              el.style.marginTop = '0';
              el.style.marginBottom = '0';
            }
            if (el.classList.contains('mb-2')) el.style.marginBottom = '0.5rem';
            if (el.classList.contains('mb-3')) el.style.marginBottom = '0.75rem';
            if (el.classList.contains('mb-4')) el.style.marginBottom = '1rem';
            if (el.classList.contains('mb-6')) el.style.marginBottom = '1.5rem';
            if (el.classList.contains('mb-8')) el.style.marginBottom = '2rem';
            if (el.classList.contains('mt-2')) el.style.marginTop = '0.5rem';
            if (el.classList.contains('mt-4')) el.style.marginTop = '1rem';
            if (el.classList.contains('mt-6')) el.style.marginTop = '1.5rem';
            if (el.classList.contains('mt-8')) el.style.marginTop = '2rem';
            if (el.classList.contains('pb-2')) el.style.paddingBottom = '0.5rem';
            if (el.classList.contains('pb-4')) el.style.paddingBottom = '1rem';
            if (el.classList.contains('pb-6')) el.style.paddingBottom = '1.5rem';
            if (el.classList.contains('pl-3')) el.style.paddingLeft = '0.75rem';
            if (el.classList.contains('pl-4')) el.style.paddingLeft = '1rem';
            if (el.classList.contains('px-2')) {
              el.style.paddingLeft = '0.5rem';
              el.style.paddingRight = '0.5rem';
            }
            if (el.classList.contains('px-3')) {
              el.style.paddingLeft = '0.75rem';
              el.style.paddingRight = '0.75rem';
            }
            if (el.classList.contains('px-4')) {
              el.style.paddingLeft = '1rem';
              el.style.paddingRight = '1rem';
            }
            if (el.classList.contains('py-0.5')) {
              el.style.paddingTop = '0.125rem';
              el.style.paddingBottom = '0.125rem';
            }
            if (el.classList.contains('py-1')) {
              el.style.paddingTop = '0.25rem';
              el.style.paddingBottom = '0.25rem';
            }
            if (el.classList.contains('py-3')) {
              el.style.paddingTop = '0.75rem';
              el.style.paddingBottom = '0.75rem';
            }
            if (el.classList.contains('py-8')) {
              el.style.paddingTop = '2rem';
              el.style.paddingBottom = '2rem';
            }
            if (el.classList.contains('gap-2')) el.style.gap = '0.5rem';
            if (el.classList.contains('gap-4')) el.style.gap = '1rem';
            
            // Layout
            if (el.classList.contains('flex')) el.style.display = 'flex';
            if (el.classList.contains('inline-flex')) el.style.display = 'inline-flex';
            if (el.classList.contains('flex-wrap')) el.style.flexWrap = 'wrap';
            if (el.classList.contains('items-center')) el.style.alignItems = 'center';
            if (el.classList.contains('justify-center')) el.style.justifyContent = 'center';
            if (el.classList.contains('justify-between')) el.style.justifyContent = 'space-between';
            if (el.classList.contains('text-center')) el.style.textAlign = 'center';
            if (el.classList.contains('text-left')) el.style.textAlign = 'left';
            if (el.classList.contains('text-right')) el.style.textAlign = 'right';
            
            // Shadow
            if (el.classList.contains('shadow-lg')) el.style.boxShadow = '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)';
            
            // Ensure proper line height
            if (el.classList.contains('leading-tight')) el.style.lineHeight = '1.25';
            if (el.classList.contains('leading-relaxed')) el.style.lineHeight = '1.625';
            
            // Apply proper background for the main container
            if (el.classList.contains('resume-preview-for-pdf')) {
              el.style.background = 'white';
              el.style.boxSizing = 'border-box';
              // Shift all content upward slightly
              el.style.marginTop = '-3px';
              el.style.position = 'relative';
            }
            
            // Handle icon alignment in section headings
            if (el.tagName === 'svg' && el.parentElement && el.parentElement.classList.contains('flex') && el.parentElement.classList.contains('items-center')) {
              el.style.verticalAlign = 'middle';
              el.style.marginTop = '0';
              el.style.alignSelf = 'center';
            }
            
            // Also handle icons with mt-0.5 class specifically
            if (el.classList.contains('mt-0\.5')) {
              el.style.marginTop = '0.125rem';
            }
            if (el.classList.contains('mt-0')) {
              el.style.marginTop = '0';
            }
            
            // Handle self-center class for icons
            if (el.classList.contains('self-center')) {
              el.style.alignSelf = 'center';
            }
            
            // Ensure proper alignment for all svg icons in headings
            if (el.tagName === 'svg' && el.parentElement && el.parentElement.classList.contains('border-b-2')) {
              el.style.position = 'relative';
              el.style.top = '1px';
            }
            
            // Specifically handle icons in flex containers
            if (el.tagName === 'svg' && el.parentElement && el.parentElement.classList.contains('flex')) {
              el.style.alignSelf = 'center';
              el.style.marginTop = '0';
            }
            
            // Specific handling for heading icons in PDF
            if (el.tagName === 'svg' && el.previousElementSibling === null && el.parentElement && 
                el.parentElement.tagName === 'H2' && el.parentElement.classList.contains('flex')) {
              el.style.verticalAlign = 'middle';
              el.style.position = 'relative';
              el.style.top = '0';
              el.style.display = 'inline-block';
              el.style.marginTop = '0';
              el.style.alignSelf = 'center';
              el.style.marginRight = '0.5rem';
            }
            
            // Also handle flex containers with items-center
            if (el.parentElement && el.parentElement.classList.contains('items-center')) {
              el.style.alignSelf = 'center';
            }
            
            // Handle heading elements with flex and items-center
            if (el.tagName === 'H2' && el.classList.contains('flex') && el.classList.contains('items-center')) {
              el.style.display = 'flex';
              el.style.alignItems = 'center';
            }
            
            // Enhanced icon alignment for heading sections
            if (el.tagName === 'svg' && el.parentElement && 
                (el.parentElement.classList.contains('border-b') || el.parentElement.classList.contains('border-b-2'))) {
              // This is likely a heading icon
              el.style.verticalAlign = 'middle';
              el.style.alignSelf = 'center';
              el.style.marginTop = '0';
              el.style.marginRight = '0.5rem';
              el.style.display = 'inline-flex';
              el.style.alignItems = 'center';
            }
            
            // Specifically target heading elements to ensure proper flex alignment
            if (el.tagName === 'H2' && (el.classList.contains('border-b') || el.classList.contains('border-b-2'))) {
              el.style.display = 'flex';
              el.style.alignItems = 'center';
              el.style.alignContent = 'center';
            }
            
            // Special handling for all SVG icons in headings
            if (el.tagName === 'SVG' && el.parentElement && el.parentElement.tagName === 'H2') {
              el.style.alignSelf = 'center';
              el.style.marginTop = '0';
              el.style.marginBottom = '0';
              el.style.verticalAlign = 'middle';
            }
            
            // Apply proper alignment for heading elements with bullet points
            if (el.tagName === 'H2' || el.tagName === 'H3') {
              el.style.display = 'flex';
              el.style.alignItems = 'center';
              el.style.gap = '0.5rem';
            }
            
            // Remove SVG icons if they exist and ensure proper bullet point alignment
            if (el.tagName === 'SVG') {
              // Remove the SVG element and let the bullet point take its place
              el.remove();
            }
            
            // Adjust text elements in heading to align with icons
            if (el.nodeType === 3 && el.parentElement && el.parentElement.tagName === 'H2') {
              // Get the sibling SVG icon and align text accordingly
              const parent = el.parentElement;
              const firstChild = parent.firstChild;
              if (firstChild && firstChild.tagName === 'svg') {
                parent.style.alignItems = 'center';
                parent.style.display = 'flex';
              }
            }
            
            // Also handle direct text nodes inside heading elements
            if (el.tagName === 'H2' && el.children.length > 0) {
              // Make sure the H2 itself has proper alignment
              el.style.display = 'flex';
              el.style.alignItems = 'center';
              el.style.gap = '0.5rem';
            }
            
            // Additional specific fix for section heading alignment
            if (el.tagName === 'H2' && (el.classList.contains('text-xl') && 
                (el.classList.contains('border-b') || el.classList.contains('border-b-2')))) {
              el.style.display = 'flex';
              el.style.alignItems = 'center';
              el.style.alignContent = 'center';
              el.style.position = 'relative';
              el.style.top = '0';
            }
          });
        }
      });
      
      const imgData = canvas.toDataURL('image/png', 0.8); // Reduced quality to avoid issues
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
        compress: true
      });
      
      const imgWidth = 210 - 30; // A4 width minus padding
      const pageHeight = 297 - 30; // A4 height minus padding
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      // Only add one page if content fits
      pdf.addImage(imgData, 'PNG', 15, 15, imgWidth, imgHeight, undefined, 'FAST');
      
      // Clean up
      root.unmount();
      document.body.removeChild(printElement);
      
      // Save the PDF
      pdf.save('resume.pdf');
      
      alert('Resume downloaded as PDF successfully!');
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('Error exporting resume. Please try again.');
    }
  };
  
  // Helper function to generate HTML for the resume
  const generateResumeHTML = (data) => {
    const { personal = {}, education = [], experience = [], skills = [], projects = [], certifications = [], activities = [] } = data;
    
    let html = `
      <style>
        @page { margin: 0.5cm; size: A4; }
        body { margin: 0; padding: 0; font-family: Arial, sans-serif; font-size: 14px; }
        .resume-container { max-width: 210mm; width: 100%; margin: 0 auto; font-family: Arial, sans-serif; box-sizing: border-box; }
        .page-break-before { page-break-before: avoid; }
        .no-page-break { page-break-inside: avoid; }
      </style>
      <div class="resume-container" style="font-family: Arial, sans-serif; margin: 0 auto; padding: 0.5rem; line-height: 1.4; font-size: 14px; box-sizing: border-box; width: 100%;">
        <!-- Header -->
        <div class="text-center mb-6 pb-4 border-b border-gray-200" style="text-align: center; margin-bottom: 0.75rem; padding-bottom: 0.5rem; border-bottom: 1px solid #e5e7eb;">
          <h1 class="text-3xl font-bold text-gray-900" style="font-size: 1.75rem; font-weight: 700; color: #111827; margin: 0; letter-spacing: -0.5px;">
            ${personal.firstName || ''} ${personal.lastName || ''}
          </h1>
          <p class="text-lg text-primary-600 font-medium mt-2" style="font-size: 1rem; color: #2563eb; font-weight: 500; margin-top: 0.25rem; text-transform: uppercase; letter-spacing: 1px;">
            ${personal.headline || ''}
          </p>
          <div class="flex flex-wrap justify-center gap-4 mt-4 text-sm text-gray-600" style="display: flex; flex-wrap: wrap; justify-content: center; gap: 0.5rem; margin-top: 0.5rem; color: #4b5563; font-size: 0.875rem;">
            ${personal.email ? `<span class="flex items-center gap-1.5" style="display: flex; align-items: center; gap: 0.25rem;"><span class="font-bold text-base" style="font-weight: bold; font-size: 0.875rem;">✉️</span> ${personal.email}</span>` : ''}
            ${personal.phone ? `<span class="flex items-center gap-1.5" style="display: flex; align-items: center; gap: 0.25rem;"><span class="font-bold text-base" style="font-weight: bold; font-size: 0.875rem;">📞</span> ${personal.phone}</span>` : ''}
            ${personal.location ? `<span class="flex items-center gap-1.5" style="display: flex; align-items: center; gap: 0.25rem;"><span class="font-bold text-base" style="font-weight: bold; font-size: 0.875rem;">📍</span> ${personal.location}</span>` : ''}
            ${personal.linkedin ? `<span class="flex items-center gap-1.5" style="display: flex; align-items: center; gap: 0.25rem;"><span class="font-bold text-base" style="font-weight: bold; font-size: 0.875rem;">💼</span> LinkedIn</span>` : ''}
            ${personal.github ? `<span class="flex items-center gap-1.5" style="display: flex; align-items: center; gap: 0.25rem;"><span class="font-bold text-base" style="font-weight: bold; font-size: 0.875rem;">💻</span> GitHub</span>` : ''}
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6" style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
          <!-- Left Column -->
          <div>
            <!-- Summary -->
            ${personal.summary ? `
            <div class="mb-6" style="margin-bottom: 0.75rem;">
              <h2 class="text-xl font-bold text-gray-900 mb-2 pb-1 border-b border-gray-200 flex items-center" style="font-size: 1.1rem; font-weight: 600; color: #111827; margin: 0 0 0.25rem 0; padding-bottom: 0.125rem; border-bottom: 1px solid #e5e7eb; display: flex; align-items: center; text-transform: uppercase; letter-spacing: 0.5px;">
                <span class="mr-2" style="margin-right: 0.5rem;">•</span> Summary
              </h2>
              <p class="text-gray-700 leading-tight break-words" style="color: #374151; line-height: 1.3; word-wrap: break-word; overflow-wrap: break-word; font-size: 0.9rem;">
                ${personal.summary}
              </p>
            </div>
            ` : ''}
            
            <!-- Experience -->
            ${experience.length > 0 ? `
            <div style="margin-bottom: 0.75rem;">
              <h2 class="text-xl font-bold text-gray-900 mb-2 pb-1 border-b-2 border-blue-500 flex items-center" style="font-size: 1.1rem; font-weight: 600; color: #111827; margin: 0 0 0.25rem 0; padding-bottom: 0.125rem; border-bottom: 2px solid #3b82f6; display: flex; align-items: center; text-transform: uppercase; letter-spacing: 0.5px;">
                <span class="mr-2" style="margin-right: 0.5rem;">•</span> Experience
              </h2>
              <div class="space-y-3" style="margin-top: 0.25rem;">
                ${experience.map(exp => `
                <div class="border-l-4 border-blue-500 pl-3" style="border-left: 2px solid #3b82f6; padding-left: 0.3rem; margin-bottom: 0.4rem;">
                  <h3 class="font-semibold text-gray-900" style="font-weight: 600; color: #111827; font-size: 0.95rem; margin: 0 0 0.05rem 0;">
                    ${exp.position}
                  </h3>
                  <p class="text-blue-600 font-medium" style="color: #2563eb; font-weight: 500; margin: 0 0 0.1rem 0; font-size: 0.9rem;">
                    ${exp.company}
                  </p>
                  <p class="text-gray-600 text-sm" style="color: #4b5563; font-size: 0.8rem; margin: 0;">
                    ${exp.startDate ? new Date(exp.startDate).toLocaleDateString('en-GB', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric'
                    }) : ''} - ${exp.endDate ? new Date(exp.endDate).toLocaleDateString('en-GB', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric'
                    }) : 'Present'}
                  </p>
                  ${exp.description ? `<p class="text-gray-700 mt-1 text-sm break-words" style="color: #374151; font-size: 0.8rem; margin-top: 0.1rem; line-height: 1.3; word-wrap: break-word; overflow-wrap: break-word;">${exp.description}</p>` : ''}
                </div>
                `).join('')}
              </div>
            </div>
            ` : ''}
            
            <!-- Projects -->
            ${projects.length > 0 ? `
            <div class="mt-6" style="margin-top: 0.75rem;">
              <h2 class="text-xl font-bold text-gray-900 mb-2 pb-1 border-b-2 border-blue-500 flex items-center" style="font-size: 1.1rem; font-weight: 600; color: #111827; margin: 0 0 0.25rem 0; padding-bottom: 0.125rem; border-bottom: 2px solid #3b82f6; display: flex; align-items: center; text-transform: uppercase; letter-spacing: 0.5px;">
                <span class="mr-2" style="margin-right: 0.5rem;">•</span> Projects
              </h2>
              <div class="space-y-3" style="margin-top: 0.25rem;">
                ${projects.map(proj => `
                <div class="border-l-4 border-blue-500 pl-3" style="border-left: 2px solid #3b82f6; padding-left: 0.3rem; margin-bottom: 0.4rem;">
                  <h3 class="font-semibold text-gray-900" style="font-weight: 600; color: #111827; font-size: 0.95rem; margin: 0 0 0.05rem 0;">
                    ${proj.title}
                  </h3>
                  <p class="text-blue-600 font-medium" style="color: #2563eb; font-weight: 500; margin: 0 0 0.1rem 0; font-size: 0.9rem;">
                    ${proj.technologies}
                  </p>
                  ${proj.description ? `<p class="text-gray-700 mt-1 text-sm break-words" style="color: #374151; font-size: 0.8rem; margin-top: 0.1rem; line-height: 1.3; word-wrap: break-word; overflow-wrap: break-word;">${proj.description}</p>` : ''}
                </div>
                `).join('')}
              </div>
            </div>
            ` : ''}
          </div>
          
          <!-- Right Column -->
          <div>
            <!-- Education -->
            ${education.length > 0 ? `
            <div class="mb-6" style="margin-bottom: 0.75rem;">
              <h2 class="text-xl font-bold text-gray-900 mb-2 pb-1 border-b-2 border-blue-500 flex items-center" style="font-size: 1.1rem; font-weight: 600; color: #111827; margin: 0 0 0.25rem 0; padding-bottom: 0.125rem; border-bottom: 2px solid #3b82f6; display: flex; align-items: center; text-transform: uppercase; letter-spacing: 0.5px;">
                <span class="mr-2" style="margin-right: 0.5rem;">•</span> Education
              </h2>
              <div class="space-y-3" style="margin-top: 0.25rem;">
                ${education.map(edu => `
                <div class="border-l-4 border-blue-500 pl-3" style="border-left: 2px solid #3b82f6; padding-left: 0.3rem; margin-bottom: 0.4rem;">
                  <h3 class="font-semibold text-gray-900" style="font-weight: 600; color: #111827; font-size: 0.95rem; margin: 0 0 0.05rem 0;">
                    ${edu.degree} in ${edu.fieldOfStudy}
                  </h3>
                  <p class="text-blue-600 font-medium" style="color: #2563eb; font-weight: 500; margin: 0 0 0.1rem 0; font-size: 0.9rem;">
                    ${edu.institution}
                  </p>
                  <p class="text-gray-600 text-sm" style="color: #4b5563; font-size: 0.8rem; margin: 0;">
                    ${edu.startDate ? new Date(edu.startDate).toLocaleDateString('en-GB', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric'
                    }) : ''} - ${edu.endDate ? new Date(edu.endDate).toLocaleDateString('en-GB', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric'
                    }) : 'Present'}
                  </p>
                  ${edu.description ? `<p class="text-gray-700 mt-1 text-sm break-words" style="color: #374151; font-size: 0.8rem; margin-top: 0.1rem; line-height: 1.3; word-wrap: break-word; overflow-wrap: break-word;">${edu.description}</p>` : ''}
                </div>
                `).join('')}
              </div>
            </div>
            ` : ''}
            
            <!-- Skills -->
            ${skills.length > 0 ? `
            <div style="margin-bottom: 0.75rem;">
              <h2 class="text-xl font-bold text-gray-900 mb-2 pb-1 border-b-2 border-gray-300 flex items-center" style="font-size: 1.1rem; font-weight: 600; color: #111827; margin: 0 0 0.25rem 0; padding-bottom: 0.125rem; border-bottom: 2px solid #d1d5db; display: flex; align-items: center; text-transform: uppercase; letter-spacing: 0.5px;">
                <span class="mr-2" style="margin-right: 0.5rem;">•</span> Skills
              </h2>
              <div class="flex flex-wrap gap-1" style="display: flex; flex-wrap: wrap; gap: 0.15rem;">
                ${skills.map(skill => `
                <span class="px-2 py-0.5 bg-gray-100 text-gray-800 rounded-full text-sm font-medium" style="padding: 0.1rem 0.3rem; background-color: #f3f4f6; color: #374151; border-radius: 9999px; font-size: 0.8rem; font-weight: 500;">
                  ${skill.name}
                </span>
                `).join('')}
              </div>
            </div>
            ` : ''}
            
            <!-- Certifications -->
            ${certifications.length > 0 ? `
            <div class="mt-6" style="margin-top: 0.75rem;">
              <h2 class="text-xl font-bold text-gray-900 mb-2 pb-1 border-b-2 border-blue-500 flex items-center" style="font-size: 1.1rem; font-weight: 600; color: #111827; margin: 0 0 0.25rem 0; padding-bottom: 0.125rem; border-bottom: 2px solid #3b82f6; display: flex; align-items: center; text-transform: uppercase; letter-spacing: 0.5px;">
                <span class="mr-2" style="margin-right: 0.5rem;">•</span> Certifications
              </h2>
              <div class="space-y-3" style="margin-top: 0.25rem;">
                ${certifications.map(cert => `
                <div class="border-l-4 border-blue-500 pl-3" style="border-left: 2px solid #3b82f6; padding-left: 0.3rem; margin-bottom: 0.4rem;">
                  <h3 class="font-semibold text-gray-900" style="font-weight: 600; color: #111827; font-size: 0.95rem; margin: 0 0 0.05rem 0;">
                    ${cert.name}
                  </h3>
                  <p class="text-blue-600 font-medium" style="color: #2563eb; font-weight: 500; margin: 0 0 0.1rem 0; font-size: 0.9rem;">
                    ${cert.issuer}
                  </p>
                  <p class="text-gray-600 text-sm" style="color: #4b5563; font-size: 0.8rem; margin: 0;">
                    ${cert.dateObtained ? new Date(cert.dateObtained).toLocaleDateString('en-GB', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric'
                    }) : ''}${cert.credentialId ? ' | ID: ' + cert.credentialId : ''}
                  </p>
                </div>
                `).join('')}
              </div>
            </div>
            ` : ''}
            
            <!-- Activities -->
            ${activities.length > 0 ? `
            <div class="mt-6" style="margin-top: 0.75rem;">
              <h2 class="text-xl font-bold text-gray-900 mb-2 pb-1 border-b-2 border-blue-500 flex items-center" style="font-size: 1.1rem; font-weight: 600; color: #111827; margin: 0 0 0.25rem 0; padding-bottom: 0.125rem; border-bottom: 2px solid #3b82f6; display: flex; align-items: center; text-transform: uppercase; letter-spacing: 0.5px;">
                <span class="mr-2" style="margin-right: 0.5rem;">•</span> Activities
              </h2>
              <div class="space-y-3" style="margin-top: 0.25rem;">
                ${activities.map(activity => `
                <div class="border-l-4 border-blue-500 pl-3" style="border-left: 2px solid #3b82f6; padding-left: 0.3rem; margin-bottom: 0.4rem;">
                  <h3 class="font-semibold text-gray-900" style="font-weight: 600; color: #111827; font-size: 0.95rem; margin: 0 0 0.05rem 0;">
                    ${activity.title}
                  </h3>
                  <p class="text-blue-600 font-medium" style="color: #2563eb; font-weight: 500; margin: 0 0 0.1rem 0; font-size: 0.9rem;">
                    ${activity.organization}
                  </p>
                  <p class="text-gray-600 text-sm" style="color: #4b5563; font-size: 0.8rem; margin: 0;">
                    ${activity.date ? new Date(activity.date).toLocaleDateString('en-GB', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric'
                    }) : ''}
                  </p>
                  ${activity.description ? `<p class="text-gray-700 mt-1 text-sm break-words" style="color: #374151; font-size: 0.8rem; margin-top: 0.1rem; line-height: 1.3; word-wrap: break-word; overflow-wrap: break-word;">${activity.description}</p>` : ''}
                </div>
                `).join('')}
              </div>
            </div>
            ` : ''}
          </div>
        </div>
      </div>
    `;
    
    return html;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Resume Builder</h1>
            <p className="text-gray-600 mt-2">Create a professional resume in minutes</p>
          </div>
          <Link 
            to="/profile" 
            className="flex items-center text-gray-600 hover:text-gray-900 font-medium"
          >
            <FiArrowLeft className="mr-2" /> Back to Profile
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Navigation Sidebar */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
              <h3 className="font-bold text-gray-900 mb-4">Sections</h3>
              <nav className="space-y-2">
                {[
                  { id: 'personal', label: 'Personal Info', icon: <FiUser /> },
                  { id: 'education', label: 'Education', icon: <FiBook /> },
                  { id: 'experience', label: 'Experience', icon: <FiBriefcase /> },
                  { id: 'skills', label: 'Skills', icon: <FiStar /> },
                  { id: 'projects', label: 'Projects', icon: <FiBriefcase /> },
                  { id: 'certifications', label: 'Certifications', icon: <FiStar /> },
                  { id: 'activities', label: 'Activities', icon: <FiUser /> }
                ].map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setCurrentSection(section.id)}
                    className={`w-full flex items-center px-4 py-3 rounded-xl text-left transition-all duration-200 ${
                      currentSection === section.id
                        ? 'bg-primary-100 text-primary-700 border border-primary-200'
                        : 'hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <span className="mr-3">{section.icon}</span>
                    {section.label}
                  </button>
                ))}
              </nav>
              
              <div className="mt-8 pt-6 border-t border-gray-200">
                <button
                  onClick={saveResume}
                  className="w-full flex items-center justify-center px-4 py-3 bg-gradient-to-r from-primary-600 to-secondary-600 text-white rounded-xl hover:from-primary-700 hover:to-secondary-700 transition-all duration-300 mb-3"
                >
                  <FiSave className="mr-2" /> Save Resume
                </button>
                <button
                  onClick={exportResume}
                  className="w-full flex items-center justify-center px-4 py-3 bg-gray-800 text-white rounded-xl hover:bg-gray-900 transition-all duration-300"
                >
                  <FiDownload className="mr-2" /> Export PDF
                </button>
              </div>
            </div>
          </div>

          {/* Form Content */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
              {/* Personal Information Form */}
              {currentSection === 'personal' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">Personal Information</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">First Name</label>
                      <input
                        type="text"
                        value={resumeData.personal.firstName}
                        onChange={(e) => updatePersonalInfo('firstName', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        placeholder="Enter your first name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Last Name</label>
                      <input
                        type="text"
                        value={resumeData.personal.lastName}
                        onChange={(e) => updatePersonalInfo('lastName', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        placeholder="Enter your last name"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                      <input
                        type="email"
                        value={resumeData.personal.email}
                        onChange={(e) => updatePersonalInfo('email', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        placeholder="Enter your email"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                      <input
                        type="tel"
                        value={resumeData.personal.phone}
                        onChange={(e) => updatePersonalInfo('phone', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        placeholder="Enter your phone number"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                      <input
                        type="text"
                        value={resumeData.personal.location}
                        onChange={(e) => updatePersonalInfo('location', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        placeholder="Enter your location"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">LinkedIn Profile URL</label>
                      <input
                        type="url"
                        value={resumeData.personal.linkedin}
                        onChange={(e) => updatePersonalInfo('linkedin', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        placeholder="https://www.linkedin.com/in/your-profile"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">GitHub Profile URL (Optional)</label>
                      <input
                        type="url"
                        value={resumeData.personal.github}
                        onChange={(e) => updatePersonalInfo('github', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        placeholder="https://github.com/your-username"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Professional Headline</label>
                      <input
                        type="text"
                        value={resumeData.personal.headline}
                        onChange={(e) => updatePersonalInfo('headline', e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        placeholder="e.g., Senior Software Engineer"
                      />
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Professional Summary</label>
                      <textarea
                        value={resumeData.personal.summary}
                        onChange={(e) => updatePersonalInfo('summary', e.target.value)}
                        rows={4}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                        placeholder="Write a brief summary of your professional background and key qualifications..."
                      />
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Education Form */}
              {currentSection === 'education' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">Education</h2>
                    <button
                      onClick={addEducation}
                      className="px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                    >
                      Add Education
                    </button>
                  </div>
                  
                  {resumeData.education.length === 0 ? (
                    <div className="text-center py-12">
                      <FiBook className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-lg font-medium text-gray-900">No education added</h3>
                      <p className="mt-1 text-gray-500">Get started by adding your education details.</p>
                      <button
                        onClick={addEducation}
                        className="mt-4 px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                      >
                        Add Education
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {resumeData.education.map((edu) => (
                        <div key={edu.id} className="border border-gray-200 rounded-xl p-6">
                          <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-semibold text-gray-900">Education #{resumeData.education.indexOf(edu) + 1}</h3>
                            <button
                              onClick={() => removeEducation(edu.id)}
                              className="text-red-600 hover:text-red-700 font-medium"
                            >
                              Remove
                            </button>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Institution</label>
                              <input
                                type="text"
                                value={edu.institution}
                                onChange={(e) => updateEducation(edu.id, 'institution', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., University of California"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Degree</label>
                              <input
                                type="text"
                                value={edu.degree}
                                onChange={(e) => updateEducation(edu.id, 'degree', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., Bachelor of Science"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Field of Study</label>
                              <input
                                type="text"
                                value={edu.fieldOfStudy}
                                onChange={(e) => updateEducation(edu.id, 'fieldOfStudy', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., Computer Science"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
                              <input
                                type="date"
                                value={edu.startDate}
                                onChange={(e) => updateEducation(edu.id, 'startDate', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
                              <input
                                type="date"
                                value={edu.endDate}
                                onChange={(e) => updateEducation(edu.id, 'endDate', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                              />
                            </div>
                            <div className="md:col-span-2">
                              <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                              <textarea
                                value={edu.description}
                                onChange={(e) => updateEducation(edu.id, 'description', e.target.value)}
                                rows={3}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="Describe your education experience..."
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}

              {/* Experience Form */}
              {currentSection === 'experience' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">Work Experience</h2>
                    <button
                      onClick={addExperience}
                      className="px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                    >
                      Add Experience
                    </button>
                  </div>
                  
                  {resumeData.experience.length === 0 ? (
                    <div className="text-center py-12">
                      <FiBriefcase className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-lg font-medium text-gray-900">No experience added</h3>
                      <p className="mt-1 text-gray-500">Get started by adding your work experience.</p>
                      <button
                        onClick={addExperience}
                        className="mt-4 px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                      >
                        Add Experience
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {resumeData.experience.map((exp) => (
                        <div key={exp.id} className="border border-gray-200 rounded-xl p-6">
                          <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-semibold text-gray-900">Experience #{resumeData.experience.indexOf(exp) + 1}</h3>
                            <button
                              onClick={() => removeExperience(exp.id)}
                              className="text-red-600 hover:text-red-700 font-medium"
                            >
                              Remove
                            </button>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Company</label>
                              <input
                                type="text"
                                value={exp.company}
                                onChange={(e) => updateExperience(exp.id, 'company', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., Google Inc."
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Position</label>
                              <input
                                type="text"
                                value={exp.position}
                                onChange={(e) => updateExperience(exp.id, 'position', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., Senior Software Engineer"
                              />
                            </div>
                            <div className="space-y-4">
                              <div className="grid grid-cols-1 gap-4">
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-2">Start Date</label>
                                  <input
                                    type="date"
                                    value={exp.startDate}
                                    onChange={(e) => updateExperience(exp.id, 'startDate', e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                  />
                                </div>
                                <div>
                                  <label className="block text-sm font-medium text-gray-700 mb-2">End Date</label>
                                  <input
                                    type="date"
                                    value={exp.endDate}
                                    onChange={(e) => updateExperience(exp.id, 'endDate', e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="md:col-span-2">
                              <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                              <textarea
                                value={exp.description}
                                onChange={(e) => updateExperience(exp.id, 'description', e.target.value)}
                                rows={4}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="Describe your responsibilities and achievements..."
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}

              {/* Skills Form */}
              {currentSection === 'skills' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">Skills</h2>
                    <button
                      onClick={addSkill}
                      className="px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                    >
                      Add Skill
                    </button>
                  </div>
                  
                  {resumeData.skills.length === 0 ? (
                    <div className="text-center py-12">
                      <FiStar className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-lg font-medium text-gray-900">No skills added</h3>
                      <p className="mt-1 text-gray-500">Get started by adding your skills.</p>
                      <button
                        onClick={addSkill}
                        className="mt-4 px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                      >
                        Add Skill
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {resumeData.skills.map((skill) => (
                        <div key={skill.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-xl">
                          <input
                            type="text"
                            value={skill.name}
                            onChange={(e) => updateSkill(skill.id, 'name', e.target.value)}
                            className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                            placeholder="e.g., JavaScript"
                          />
                          <select
                            value={skill.level}
                            onChange={(e) => updateSkill(skill.id, 'level', e.target.value)}
                            className="px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                          >
                            <option value="Beginner">Beginner</option>
                            <option value="Intermediate">Intermediate</option>
                            <option value="Advanced">Advanced</option>
                          </select>
                          <button
                            onClick={() => removeSkill(skill.id)}
                            className="text-red-600 hover:text-red-700 font-medium"
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
              
              {/* Projects Form */}
              {currentSection === 'projects' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">Projects</h2>
                    <button
                      onClick={addProject}
                      className="px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                    >
                      Add Project
                    </button>
                  </div>
                  
                  {resumeData.projects.length === 0 ? (
                    <div className="text-center py-12">
                      <FiBriefcase className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-lg font-medium text-gray-900">No projects added</h3>
                      <p className="mt-1 text-gray-500">Get started by adding your projects.</p>
                      <button
                        onClick={addProject}
                        className="mt-4 px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                      >
                        Add Project
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {resumeData.projects.map((proj) => (
                        <div key={proj.id} className="border border-gray-200 rounded-xl p-6">
                          <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-semibold text-gray-900">Project #{resumeData.projects.indexOf(proj) + 1}</h3>
                            <button
                              onClick={() => removeProject(proj.id)}
                              className="text-red-600 hover:text-red-700 font-medium"
                            >
                              Remove
                            </button>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Project Title</label>
                              <input
                                type="text"
                                value={proj.title}
                                onChange={(e) => updateProject(proj.id, 'title', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., E-commerce Website"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Technologies Used</label>
                              <input
                                type="text"
                                value={proj.technologies}
                                onChange={(e) => updateProject(proj.id, 'technologies', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., React, Node.js, MongoDB"
                              />
                            </div>

                            <div className="md:col-span-2">
                              <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                              <textarea
                                value={proj.description}
                                onChange={(e) => updateProject(proj.id, 'description', e.target.value)}
                                rows={4}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="Describe the project, your role, and key achievements..."
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
              
              {/* Certifications Form */}
              {currentSection === 'certifications' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">Certifications</h2>
                    <button
                      onClick={addCertification}
                      className="px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                    >
                      Add Certification
                    </button>
                  </div>
                  
                  {resumeData.certifications.length === 0 ? (
                    <div className="text-center py-12">
                      <FiStar className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-lg font-medium text-gray-900">No certifications added</h3>
                      <p className="mt-1 text-gray-500">Get started by adding your certifications.</p>
                      <button
                        onClick={addCertification}
                        className="mt-4 px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                      >
                        Add Certification
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {resumeData.certifications.map((cert) => (
                        <div key={cert.id} className="border border-gray-200 rounded-xl p-6">
                          <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-semibold text-gray-900">Certification #{resumeData.certifications.indexOf(cert) + 1}</h3>
                            <button
                              onClick={() => removeCertification(cert.id)}
                              className="text-red-600 hover:text-red-700 font-medium"
                            >
                              Remove
                            </button>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Certification Name</label>
                              <input
                                type="text"
                                value={cert.name}
                                onChange={(e) => updateCertification(cert.id, 'name', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., AWS Certified Solutions Architect"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Issuing Organization</label>
                              <input
                                type="text"
                                value={cert.issuer}
                                onChange={(e) => updateCertification(cert.id, 'issuer', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., Amazon Web Services"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Date Obtained</label>
                              <input
                                type="date"
                                value={cert.dateObtained}
                                onChange={(e) => updateCertification(cert.id, 'dateObtained', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Credential ID (Optional)</label>
                              <input
                                type="text"
                                value={cert.credentialId}
                                onChange={(e) => updateCertification(cert.id, 'credentialId', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., A1B2C3D4E5"
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
              
              {/* Activities Form */}
              {currentSection === 'activities' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-gray-900">Activities & Achievements</h2>
                    <button
                      onClick={addActivity}
                      className="px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                    >
                      Add Activity
                    </button>
                  </div>
                  
                  {resumeData.activities.length === 0 ? (
                    <div className="text-center py-12">
                      <FiUser className="mx-auto h-12 w-12 text-gray-400" />
                      <h3 className="mt-2 text-lg font-medium text-gray-900">No activities added</h3>
                      <p className="mt-1 text-gray-500">Get started by adding your activities.</p>
                      <button
                        onClick={addActivity}
                        className="mt-4 px-4 py-2 bg-primary-600 text-white rounded-xl hover:bg-primary-700 transition-all duration-300"
                      >
                        Add Activity
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {resumeData.activities.map((activity) => (
                        <div key={activity.id} className="border border-gray-200 rounded-xl p-6">
                          <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-semibold text-gray-900">Activity #{resumeData.activities.indexOf(activity) + 1}</h3>
                            <button
                              onClick={() => removeActivity(activity.id)}
                              className="text-red-600 hover:text-red-700 font-medium"
                            >
                              Remove
                            </button>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Activity Title</label>
                              <input
                                type="text"
                                value={activity.title}
                                onChange={(e) => updateActivity(activity.id, 'title', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., Lead Organizer"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Organization</label>
                              <input
                                type="text"
                                value={activity.organization}
                                onChange={(e) => updateActivity(activity.id, 'organization', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="e.g., Student Council"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
                              <input
                                type="date"
                                value={activity.date}
                                onChange={(e) => updateActivity(activity.id, 'date', e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                              />
                            </div>
                            <div className="md:col-span-2">
                              <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                              <textarea
                                value={activity.description}
                                onChange={(e) => updateActivity(activity.id, 'description', e.target.value)}
                                rows={4}
                                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                                placeholder="Describe your role and achievements in this activity..."
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
            </div>
          </div>
          
          {/* Preview Section */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 sticky top-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900 flex items-center">
                  <FiEye className="mr-2" /> Live Preview
                </h2>
                <button
                  onClick={exportResume}
                  className="px-4 py-2 bg-gray-800 text-white rounded-xl hover:bg-gray-900 transition-all duration-300 flex items-center"
                >
                  <FiPrinter className="mr-2" /> Print
                </button>
              </div>
              <div className="overflow-y-auto max-h-[calc(100vh-200px)]">
                <ResumePreview resumeData={resumeData} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResumeBuilder;