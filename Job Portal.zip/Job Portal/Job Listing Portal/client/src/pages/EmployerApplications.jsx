import React, { useState, useEffect } from 'react';
import { FiUser, FiMail, FiPhone, FiMapPin, FiFileText, FiDownload, FiCheck, FiX, FiUsers, FiEdit, FiTrash2, FiBriefcase } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext';
import { applicationsAPI, jobsAPI } from '../services/api';
import { useNavigate } from 'react-router-dom';

const EmployerApplications = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedJob, setSelectedJob] = useState(null);
  const [jobApplications, setJobApplications] = useState([]);
  const [lastUpdated, setLastUpdated] = useState(Date.now());

  // Format the posted date to show relative time
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffMinutes = Math.floor(diffTime / (1000 * 60));
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffMinutes < 60) {
      return `${diffMinutes} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else if (diffDays === 1) {
      return '1 day ago';
    } else if (diffDays < 7) {
      return `${diffDays} days ago`;
    } else if (diffDays < 30) {
      const weeks = Math.floor(diffDays / 7);
      return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
    } else {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months > 1 ? 's' : ''} ago`;
    }
  };

  // Format date as DD/MM/YYYY with zero-padding
  const formatAbsoluteDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  // Fetch jobs and applications
  const fetchData = async () => {
    try {
      setLoading(true);
      setError(''); // Clear any previous errors
      
      // Fetch employer's posted jobs
      try {
        const res = await jobsAPI.getJobsByUser();
        // Ensure we're working with fresh data by creating a new array
        setJobs([...(res.data || [])]);
        
        // Fetch all applications for employer's jobs
        const allJobIds = res.data.map(job => job._id);
        let allApps = [];
        for (const jobId of allJobIds) {
          try {
            const appRes = await applicationsAPI.getApplicationsByJob(jobId);
            allApps = [...allApps, ...appRes.data];
          } catch (appErr) {
            console.error(`Error fetching applications for job ${jobId}:`, appErr);
          }
        }
        setApplications(allApps);
      } catch (err) {
        console.error('Error fetching jobs:', err);
        setError('Failed to fetch jobs and applications');
        setJobs([]);
        setApplications([]);
      }
    } catch (err) {
      setError('Failed to fetch data');
      console.error('Error:', err);
      setJobs([]);
      setApplications([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.role === 'employer') {
      fetchData();
    } else {
      setError('Access denied. Employer account required.');
      setLoading(false);
    }
  }, [user, lastUpdated]);

  // Fetch applications for a specific job
  const fetchJobApplications = async (jobId) => {
    try {
      // Reset applications to empty array while loading
      setJobApplications([]);
      
      const job = jobs.find(j => j._id === jobId);
      setSelectedJob(job);
      
      const res = await applicationsAPI.getApplicationsByJob(jobId);
      setJobApplications(res.data || []);
    } catch (err) {
      console.error('Error fetching job applications:', err);
      setError('Failed to fetch job applications');
      setJobApplications([]); // Set to empty array on error
    }
  };

  // Update application status
  const updateApplicationStatus = async (applicationId, status) => {
    try {
      const res = await applicationsAPI.updateApplicationStatus(applicationId, { status });
      
      // Update the application in state
      setJobApplications(prev => 
        prev.map(app => 
          app._id === applicationId ? { ...app, status: res.data.status } : app
        )
      );
      
      // Update main applications state
      setApplications(prev => 
        prev.map(app => 
          app._id === applicationId ? { ...app, status: res.data.status } : app
        )
      );
    } catch (err) {
      console.error('Error updating application status:', err);
      setError('Failed to update application status');
    }
  };

  // Download applicant resume
  const downloadResume = async (applicationId, applicantName) => {
    try {
      const res = await applicationsAPI.downloadResume(applicationId);
      
      // Create a blob URL and trigger download
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `resume-${applicantName || 'applicant'}.pdf`);
      document.body.appendChild(link);
      link.click();
      
      // Clean up
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error downloading resume:', err);
      // Show more specific error message
      if (err.response && err.response.status === 404) {
        setError('Resume file not found. The file may have been deleted or moved.');
      } else if (err.response && err.response.status === 401) {
        setError('You are not authorized to download this resume.');
      } else {
        setError('Failed to download resume. Please try again.');
      }
    }
  };

  const handleEditJob = (jobId) => {
    navigate(`/edit-job/${jobId}`);
  };

  const handleDeleteJob = async (jobId) => {
    if (window.confirm('Are you sure you want to delete this job?')) {
      try {
        await jobsAPI.deleteJob(jobId);
        setJobs(jobs.filter(job => job._id !== jobId));
        // Also remove applications for this job
        setApplications(applications.filter(app => app.jobId !== jobId));
        alert('Job deleted successfully');
      } catch (err) {
        console.error('Error deleting job:', err);
        setError('Failed to delete job');
      }
    }
  };

  // Show loading state
  if (loading) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  // Show error if any
  if (error) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded relative mb-4">
          {error}
        </div>
      </div>
    );
  }

  // Show job applications if a job is selected, otherwise show all jobs with their applications
  if (selectedJob) {
    return (
      <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200 bg-gray-50">
            <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
              <div>
                <h3 className="text-2xl font-bold text-gray-900">
                  Applications for "{selectedJob.title}"
                </h3>
                <p className="text-gray-600 mt-1">Review and manage applicants for this position</p>
              </div>
              <button 
                onClick={() => {
                  setSelectedJob(null);
                  setJobApplications([]);
                }}
                className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-lg hover:from-blue-700 hover:to-indigo-700 transition duration-300 shadow-md"
              >
                <FiBriefcase className="mr-2" /> Back to Jobs
              </button>
            </div>
          </div>
          
          <div className="p-6">
            <div className="space-y-6">
              {jobApplications.length > 0 ? (
                jobApplications.map((application) => (
                  <div key={application._id} className="p-6 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all duration-300">
                    <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-6">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start gap-4 mb-4">
                          <div className="flex-shrink-0 w-14 h-14 rounded-lg overflow-hidden bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                            {application.applicant?.profile?.avatar ? (
                              <img 
                                src={`http://localhost:5000${application.applicant.profile.avatar}`} 
                                alt={application.applicant.name || 'Applicant'} 
                                className="w-full h-full object-cover" 
                              />
                            ) : (
                              <FiUser className="h-7 w-7 text-blue-600" />
                            )}
                          </div>
                          <div className="min-w-0 flex-1">
                            <h4 className="font-bold text-lg text-gray-900 truncate">{application.applicant?.name || 'Applicant'}</h4>
                            <p className="text-gray-700 truncate flex items-center">
                              <FiMail className="h-4 w-4 mr-1 text-gray-500" /> {application.applicant?.email || 'Email not provided'}
                            </p>
                            
                            {/* Applicant details */}
                            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500 mt-2">
                              <div className="flex items-center">
                                <FiCalendar className="h-4 w-4 mr-1 text-gray-400" />
                                <span>Applied {formatAbsoluteDate(application.createdAt)}</span>
                              </div>
                              <div className="flex items-center">
                                <FiClock className="h-4 w-4 mr-1 text-gray-400" />
                                <span>{formatDate(application.createdAt)}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {application.coverLetter && (
                          <div className="mt-4">
                            <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                              <FiFileText className="mr-2" /> Cover Letter
                            </h5>
                            <p className="text-gray-700 text-sm bg-gray-50 p-4 rounded-lg border border-gray-200 leading-relaxed">
                              {application.coverLetter.substring(0, 200)}...
                              <span className="text-blue-600 font-medium cursor-pointer ml-1" onClick={() => alert(application.coverLetter)}>read more</span>
                            </p>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex flex-col items-end gap-4">
                        <span className={`px-4 py-1.5 text-sm font-medium rounded-full ${
                          application.status === 'Pending' 
                            ? 'bg-yellow-100 text-yellow-800' 
                            : application.status === 'Interview' 
                              ? 'bg-blue-100 text-blue-800' 
                              : application.status === 'Accepted' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-red-100 text-red-800'
                        }`}>
                          {application.status}
                        </span>
                        
                        <div className="flex flex-wrap gap-2">
                          {/* Always show status update buttons, regardless of current status */}
                          <button
                            onClick={() => updateApplicationStatus(application._id, 'Accepted')}
                            className={`flex items-center text-sm px-4 py-2 rounded-lg transition-colors duration-200 shadow-sm ${
                              application.status === 'Accepted' 
                                ? 'bg-green-700 text-white' 
                                : 'bg-green-600 text-white hover:bg-green-700'
                            }`}
                          >
                            <FiCheck className="mr-1.5" /> Accept
                          </button>
                          <button
                            onClick={() => updateApplicationStatus(application._id, 'Interview')}
                            className={`flex items-center text-sm px-4 py-2 rounded-lg transition-colors duration-200 shadow-sm ${
                              application.status === 'Interview' 
                                ? 'bg-blue-700 text-white' 
                                : 'bg-blue-600 text-white hover:bg-blue-700'
                            }`}
                          >
                            <FiUsers className="mr-1.5" /> Interview
                          </button>
                          <button
                            onClick={() => updateApplicationStatus(application._id, 'Rejected')}
                            className={`flex items-center text-sm px-4 py-2 rounded-lg transition-colors duration-200 shadow-sm ${
                              application.status === 'Rejected' 
                                ? 'bg-red-700 text-white' 
                                : 'bg-red-600 text-white hover:bg-red-700'
                            }`}
                          >
                            <FiX className="mr-1.5" /> Reject
                          </button>
                          <button
                            onClick={() => downloadResume(application._id, application.applicant?.name)}
                            className="flex items-center text-sm bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-4 py-2 rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all duration-200 shadow-sm"
                          >
                            <FiDownload className="mr-1.5" /> Resume
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-16">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-6">
                    <FiUsers className="h-8 w-8 text-gray-600" />
                  </div>
                  <h4 className="text-xl font-medium text-gray-900 mb-2">No Applications Yet</h4>
                  <p className="text-gray-600 mb-6 max-w-md mx-auto">There are no applications for this job posting yet.</p>
                  <button 
                    onClick={() => {
                      setSelectedJob(null);
                      setJobApplications([]);
                    }}
                    className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-lg hover:from-blue-700 hover:to-indigo-700 transition duration-300 shadow-md"
                  >
                    <FiBriefcase className="mr-2" /> Back to Jobs
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Your Applications</h1>
        <p className="text-gray-600 mt-2">Manage applications for your job postings</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden text-white">
          <div className="p-6">
            <div className="flex items-center">
              <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl">
                <FiBriefcase className="h-8 w-8" />
              </div>
              <div className="ml-5">
                <p className="text-base font-medium text-blue-100">Total Jobs</p>
                <p className="text-3xl font-bold">{jobs.length}</p>
              </div>
            </div>
          </div>
          <div className="px-6 py-3 bg-white/10 text-blue-100 text-sm font-medium">
            Posted by you
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden text-white">
          <div className="p-6">
            <div className="flex items-center">
              <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl">
                <FiUsers className="h-8 w-8" />
              </div>
              <div className="ml-5">
                <p className="text-base font-medium text-green-100">Total Applicants</p>
                <p className="text-3xl font-bold">{jobs.reduce((total, job) => total + (job.applicants ? job.applicants.length : 0), 0)}</p>
              </div>
            </div>
          </div>
          <div className="px-6 py-3 bg-white/10 text-green-100 text-sm font-medium">
            For your jobs
          </div>
        </div>
        
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden text-white">
          <div className="p-6">
            <div className="flex items-center">
              <div className="p-4 bg-white/20 backdrop-blur-sm rounded-xl">
                <FiFileText className="h-8 w-8" />
              </div>
              <div className="ml-5">
                <p className="text-base font-medium text-purple-100">Applications</p>
                <p className="text-3xl font-bold">{applications.length}</p>
              </div>
            </div>
          </div>
          <div className="px-6 py-3 bg-white/10 text-purple-100 text-sm font-medium">
            Received for your jobs
          </div>
        </div>
      </div>

      {/* Job Listings */}
      <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
        <div className="p-6 border-b border-gray-200 bg-gray-50">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h3 className="text-xl font-bold text-gray-900">
                Your Job Posts
              </h3>
              <p className="text-gray-600 mt-1">Manage your job listings and applications</p>
            </div>
            <a 
              href="/post-job" 
              className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-lg hover:from-blue-700 hover:to-indigo-700 transition duration-300 shadow-md"
            >
              Post New Job
            </a>
          </div>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {jobs.length > 0 ? (
              jobs.map((job) => (
                <div key={job._id} className="flex flex-col md:flex-row md:items-center justify-between p-6 bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all duration-300">
                  <div className="flex-1 mb-4 md:mb-0">
                    <h4 className="font-bold text-lg text-gray-900 truncate">{job.title}</h4>
                    <p className="text-gray-700 mb-2 truncate">{job.company?.company?.name || job.company?.name || 'Your Company'}</p>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                      <span className="flex items-center">
                        <FiMapPin className="h-4 w-4 mr-1" />
                        {job.location}
                      </span>
                      <span>Posted {formatAbsoluteDate(job.createdAt)}</span>
                      <span className="font-medium">
                        {job.salaryMin && job.salaryMax 
                          ? `₹${job.salaryMin.toLocaleString()} - ₹${job.salaryMax.toLocaleString()}/yr` 
                          : 'Not specified'}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="text-sm text-gray-600 whitespace-nowrap bg-gray-100 px-3 py-1.5 rounded-full border border-gray-200">
                      <FiUsers className="inline h-4 w-4 mr-1" />
                      {job.applicants ? job.applicants.length : 0} applicants
                    </span>
                    <span className={`px-3 py-1.5 text-sm font-medium rounded-full whitespace-nowrap ${
                      job.isActive 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {job.isActive ? 'Active' : 'Closed'}
                    </span>
                    <div className="flex flex-wrap gap-2">
                      <button 
                        onClick={() => handleEditJob(job._id)}
                        className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-blue-100 text-blue-600 hover:bg-blue-200 transition-colors duration-200 shadow-sm"
                        title="Edit Job"
                      >
                        <FiEdit className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => handleDeleteJob(job._id)}
                        className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-red-100 text-red-600 hover:bg-red-200 transition-colors duration-200 shadow-sm"
                        title="Delete Job"
                      >
                        <FiTrash2 className="w-5 h-5" />
                      </button>
                      <button 
                        onClick={() => fetchJobApplications(job._id)}
                        className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-green-100 text-green-600 hover:bg-green-200 transition-colors duration-200 shadow-sm"
                        title="View Applications"
                      >
                        <FiUsers className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-16">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-6">
                  <FiBriefcase className="h-8 w-8 text-gray-600" />
                </div>
                <h4 className="text-xl font-medium text-gray-900 mb-2">No Jobs Posted Yet</h4>
                <p className="text-gray-600 mb-6 max-w-md mx-auto">Get started by creating your first job listing to attract top talent</p>
                <a href="/post-job" className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-medium rounded-lg hover:from-blue-700 hover:to-indigo-700 transition duration-300 shadow-md">
                  <FiBriefcase className="mr-2" /> Post Your First Job
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployerApplications;