import React, { useEffect } from 'react';
import { Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import JobList from './pages/JobList';
import JobDetails from './pages/JobDetails';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import Dashboard from './pages/Dashboard';
import PostJob from './pages/PostJob';
import EditJob from './pages/EditJob';
import About from './pages/About';
import Contact from './pages/Contact';
import FAQ from './pages/FAQ';
import AdminLogin from './pages/admin/Login';
import AdminDashboard from './pages/admin/Dashboard';
import AdminUsers from './pages/admin/Users';
import AdminEmployers from './pages/admin/Employers';
import AdminJobSeekers from './pages/admin/JobSeekers';
import AdminJobs from './pages/admin/Jobs';
import AdminApplications from './pages/admin/Applications';
import AdminSettings from './pages/admin/Settings';
import AdminMessages from './pages/admin/Messages';
import AdminSystemReports from './pages/admin/SystemReports'; // Add system reports import
import AllActivities from './pages/admin/AllActivities';
import ResumeBuilder from './pages/ResumeBuilder';
import ResumeInfo from './pages/ResumeInfo';
import UserMessages from './pages/UserMessages';
import MyJobs from './pages/MyJobs';
import AllApplications from './pages/AllApplications';
import JobApplications from './pages/JobApplications';
import ProtectedRoute from './components/ProtectedRoute';
import ProtectedAdminRoute from './components/admin/ProtectedAdminRoute';
import JobPortalChatbot from './components/JobPortalChatbot';

import EmployerRouteWrapper from './components/EmployerRouteWrapper';
// Companies page removed as per user request
import './App.css';

function ScrollToTop() {
  const location = useLocation();

  useEffect(() => {
    // Scroll to top whenever the location changes
    window.scrollTo(0, 0);
  }, [location]);

  return null;
}

function App() {
  const location = useLocation();
  const navigate = useNavigate();
  const isAdminRoute = location.pathname.startsWith('/admin');
  const hideFooterPages = ['/login', '/register', '/post-job', '/resume-builder', '/dashboard', '/profile', '/messages', '/my-jobs', '/all-applications'];
  const shouldHideFooter = hideFooterPages.some(page => location.pathname.startsWith(page));
  
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {!isAdminRoute && <Navbar />}
      <ScrollToTop />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/jobs" element={<JobList />} />
          <Route path="/jobs/:id" element={<JobDetails />} />
          {/* Companies route removed as per user request */}
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route 
            path="/profile" 
            element={
              <ProtectedRoute allowedRoles={['employer', 'jobseeker']}>
                <EmployerRouteWrapper>
                  <Profile />
                </EmployerRouteWrapper>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/dashboard" 
            element={
              <ProtectedRoute allowedRoles={['employer', 'jobseeker']}>
                <EmployerRouteWrapper>
                  <Dashboard />
                </EmployerRouteWrapper>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/messages" 
            element={
              <ProtectedRoute allowedRoles={['employer', 'jobseeker']}>
                <EmployerRouteWrapper>
                  <UserMessages />
                </EmployerRouteWrapper>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/post-job" 
            element={
              <ProtectedRoute allowedRoles={['employer']}>
                <EmployerRouteWrapper>
                  <PostJob />
                </EmployerRouteWrapper>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/edit-job/:id" 
            element={
              <ProtectedRoute allowedRoles={['employer']}>
                <EmployerRouteWrapper>
                  <EditJob />
                </EmployerRouteWrapper>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/my-jobs" 
            element={
              <ProtectedRoute allowedRoles={['employer']}>
                <EmployerRouteWrapper>
                  <MyJobs />
                </EmployerRouteWrapper>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/all-applications" 
            element={
              <ProtectedRoute allowedRoles={['employer']}>
                <EmployerRouteWrapper>
                  <AllApplications />
                </EmployerRouteWrapper>
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/job-applications/:jobId" 
            element={
              <ProtectedRoute allowedRoles={['employer']}>
                <EmployerRouteWrapper>
                  <JobApplications />
                </EmployerRouteWrapper>
              </ProtectedRoute>
            } 
          />

          
          {/* Admin Routes */}
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route 
            path="/admin/dashboard" 
            element={
              <ProtectedAdminRoute>
                <AdminDashboard />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/admin/users" 
            element={
              <ProtectedAdminRoute>
                <AdminUsers />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/admin/employers" 
            element={
              <ProtectedAdminRoute>
                <AdminEmployers />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/admin/jobseekers" 
            element={
              <ProtectedAdminRoute>
                <AdminJobSeekers />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/admin/jobs" 
            element={
              <ProtectedAdminRoute>
                <AdminJobs />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/admin/applications" 
            element={
              <ProtectedAdminRoute>
                <AdminApplications />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/admin/messages" 
            element={
              <ProtectedAdminRoute>
                <AdminMessages />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/admin/reports" 
            element={
              <ProtectedAdminRoute>
                <AdminSystemReports />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/resume-builder" 
            element={
              <ProtectedRoute>
                <ResumeBuilder />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin/activity" 
            element={
              <ProtectedAdminRoute>
                <AllActivities />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/admin/settings" 
            element={
              <ProtectedAdminRoute>
                <AdminSettings />
              </ProtectedAdminRoute>
            } 
          />
          <Route 
            path="/resume-info" 
            element={<ResumeInfo />}
          />
        </Routes>
      </main>
      {!isAdminRoute && !shouldHideFooter && <Footer />}
      {!isAdminRoute && !shouldHideFooter && <JobPortalChatbot />}
           
    </div>
  );
}

export default App;