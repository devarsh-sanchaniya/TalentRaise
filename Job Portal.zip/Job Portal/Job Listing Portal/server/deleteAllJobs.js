import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Job from './models/Job.model.js';

dotenv.config();

const connectDB = async () => {
  try {
    // Use the same URI as in server.js
    const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/jobportal';
    const conn = await mongoose.connect(uri);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

const deleteAllJobs = async () => {
  await connectDB();
  
  try {
    // Delete all jobs
    const result = await Job.deleteMany({});
    console.log(`Deleted ${result.deletedCount} jobs`);
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
};

deleteAllJobs();