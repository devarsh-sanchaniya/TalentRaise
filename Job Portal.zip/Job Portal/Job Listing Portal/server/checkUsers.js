import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from './models/User.model.js';

dotenv.config();

const connectDB = async () => {
  try {
    // Use the same URI as in server.js
    const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/jobportal';
    const conn = await mongoose.connect(uri);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

const checkUsers = async () => {
  await connectDB();
  
  try {
    // Find all users except admins
    const users = await User.find({ role: { $ne: 'admin' } });
    console.log('All non-admin users in database:', users);
    
    // Count users
    const userCount = await User.countDocuments({ role: { $ne: 'admin' } });
    console.log('Total non-admin user count:', userCount);
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
};

checkUsers();