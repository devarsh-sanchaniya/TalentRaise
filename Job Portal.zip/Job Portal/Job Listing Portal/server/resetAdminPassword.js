import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import User from './models/User.model.js';

// Load environment variables
dotenv.config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/jobportal')
  .then(async () => {
    console.log('Connected to MongoDB');
    
    // Find the admin user
    const admin = await User.findOne({ email: 'admin@jobportal.com' });
    if (!admin) {
      console.log('Admin user not found');
      process.exit(1);
    }
    
    // Hash the new password
    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash('Admin', salt);
    
    // Update the password
    admin.password = hashedPassword;
    await admin.save();
    
    console.log('Admin password reset successfully');
    process.exit(0);
  })
  .catch((err) => {
    console.error('Error:', err);
    process.exit(1);
  });