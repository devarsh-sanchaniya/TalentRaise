import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Application from './models/Application.model.js';

// Load environment variables
dotenv.config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/jobportal')
  .then(async () => {
    console.log('Connected to MongoDB');
    
    // Delete all applications
    const result = await Application.deleteMany({});
    console.log(`Deleted ${result.deletedCount} applications`);
    
    // Close connection
    mongoose.connection.close();
    console.log('Connection closed');
  })
  .catch(err => {
    console.error('Error:', err);
    mongoose.connection.close();
  });