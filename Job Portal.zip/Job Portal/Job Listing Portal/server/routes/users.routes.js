import express from 'express';
import { 
  getUsers, 
  deleteUser, 
  getUserById, 
  approveCompany,
  getAllJobs,
  deleteJobAsAdmin,
  getAdminStats,
  blockUser,
  closeJob,
  updateUserAsAdmin,
  updateJobAsAdmin,
  updateAdminPassword,
  getRecentActivities,
  getSystemReports
} from '../controllers/users.controller.js';
import { protect, authorize } from '../middleware/auth.middleware.js';

const router = express.Router();

// Admin routes
router.route('/admin/stats')
  .get(protect, authorize('admin'), getAdminStats);

router.route('/admin/recent-activities')
  .get(protect, authorize('admin'), getRecentActivities);

router.route('/admin/system-reports')
  .get(protect, authorize('admin'), getSystemReports);

router.route('/')
  .get(protect, authorize('admin'), getUsers);

router.route('/:id')
  .get(protect, authorize('admin'), getUserById)
  .delete(protect, authorize('admin'), deleteUser);

router.route('/:id/block')
  .put(protect, authorize('admin'), blockUser);

router.route('/:id/approve-company')
  .put(protect, authorize('admin'), approveCompany);

router.route('/admin/jobs')
  .get(protect, authorize('admin'), getAllJobs);

router.route('/admin/jobs/:id')
  .delete(protect, authorize('admin'), deleteJobAsAdmin);

router.route('/admin/jobs/:id/close')
  .put(protect, authorize('admin'), closeJob);

// Admin update routes
router.route('/:id')
  .put(protect, authorize('admin'), updateUserAsAdmin);

router.route('/admin/jobs/:id')
  .put(protect, authorize('admin'), updateJobAsAdmin);

// Admin password update route
router.route('/admin/password')
  .put(protect, authorize('admin'), updateAdminPassword);

export default router;