import express from 'express';
import { register, login, logout, getProfile, updateProfile, deleteProfile, updatePassword, updateCompanyLogo } from '../controllers/auth.controller.js';
import { protect } from '../middleware/auth.middleware.js';
import upload from '../middleware/upload.middleware.js';

const router = express.Router();

router.post('/register', upload.single('profileImage'), register);
router.post('/login', login);
router.post('/logout', protect, logout);
router.get('/profile', protect, getProfile);
router.put('/profile', protect, upload.single('profileImage'), updateProfile);
router.put('/company-logo', protect, upload.single('logo'), updateCompanyLogo);
router.delete('/profile', protect, deleteProfile);
router.put('/password', protect, updatePassword);

export default router;