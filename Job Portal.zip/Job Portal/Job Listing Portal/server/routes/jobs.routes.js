import express from 'express';
import { 
  getJobs, 
  getJobById, 
  createJob, 
  updateJob, 
  deleteJob, 
  getJobsByUser
} from '../controllers/jobs.controller.js';
import { protect, authorize } from '../middleware/auth.middleware.js';
import upload from '../middleware/upload.middleware.js';

const router = express.Router();

// Public routes
router.route('/')
  .get(getJobs)
  .post(protect, authorize('employer'), upload.single('companyLogo'), createJob);

router.route('/user')
  .get(protect, authorize('employer'), getJobsByUser);

router.route('/:id')
  .get(getJobById)
  .put(protect, authorize('employer'), upload.single('companyLogo'), updateJob)
  .delete(protect, authorize('employer'), deleteJob);

export default router;