import express from 'express';
import { 
  sendMessage,
  getMessagesForAdmin,
  markMessageAsRead,
  deleteMessage,
  getMessageCount,
  replyToMessage,
  getMessagesForUser,
  markUserMessageAsRead,
  getUserMessageCount,
  deleteUserMessage
} from '../controllers/messages.controller.js';
import { protect, authorize } from '../middleware/auth.middleware.js';

const router = express.Router();

// User routes (employers and job seekers)
router.route('/')
  .post(protect, authorize('jobseeker', 'employer'), sendMessage);

// Admin routes
router.route('/admin')
  .get(protect, authorize('admin'), getMessagesForAdmin);

router.route('/admin/:id/read')
  .put(protect, authorize('admin'), markMessageAsRead);

router.route('/admin/:id')
  .delete(protect, authorize('admin'), deleteMessage);

router.route('/admin/:id/reply')
  .post(protect, authorize('admin'), replyToMessage);

router.route('/admin/count')
  .get(protect, authorize('admin'), getMessageCount);

// User routes
router.route('/user')
  .get(protect, authorize('jobseeker', 'employer'), getMessagesForUser);

router.route('/user/:id/read')
  .put(protect, authorize('jobseeker', 'employer'), markUserMessageAsRead);

router.route('/user/:id')
  .delete(protect, authorize('jobseeker', 'employer'), deleteUserMessage);

router.route('/user/count')
  .get(protect, authorize('jobseeker', 'employer'), getUserMessageCount);

export default router;