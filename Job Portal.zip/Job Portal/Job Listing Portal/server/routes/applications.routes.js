import express from 'express';
import { 
  applyForJob, 
  getApplicationsByJob, 
  getMyApplications, 
  updateApplicationStatus,
  updateApplicationStatusAdmin,
  downloadResume,
  downloadResumeAdmin,
  getAllApplicationsAdmin
} from '../controllers/applications.controller.js';
import { protect, authorize } from '../middleware/auth.middleware.js';
import resumeUpload from '../middleware/resumeUpload.middleware.js';

const router = express.Router();

// Admin route to get all applications
router.route('/admin/all')
  .get(protect, authorize('admin'), getAllApplicationsAdmin);

// Admin route to update application status
router.route('/admin/:id')
  .put(protect, authorize('admin'), updateApplicationStatusAdmin);

// Admin route to download resume
router.route('/admin/:id/resume')
  .get(protect, authorize('admin'), downloadResumeAdmin);

router.route('/')
  .post(protect, authorize('jobseeker'), resumeUpload.single('resume'), applyForJob);

router.route('/job/:jobId')
  .get(protect, authorize('employer'), getApplicationsByJob);

router.route('/my-applications')
  .get(protect, authorize('jobseeker'), getMyApplications);

router.route('/:id')
  .put(protect, authorize('employer'), updateApplicationStatus);

router.route('/:id/resume')
  .get(protect, authorize('employer'), downloadResume);

export default router;