import axios from 'axios';

async function testAdminLogin() {
  try {
    console.log('Testing admin login with new credentials...');
    
    const response = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@talentraise.com',
      password: 'Admin@2025!'
    });
    
    console.log('Login successful!');
    console.log('Token:', response.data.token);
    console.log('Role:', response.data.role);
    
    // Test accessing admin stats with the token
    try {
      const statsResponse = await axios.get('http://localhost:5000/api/users/admin/stats', {
        headers: {
          'Authorization': `Bearer ${response.data.token}`
        }
      });
      
      console.log('Admin stats:', statsResponse.data);
    } catch (statsError) {
      console.log('Could not fetch admin stats:', statsError.message);
    }
  } catch (error) {
    console.error('Login failed:', error.response?.data || error.message);
  }
}

testAdminLogin();