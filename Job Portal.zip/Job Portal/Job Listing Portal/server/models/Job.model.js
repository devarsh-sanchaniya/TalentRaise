import mongoose from 'mongoose';

const jobSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  requirements: [{
    type: String
  }],
  responsibilities: [{
    type: String
  }],
  location: {
    type: String,
    required: true
  },
  employmentType: {
    type: String,
    enum: ['Full-time', 'Part-time', 'Contract', 'Freelance', 'Internship'],
    required: true
  },
  experienceLevel: {
    type: String,
    enum: ['Entry', 'Mid', 'Senior', 'Executive'],
    required: true
  },
  salaryMin: {
    type: Number
  },
  salaryMax: {
    type: Number
  },
  salaryCurrency: {
    type: String,
    default: 'USD'
  },
  salaryPeriod: {
    type: String,
    enum: ['Hourly', 'Daily', 'Weekly', 'Monthly', 'Yearly'],
    default: 'Yearly'
  },
  category: {
    type: String,
    required: true
  },
  skills: [{
    type: String
  }],

  isActive: {
    type: Boolean,
    default: true
  },
  company: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  companyLogo: {
    type: String
  },
  applicants: [{
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    status: {
      type: String,
      enum: ['Pending', 'Reviewed', 'Interview', 'Accepted', 'Rejected'],
      default: 'Pending'
    },
    appliedAt: {
      type: Date,
      default: Date.now
    }
  }]
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Virtual field to format salary in Rupees
jobSchema.virtual('salary').get(function() {
  // If no salary data, return empty string
  if (!this.salaryMin && !this.salaryMax) {
    return '';
  }
  
  // Conversion rates (approximate as of 2024)
  const conversionRates = {
    'USD': 83,
    'EUR': 90,
    'GBP': 105,
    'CAD': 62,
    'AUD': 55
  };
  
  const rate = conversionRates[this.salaryCurrency] || conversionRates['USD'];
  
  // Convert to INR
  const minInr = this.salaryMin ? Math.round(this.salaryMin * rate) : null;
  const maxInr = this.salaryMax ? Math.round(this.salaryMax * rate) : null;
  
  // Format with commas
  const formatNumber = (num) => {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  };
  
  // Format based on available data
  if (minInr && maxInr) {
    return `₹${formatNumber(minInr)} - ₹${formatNumber(maxInr)}`;
  } else if (minInr) {
    return `₹${formatNumber(minInr)}+`;
  } else if (maxInr) {
    return `Up to ₹${formatNumber(maxInr)}`;
  } else {
    return '';
  }
});

// New virtual field to display salary in original currency and amount
jobSchema.virtual('formattedSalary').get(function() {
  // If no salary data, return empty string
  if (!this.salaryMin && !this.salaryMax) {
    return '';
  }
  
  // Format with commas
  const formatNumber = (num) => {
    if (!num) return '';
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  };
  
  // Format based on available data
  if (this.salaryMin && this.salaryMax) {
    return `₹${formatNumber(this.salaryMin)} - ₹${formatNumber(this.salaryMax)} ${this.salaryPeriod || ''}`;
  } else if (this.salaryMin) {
    return `₹${formatNumber(this.salaryMin)}+ ${this.salaryPeriod || ''}`;
  } else if (this.salaryMax) {
    return `Up to ₹${formatNumber(this.salaryMax)} ${this.salaryPeriod || ''}`;
  } else {
    return '';
  }
});

const Job = mongoose.model('Job', jobSchema);

export default Job;