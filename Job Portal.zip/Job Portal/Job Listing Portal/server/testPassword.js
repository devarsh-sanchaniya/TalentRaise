import bcrypt from 'bcryptjs';

async function testPassword() {
  try {
    // Hash password
    const salt = await bcrypt.genSalt(12);
    console.log('Salt:', salt);
    
    const plainPassword = 'Admin';
    const hashedPassword = await bcrypt.hash(plainPassword, salt);
    console.log('Plain password:', plainPassword);
    console.log('Hashed password:', hashedPassword);
    
    // Test comparison
    const isMatch = await bcrypt.compare(plainPassword, hashedPassword);
    console.log('Password match:', isMatch);
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

testPassword();