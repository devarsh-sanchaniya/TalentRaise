import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Job from './models/Job.model.js';

// Load environment variables
dotenv.config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/jobportal')
  .then(async () => {
    console.log('Connected to MongoDB');
    
    // Delete all jobs
    const result = await Job.deleteMany({});
    console.log(`Deleted ${result.deletedCount} jobs`);
    
    // Close connection
    mongoose.connection.close();
    console.log('Connection closed');
  })
  .catch(err => {
    console.error('Error:', err);
    mongoose.connection.close();
  });