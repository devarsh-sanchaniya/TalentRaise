import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import User from './models/User.model.js';

// Load environment variables
dotenv.config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/jobportal')
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  });

// Create admin user with new credentials
const createAdmin = async () => {
  try {
    // Delete existing admin user if exists
    await User.deleteOne({ email: 'admin@jobportal.com' });
    console.log('Existing admin user deleted');

    // Create admin user directly without going through the model's save method
    // to avoid double hashing
    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash('Admin@2025!', salt);
    
    const collection = mongoose.connection.collection('users');
    const result = await collection.insertOne({
      name: 'Administrator',
      email: 'admin@talentraise.com',
      password: hashedPassword,
      role: 'admin',
      isVerified: true,
      isActive: true,
      profile: {
        socialLinks: {
          linkedin: '',
          twitter: '',
          github: ''
        }
      },
      company: { isApproved: false },
      jobSeekerProfile: { skills: [], portfolio: [], experience: [], education: [] },
      createdAt: new Date(),
      updatedAt: new Date()
    });

    console.log('Admin user created successfully with ID:', result.insertedId);
    console.log('New admin credentials:');
    console.log('Email: admin@talentraise.com');
    console.log('Password: Admin@2025!');
    process.exit(0);
  } catch (error) {
    console.error('Error creating admin user:', error);
    process.exit(1);
  }
};

// Run the function
createAdmin();