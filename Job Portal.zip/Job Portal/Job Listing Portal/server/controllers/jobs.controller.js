import Job from '../models/Job.model.js';
import Application from '../models/Application.model.js';

// @desc    Get all jobs
// @route   GET /api/jobs
// @access  Public
export const getJobs = async (req, res) => {
  try {
    const pageSize = 10;
    const page = Number(req.query.page) || 1;

    // Build filter object
    const filter = {};
    
    if (req.query.search) {
      filter.$or = [
        { title: { $regex: req.query.search, $options: 'i' } },
        { description: { $regex: req.query.search, $options: 'i' } }
      ];
    }
    
    if (req.query.location) {
      filter.location = { $regex: req.query.location, $options: 'i' };
    }
    
    if (req.query.category) {
      filter.category = req.query.category;
    }
    
    if (req.query.employmentType) {
      filter.employmentType = req.query.employmentType;
    }
    
    if (req.query.experienceLevel) {
      filter.experienceLevel = req.query.experienceLevel;
    }
    
    // Handle salary range filtering
    if (req.query.salaryRange && req.query.salaryRange !== 'Any') {
      const salaryRange = req.query.salaryRange;
      
      if (salaryRange === '30,00,000+') {
        // For "30,00,000+" range, check if max salary is 30,00,000 or more
        filter.salaryMax = { $gte: 3000000 };
      } else {
        // For other ranges, parse the min and max values
        const rangeParts = salaryRange.split(' - ');
        if (rangeParts.length === 2) {
          // Remove commas and convert to numbers
          const minRange = parseInt(rangeParts[0].replace(/,/g, ''), 10);
          const maxRange = parseInt(rangeParts[1].replace(/,/g, ''), 10);
          
          // Filter jobs where salary range overlaps with the filter range
          filter.$or = filter.$or || [];
          filter.$or.push(
            { salaryMin: { $gte: minRange, $lte: maxRange } },
            { salaryMax: { $gte: minRange, $lte: maxRange } },
            { salaryMin: { $lte: minRange }, salaryMax: { $gte: maxRange } }
          );
        }
      }
    }

    const count = await Job.countDocuments(filter);
    const jobs = await Job.find(filter)
      .populate('company', 'name profile avatar company.name company.description company.industry company.website company.logo company.location company.size company.founded') // Populate company field with all company details
      .limit(pageSize)
      .skip(pageSize * (page - 1))
      .sort({ createdAt: -1 });
    
    // Convert to plain objects with virtuals
    const jobsWithVirtuals = jobs.map(job => job.toObject({ virtuals: true }));

    res.json({
      jobs: jobsWithVirtuals,
      page,
      pages: Math.ceil(count / pageSize),
      count
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get job by ID
// @route   GET /api/jobs/:id
// @access  Public
export const getJobById = async (req, res) => {
  try {
    console.log('Fetching job by ID:', req.params.id);
    const job = await Job.findById(req.params.id).populate('company', 'name profile avatar company.name company.description company.industry company.website company.logo company.location company.size company.founded');
    console.log('Found job:', job);
    
    if (job) {
      res.json(job.toObject({ virtuals: true }));
    } else {
      res.status(404).json({ message: 'Job not found' });
    }
  } catch (error) {
    console.error('Error fetching job by ID:', error);
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get jobs by user
// @route   GET /api/jobs/user
// @access  Private
export const getJobsByUser = async (req, res) => {
  try {
    console.log('Fetching jobs for user ID:', req.user._id);
    console.log('User object:', req.user);
    
    const jobs = await Job.find({ company: req.user._id })
      .populate('company', 'name profile avatar company.name company.description company.industry company.website company.logo company.location company.size company.founded') // Populate company field with all company details
      .sort({ createdAt: -1 });
      
    console.log(`Found ${jobs.length} jobs for user ${req.user._id}:`, jobs);
    
    // Log each job's company field for debugging
    jobs.forEach((job, index) => {
      console.log(`Job ${index + 1}:`, job.title, 'Company field:', job.company);
    });
    
    // Convert to plain objects with virtuals
    const jobsWithVirtuals = jobs.map(job => job.toObject({ virtuals: true }));
    
    res.json(jobsWithVirtuals);
  } catch (error) {
    console.error('Error fetching jobs by user:', error);
    res.status(500).json({ message: error.message });
  }
};

// @desc    Create a job
// @route   POST /api/jobs
// @access  Private (Employer only)
export const createJob = async (req, res) => {
  try {
    const {
      title,
      description,
      requirements,
      responsibilities,
      location,
      employmentType,
      experienceLevel,
      salaryMin,
      salaryMax,
      salaryPeriod,
      category,
      skills
    } = req.body;

    console.log('Creating job with company ID:', req.user._id);
    console.log('User object:', req.user);

    const jobData = {
      title,
      description,
      requirements,
      responsibilities,
      location,
      employmentType,
      experienceLevel,
      salaryMin,
      salaryMax,
      salaryPeriod,
      category,
      skills,
      company: req.user._id
    };

    // Add company logo if uploaded
    if (req.file) {
      jobData.companyLogo = `/uploads/${req.file.filename}`;
    }

    const job = new Job(jobData);

    const createdJob = await job.save();
    console.log('Created job:', createdJob);
    console.log('Created job company field:', createdJob.company);
    res.status(201).json(createdJob.toObject({ virtuals: true }));
  } catch (error) {
    console.error('Error creating job:', error);
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update a job
// @route   PUT /api/jobs/:id
// @access  Private (Employer only)
export const updateJob = async (req, res) => {
  try {
    const {
      title,
      description,
      requirements,
      responsibilities,
      location,
      employmentType,
      experienceLevel,
      salaryMin,
      salaryMax,
      salaryPeriod,
      category,
      skills,
      isActive
    } = req.body;

    // Populate the company field to ensure we have all the data
    const job = await Job.findById(req.params.id).populate('company', 'name profile avatar company.name company.description company.industry company.website company.logo company.location company.size company.founded');
    
    console.log('Updating job:', req.params.id);
    console.log('User:', req.user);
    console.log('Job:', job);

    if (job) {
      // Check if user is the owner of the job
      console.log('Job company ID:', job.company._id.toString());
      console.log('User ID:', req.user._id.toString());
      console.log('Comparison result:', job.company._id.toString() === req.user._id.toString());
      
      if (job.company._id.toString() !== req.user._id.toString()) {
        console.log('Not authorized to update job - user is not the owner');
        return res.status(401).json({ message: 'Not authorized' });
      }

      job.title = title || job.title;
      job.description = description || job.description;
      job.requirements = requirements || job.requirements;
      job.responsibilities = responsibilities || job.responsibilities;
      job.location = location || job.location;
      job.employmentType = employmentType || job.employmentType;
      job.experienceLevel = experienceLevel || job.experienceLevel;
      job.salaryMin = salaryMin || job.salaryMin;
      job.salaryMax = salaryMax || job.salaryMax;
      job.salaryPeriod = salaryPeriod || job.salaryPeriod;
      job.category = category || job.category;
      job.skills = skills || job.skills;
      job.isActive = isActive !== undefined ? isActive : job.isActive;

      // Update company logo if a new one is uploaded
      if (req.file) {
        job.companyLogo = `/uploads/${req.file.filename}`;
      }

      const updatedJob = await job.save();
      console.log('Updated job:', updatedJob);
      res.json(updatedJob.toObject({ virtuals: true }));
    } else {
      console.log('Job not found for update');
      res.status(404).json({ message: 'Job not found' });
    }
  } catch (error) {
    console.error('Error updating job:', error);
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete a job
// @route   DELETE /api/jobs/:id
// @access  Private (Employer only)
export const deleteJob = async (req, res) => {
  try {
    console.log('DELETE request received for job ID:', req.params.id);
    console.log('User making request:', req.user);
    
    // Populate the company field to ensure we have all the data
    const job = await Job.findById(req.params.id).populate('company', 'name profile avatar company.name company.description company.industry company.website company.logo company.location company.size company.founded');
    
    console.log('Found job for deletion:', job);

    if (job) {
      // Check if user is the owner of the job
      console.log('Job company ID:', job.company._id.toString());
      console.log('Requesting user ID:', req.user._id.toString());
      console.log('Comparison result:', job.company._id.toString() === req.user._id.toString());
      
      if (job.company._id.toString() !== req.user._id.toString()) {
        console.log('Not authorized to delete job - user is not the owner');
        return res.status(401).json({ message: 'Not authorized' });
      }

      // First delete all applications for this job
      await Application.deleteMany({ job: job._id });
      console.log('Deleted associated applications');

      // Delete the job
      await Job.deleteOne({ _id: job._id });
      console.log('Job deleted successfully');
      res.json({ message: 'Job removed' });
    } else {
      console.log('Job not found for deletion');
      res.status(404).json({ message: 'Job not found' });
    }
  } catch (error) {
    console.error('Error deleting job:', error);
    res.status(500).json({ message: error.message });
  }
};