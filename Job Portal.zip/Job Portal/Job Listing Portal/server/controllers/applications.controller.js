import path from 'path';
import fs from 'fs';
import Application from '../models/Application.model.js';
import Job from '../models/Job.model.js';

// @desc    Apply for a job
// @route   POST /api/applications
// @access  Private (Jobseeker only)
export const applyForJob = async (req, res) => {
  try {
    const { jobId, coverLetter } = req.body;
    const resume = req.file ? `/uploads/${req.file.filename}` : '';

    // Check if job exists
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }

    // Check if user has already applied
    const existingApplication = await Application.findOne({
      job: jobId,
      applicant: req.user._id
    });

    if (existingApplication) {
      return res.status(400).json({ message: 'You have already applied for this job' });
    }

    // Create application
    const application = new Application({
      job: jobId,
      applicant: req.user._id,
      resume,
      coverLetter
    });

    const createdApplication = await application.save();

    // Add applicant to job's applicants array
    job.applicants.push({
      user: req.user._id,
      status: 'Pending'
    });
    await job.save();

    res.status(201).json(createdApplication);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get applications for a job (Employer)
// @route   GET /api/applications/job/:jobId
// @access  Private (Employer only)
export const getApplicationsByJob = async (req, res) => {
  try {
    const applications = await Application.find({ job: req.params.jobId })
      .populate('applicant', 'name email profile')
      .populate({
        path: 'job',
        populate: {
          path: 'company',
          select: 'name'
        }
      });
      
    res.json(applications);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get applications by user (Jobseeker)
// @route   GET /api/applications/my-applications
// @access  Private (Jobseeker only)
export const getMyApplications = async (req, res) => {
  try {
    // First, get all applications for the user
    let applications = await Application.find({ applicant: req.user._id })
      .populate('job', 'title company')
      .populate({
        path: 'job',
        populate: {
          path: 'company',
          select: 'name company'
        }
      });
    
    // Filter out applications where the job no longer exists
    // This happens when an employer deletes their account
    applications = applications.filter(application => application.job !== null);
      
    res.json(applications);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update application status (Employer)
// @route   PUT /api/applications/:id
// @access  Private (Employer only)
export const updateApplicationStatus = async (req, res) => {
  try {
    const { status, notes } = req.body;

    const application = await Application.findById(req.params.id);
    if (!application) {
      return res.status(404).json({ message: 'Application not found' });
    }

    // Check if employer owns the job
    const job = await Job.findById(application.job);
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }

    // Compare ObjectId values correctly
    if (job.company.toString() !== req.user._id.toString()) {
      return res.status(401).json({ message: 'Not authorized' });
    }

    application.status = status || application.status;
    application.notes = notes || application.notes;

    const updatedApplication = await application.save();
    res.json(updatedApplication);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update application status (Admin)
// @route   PUT /api/applications/admin/:id
// @access  Private (Admin only)
export const updateApplicationStatusAdmin = async (req, res) => {
  try {
    const { status, notes } = req.body;

    const application = await Application.findById(req.params.id);
    if (!application) {
      return res.status(404).json({ message: 'Application not found' });
    }

    application.status = status || application.status;
    application.notes = notes || application.notes;

    const updatedApplication = await application.save();
    res.json(updatedApplication);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Download applicant resume (Employer)
// @route   GET /api/applications/:id/resume
// @access  Private (Employer only)
export const downloadResume = async (req, res) => {
  try {
    const application = await Application.findById(req.params.id);
    if (!application) {
      return res.status(404).json({ message: 'Application not found' });
    }

    // Check if employer owns the job
    const job = await Job.findById(application.job);
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }

    // Compare ObjectId values correctly
    if (job.company.toString() !== req.user._id.toString()) {
      return res.status(401).json({ message: 'Not authorized' });
    }

    // Construct full file path (resume path is stored as /uploads/filename)
    // We need to resolve the path relative to the server root
    const resumePath = path.resolve('uploads', path.basename(application.resume));
    
    // Check if resume file exists
    if (!fs.existsSync(resumePath)) {
      console.error('Resume file not found at path:', resumePath);
      return res.status(404).json({ message: 'Resume file not found' });
    }

    // Extract filename from path
    const filename = path.basename(application.resume);
    
    // Set headers for file download
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/octet-stream');
    
    // Send file
    res.sendFile(resumePath);
  } catch (error) {
    console.error('Error downloading resume:', error);
    res.status(500).json({ message: error.message });
  }
};

// @desc    Download applicant resume (Admin)
// @route   GET /api/applications/admin/:id/resume
// @access  Private (Admin only)
export const downloadResumeAdmin = async (req, res) => {
  try {
    const application = await Application.findById(req.params.id);
    if (!application) {
      return res.status(404).json({ message: 'Application not found' });
    }

    // Construct full file path (resume path is stored as /uploads/filename)
    // We need to resolve the path relative to the server root
    const resumePath = path.resolve('uploads', path.basename(application.resume));
    
    // Check if resume file exists
    if (!fs.existsSync(resumePath)) {
      console.error('Resume file not found at path:', resumePath);
      return res.status(404).json({ message: 'Resume file not found' });
    }

    // Extract filename from path
    const filename = path.basename(application.resume);
    
    // Set headers for file download
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'application/octet-stream');
    
    // Send file
    res.sendFile(resumePath);
  } catch (error) {
    console.error('Error downloading resume:', error);
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all applications (Admin)
// @route   GET /api/applications/admin/all
// @access  Private (Admin only)
export const getAllApplicationsAdmin = async (req, res) => {
  try {
    // Get all applications and populate related data
    let applications = await Application.find({})
      .populate('applicant', 'name email profile')
      .populate({
        path: 'job',
        populate: {
          path: 'company',
          select: 'name company'
        }
      })
      .sort({ createdAt: -1 });
      
    // Filter out applications where job or applicant no longer exist
    applications = applications.filter(application => 
      application.job !== null && 
      application.applicant !== null
    );
    
    res.json(applications);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};