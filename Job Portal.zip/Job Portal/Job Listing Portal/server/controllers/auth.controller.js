import jwt from 'jsonwebtoken';
import User from '../models/User.model.js';
import Job from '../models/Job.model.js';
import Application from '../models/Application.model.js';
import { body, validationResult } from 'express-validator';
import upload from '../middleware/upload.middleware.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Generate JWT token
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d'
  });
};

// @desc    Register user
// @route   POST /api/auth/register
// @access  Public
export const register = async (req, res) => {
  try {
    // Validation
    await body('name', 'Name is required').notEmpty().run(req);
    await body('email', 'Please include a valid email').isEmail().run(req);
    await body('password', 'Please enter a password with 6 or more characters').isLength({ min: 6 }).run(req);
    await body('role', 'Role is required').isIn(['jobseeker', 'employer', 'admin']).run(req);

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, email, password, role } = req.body;

    // Check if user exists
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Create user
    const userData = {
      name,
      email,
      password,
      role
    };

    // Handle profile image if uploaded
    if (req.file) {
      userData.profile = {
        avatar: `/uploads/${req.file.filename}`
      };
    }

    const user = await User.create(userData);

    if (user) {
      res.status(201).json({
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        profile: user.profile,
        token: generateToken(user._id)
      });
    } else {
      res.status(400).json({ message: 'Invalid user data' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Authenticate user & get token
// @route   POST /api/auth/login
// @access  Public
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
      return res.status(400).json({ message: 'Please provide email and password' });
    }

    // Check for user email
    const user = await User.findOne({ email }).select('+password');

    if (user && (await user.comparePassword(password))) {
      // Update the user's last activity time and set isOnline to true to mark as online
      await User.findByIdAndUpdate(user._id, { 
        lastActivity: new Date(),
        isOnline: true
      });
      
      res.json({
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        profile: user.profile,
        company: user.company,
        jobSeekerProfile: user.jobSeekerProfile,
        token: generateToken(user._id)
      });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get user profile
// @route   GET /api/auth/profile
// @access  Private
export const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      profile: user.profile,
      company: user.company,
      jobSeekerProfile: user.jobSeekerProfile,
      isVerified: user.isVerified,
      isOnline: user.isOnline,
      lastActivity: user.lastActivity,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update user profile
// @route   PUT /api/auth/profile
// @access  Private
export const updateProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (user) {
      // Update basic user info
      user.name = req.body.name || user.name;
      user.email = req.body.email || user.email;
      
      // Split name into first and last name if provided
      let firstName = user.profile?.firstName || '';
      let lastName = user.profile?.lastName || '';
      if (req.body.name) {
        // Also update firstName and lastName in profile
        const nameParts = req.body.name.trim().split(' ');
        firstName = nameParts[0] || '';
        lastName = nameParts.slice(1).join(' ') || '';
      }
      
      // Handle profile updates for both jobseekers and employers
      // Profile fields are sent directly in req.body, not nested under profile
      user.profile = {
        firstName: firstName,
        lastName: lastName,
        phone: req.body.phone || user.profile?.phone || '',
        location: req.body.location || user.profile?.location || '',
        bio: req.body.bio || user.profile?.bio || '',
        avatar: user.profile?.avatar || '',
        website: user.profile?.website || '',
        socialLinks: user.profile?.socialLinks || {
          linkedin: '',
          twitter: '',
          github: ''
        }
      };
      
      // Handle job seeker profile updates
      if (user.role === 'jobseeker') {
        if (!user.jobSeekerProfile) {
          user.jobSeekerProfile = {};
        }
        
        // Handle skills (array of strings)
        let updatedSkills = user.jobSeekerProfile.skills;
        if (req.body['profile[skills]'] !== undefined) {
          if (typeof req.body['profile[skills]'] === 'string') {
            updatedSkills = req.body['profile[skills]'].split(',').map(skill => skill.trim()).filter(skill => skill);
          } else {
            updatedSkills = req.body['profile[skills]'];
          }
        }
        
        // Handle experience (array of objects) - treat the text input as the first experience entry
        let updatedExperience = user.jobSeekerProfile.experience;
        if (req.body['profile[experience]'] !== undefined) {
          if (Array.isArray(updatedExperience) && updatedExperience.length > 0) {
            // Update the first experience entry
            updatedExperience[0] = { ...updatedExperience[0], description: req.body['profile[experience]'] };
          } else {
            // Create a new experience entry
            updatedExperience = [{ description: req.body['profile[experience]'], title: '', company: '', location: '', startDate: null, endDate: null, isCurrent: false }];
          }
        }
        
        user.jobSeekerProfile = {
          ...user.jobSeekerProfile,
          skills: updatedSkills,
          experience: updatedExperience
        };
      }

      // Handle company profile updates for employers
      if (req.body.company && user.role === 'employer') {
        user.company = {
          ...user.company,
          ...req.body.company
        };
      } else if (user.role === 'employer' && (
        req.body.companyName !== undefined || 
        req.body.companyDescription !== undefined || 
        req.body.companyIndustry !== undefined || 
        req.body.companyWebsite !== undefined || 
        req.body.companyLocation !== undefined || 
        req.body.companySize !== undefined || 
        req.body.companyFounded !== undefined
      )) {
        // Handle company fields sent directly in req.body for employers
        // Initialize company object if it doesn't exist
        if (!user.company) {
          user.company = {};
        }
        user.company = {
          ...user.company,
          name: req.body.companyName !== undefined ? req.body.companyName : user.company.name,
          description: req.body.companyDescription !== undefined ? req.body.companyDescription : user.company.description,
          industry: req.body.companyIndustry !== undefined ? req.body.companyIndustry : user.company.industry,
          website: req.body.companyWebsite !== undefined ? req.body.companyWebsite : user.company.website,
          location: req.body.companyLocation !== undefined ? req.body.companyLocation : user.company.location,
          size: req.body.companySize !== undefined ? req.body.companySize : user.company.size,
          founded: req.body.companyFounded !== undefined ? (req.body.companyFounded ? new Date(parseInt(req.body.companyFounded), 0, 1) : null) : user.company.founded
        };
      }

      // Handle profile image if uploaded
      if (req.file) {
        // Delete old avatar file if it exists
        if (user.profile?.avatar) {
          const oldAvatarPath = path.join(__dirname, '..', user.profile.avatar);
          if (fs.existsSync(oldAvatarPath)) {
            fs.unlinkSync(oldAvatarPath);
          }
        }
        
        // Update only the avatar field
        user.profile.avatar = `/uploads/${req.file.filename}`;
      }

      const updatedUser = await user.save();

      res.json({
        _id: updatedUser._id,
        name: updatedUser.name,
        email: updatedUser.email,
        role: updatedUser.role,
        profile: updatedUser.profile,
        company: updatedUser.company,
        jobSeekerProfile: updatedUser.jobSeekerProfile
      });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Logout user
// @route   POST /api/auth/logout
// @access  Public
export const logout = async (req, res) => {
  try {
    // Update user's last activity time and set isOnline to false to indicate logout
    if (req.user && req.user._id) {
      await User.findByIdAndUpdate(req.user._id, { 
        lastActivity: new Date(),
        isOnline: false
      });
    }
    
    res.json({ message: 'Logged out successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete user profile
// @route   DELETE /api/auth/profile
// @access  Private
export const deleteProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (user) {
      // Delete avatar file if it exists
      if (user.profile?.avatar) {
        const avatarPath = path.join(__dirname, '..', user.profile.avatar);
        if (fs.existsSync(avatarPath)) {
          fs.unlinkSync(avatarPath);
        }
      }

      // If user is an employer, delete their jobs and associated applications
      if (user.role === 'employer') {
        // Find all jobs posted by this employer
        const jobs = await Job.find({ company: user._id });
        
        // Delete all applications for these jobs
        const jobIds = jobs.map(job => job._id);
        if (jobIds.length > 0) {
          await Application.deleteMany({ job: { $in: jobIds } });
          console.log(`Deleted ${jobIds.length} job applications`);
        }
        
        // Delete all jobs posted by this employer
        await Job.deleteMany({ company: user._id });
        console.log(`Deleted ${jobs.length} jobs`);
      }
      
      // If user is a jobseeker, delete their applications
      if (user.role === 'jobseeker') {
        await Application.deleteMany({ applicant: user._id });
        console.log('Deleted jobseeker applications');
      }

      // Delete user from database
      await user.deleteOne();

      res.json({ message: 'User profile deleted successfully' });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update company logo
// @route   PUT /api/auth/company-logo
// @access  Private
export const updateCompanyLogo = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (user) {
      if (req.file) {
        // Delete old logo file if it exists
        if (user.company?.logo) {
          const oldLogoPath = path.join(__dirname, '..', user.company.logo);
          if (fs.existsSync(oldLogoPath)) {
            fs.unlinkSync(oldLogoPath);
          }
        }
        
        // Update company logo
        if (!user.company) {
          user.company = {};
        }
        user.company.logo = `/uploads/${req.file.filename}`;
        
        await user.save();
        
        res.json({
          _id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          profile: user.profile,
          company: user.company
        });
      } else {
        res.status(400).json({ message: 'No logo file uploaded' });
      }
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update user password
// @route   PUT /api/auth/password
// @access  Private
export const updatePassword = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('+password');

    if (user) {
      const { currentPassword, newPassword } = req.body;

      // Check if current password is correct
      if (!(await user.comparePassword(currentPassword))) {
        return res.status(401).json({ message: 'Current password is incorrect' });
      }

      // Validate new password length
      if (!newPassword || newPassword.length < 6) {
        return res.status(400).json({ message: 'New password must be at least 6 characters long' });
      }

      // Update password
      user.password = newPassword;
      await user.save();

      res.json({ message: 'Password updated successfully' });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
