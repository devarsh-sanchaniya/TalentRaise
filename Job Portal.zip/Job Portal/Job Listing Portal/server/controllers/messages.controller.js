import Message from '../models/Message.model.js';
import User from '../models/User.model.js';

// @desc    Send message to admin
// @route   POST /api/messages
// @access  Private (Employers and Job Seekers only)
export const sendMessage = async (req, res) => {
  try {
    const { subject, content } = req.body;
    
    // Find admin user
    const admin = await User.findOne({ role: 'admin' });
    
    if (!admin) {
      return res.status(404).json({ message: 'Admin user not found' });
    }
    
    const message = new Message({
      sender: req.user._id,
      recipient: admin._id,
      subject,
      content,
      senderRole: req.user.role,
      recipientRole: 'admin'
    });
    
    const savedMessage = await message.save();
    
    // Populate sender info for response
    await savedMessage.populate({
      path: 'sender',
      select: 'name email role profile',
      options: { strictPopulate: false }
    });
    
    res.status(201).json(savedMessage);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get messages for admin
// @route   GET /api/messages/admin
// @access  Private (Admin only)
export const getMessagesForAdmin = async (req, res) => {
  try {
    // Find all messages where the recipient role is 'admin'
    // This ensures all admins can see messages sent to any admin
    const messages = await Message.find({ recipientRole: 'admin' })
      .populate({
        path: 'sender',
        select: 'name email role profile',
        // Use null if sender is not found (in case user was deleted)
        options: { strictPopulate: false }
      })
      .sort({ createdAt: -1 });
    
    res.json(messages);
  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({ message: error.message });
  }
};

// @desc    Mark message as read
// @route   PUT /api/messages/admin/:id/read
// @access  Private (Admin only)
export const markMessageAsRead = async (req, res) => {
  try {
    const message = await Message.findOneAndUpdate(
      { 
        _id: req.params.id,
        recipientRole: 'admin'
      },
      { isRead: true },
      { new: true }
    ).populate({
      path: 'sender',
      select: 'name email role profile',
      options: { strictPopulate: false }
    });
    
    if (!message) {
      return res.status(404).json({ message: 'Message not found' });
    }
    
    res.json(message);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete message
// @route   DELETE /api/messages/admin/:id
// @access  Private (Admin only)
export const deleteMessage = async (req, res) => {
  try {
    const message = await Message.findOneAndDelete({
      _id: req.params.id,
      recipientRole: 'admin'
    });
    
    if (!message) {
      return res.status(404).json({ message: 'Message not found' });
    }
    
    res.json({ message: 'Message deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get unread message count for admin
// @route   GET /api/messages/admin/count
// @access  Private (Admin only)
export const getMessageCount = async (req, res) => {
  try {
    const count = await Message.countDocuments({
      recipientRole: 'admin',
      isRead: false
    });
    
    res.json({ count });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Reply to message as admin
// @route   POST /api/messages/admin/:id/reply
// @access  Private (Admin only)
export const replyToMessage = async (req, res) => {
  try {
    const { content } = req.body;
    
    // Validate request body
    if (!content || typeof content !== 'string' || content.trim() === '') {
      return res.status(400).json({ message: 'Content is required and must be a non-empty string' });
    }
    
    // Log the admin user making the request
    console.log('Admin user attempting reply:', req.user);
    
    const admin = req.user; // Admin user making the request
    
    // Find the original message to get sender information
    const originalMessage = await Message.findById(req.params.id);
    
    if (!originalMessage) {
      return res.status(404).json({ message: 'Original message not found' });
    }
    
    // Log the original message
    console.log('Original message:', originalMessage);
    
    // Validate that the original message has required fields
    if (!originalMessage.sender || !originalMessage.senderRole) {
      return res.status(400).json({ message: 'Invalid message: missing sender or sender role' });
    }
    
    // Verify that the original sender exists in the database
    const originalSender = await User.findById(originalMessage.sender);
    if (!originalSender) {
      return res.status(400).json({ message: 'Original message sender no longer exists' });
    }
    
    // Log the original sender
    console.log('Original sender:', originalSender);
    
    // Create a reply message with the original sender as recipient
    const replyMessage = new Message({
      sender: admin._id,
      recipient: originalMessage.sender, // Original sender becomes recipient of the reply
      subject: `Re: ${originalMessage.subject || 'Reply'}`, // Add 'Re:' prefix to indicate it's a reply
      content: content.trim(),
      senderRole: 'admin',
      recipientRole: originalMessage.senderRole // Use the original sender's role as recipient role
    });
    
    console.log('Creating reply message:', replyMessage);
    
    const savedReply = await replyMessage.save();
    
    // Populate sender info for response
    await savedReply.populate({
      path: 'sender',
      select: 'name email role profile',
      options: { strictPopulate: false }
    });
    
    res.status(201).json(savedReply);
  } catch (error) {
    console.error('Error replying to message:', error);
    // Return more specific error based on error type
    if (error.name === 'ValidationError') {
      return res.status(400).json({ message: 'Validation error: ' + error.message });
    }
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get messages for user
// @route   GET /api/messages/user
// @access  Private (Employers and Job Seekers only)
export const getMessagesForUser = async (req, res) => {
  try {
    // Find all messages where the current user is the recipient
    const messages = await Message.find({ recipient: req.user._id })
      .populate({
        path: 'sender',
        select: 'name email role profile',
        options: { strictPopulate: false }
      })
      .sort({ createdAt: -1 });
    
    res.json(messages);
  } catch (error) {
    console.error('Error fetching user messages:', error);
    res.status(500).json({ message: error.message });
  }
};

// @desc    Mark user message as read
// @route   PUT /api/messages/user/:id/read
// @access  Private (Employers and Job Seekers only)
export const markUserMessageAsRead = async (req, res) => {
  try {
    const message = await Message.findOneAndUpdate(
      { 
        _id: req.params.id,
        recipient: req.user._id
      },
      { isRead: true },
      { new: true }
    ).populate({
      path: 'sender',
      select: 'name email role profile',
      options: { strictPopulate: false }
    });
    
    if (!message) {
      return res.status(404).json({ message: 'Message not found' });
    }
    
    res.json(message);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get unread message count for user
// @route   GET /api/messages/user/count
// @access  Private (Employers and Job Seekers only)
export const getUserMessageCount = async (req, res) => {
  try {
    const count = await Message.countDocuments({
      recipient: req.user._id,
      isRead: false
    });
    
    res.json({ count });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete user message
// @route   DELETE /api/messages/user/:id
// @access  Private (Employers and Job Seekers only)
export const deleteUserMessage = async (req, res) => {
  try {
    const message = await Message.findOneAndDelete({
      _id: req.params.id,
      recipient: req.user._id  // Only allow user to delete messages sent to them (where they are recipient)
    });
    
    if (!message) {
      return res.status(404).json({ message: 'Message not found or you do not have permission to delete this message' });
    }
    
    res.json({ message: 'Message deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};