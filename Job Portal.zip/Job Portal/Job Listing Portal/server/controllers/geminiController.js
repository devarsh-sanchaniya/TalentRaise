import axios from 'axios';

const API_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';

export const getGeminiResponse = async (req, res) => {
  try {
    const { message } = req.body;
    
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: 'Gemini API key is not configured' });
    }

    const prompt = `You are a helpful career assistant for a job portal called TalentRaise. Provide helpful, professional responses related to job searching, career advice, resume building, interview preparation, and job applications. Keep responses concise but informative. If asked about specific job openings, suggest that the user search on the platform. User message: "${message}"`;

    const requestBody = {
      contents: [{
        parts: [{
          text: prompt
        }]
      }]
    };

    // Log the request for debugging
    console.log('Making request to Gemini API with prompt:', prompt.substring(0, 100) + '...');
    
    const response = await axios.post(
      `${API_BASE_URL}?key=${apiKey}`,
      requestBody,
      {
        headers: {
          'Content-Type': 'application/json',
        },
        timeout: 20000,
        maxRedirects: 5
      }
    );
    
    // Log the response for debugging
    console.log('Received response from Gemini API:', typeof response.data === 'object' ? 'Object received' : typeof response.data);

    const result = response.data;
    if (result.candidates && result.candidates[0]?.content?.parts?.[0]?.text) {
      return res.status(200).json({ 
        response: result.candidates[0].content.parts[0].text.trim() 
      });
    } else {
      console.error('Unexpected response format:', result);
      return res.status(500).json({ error: 'Invalid response format from Gemini API' });
    }
  } catch (error) {
    console.error('Error calling Gemini API:', error.message || error);
    console.error('Error details:', {
      status: error.response?.status,
      statusText: error.response?.statusText,
      data: error.response?.data,
      message: error.message
    });
    
    if (error.response?.status === 400) {
      return res.status(400).json({ error: "Invalid request to Gemini API: " + (error.response.data?.error?.message || 'Bad Request') });
    } else if (error.response?.status === 429) {
      return res.status(429).json({ error: "Rate limit exceeded. Please try again later." });
    } else if (error.response?.status === 401 || error.response?.status === 403) {
      return res.status(500).json({ error: "Authentication error with Gemini API. Please check your API key." });
    } else {
      return res.status(500).json({ error: "Error processing your request: " + (error.message || 'Unknown error') });
    }
  }
};