import User from '../models/User.model.js';
import Job from '../models/Job.model.js';
import Application from '../models/Application.model.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// @desc    Get all users (Admin)
// @route   GET /api/users
// @access  Private (Admin only)
export const getUsers = async (req, res) => {
  try {
    // Get all users except admins with additional information
    const users = await User.find({ role: { $ne: 'admin' } }).select('-password');
    
    // Enhance users with job counts for employers and application counts for job seekers
    const enhancedUsers = await Promise.all(users.map(async (user) => {
      // Use the isOnline field to determine if user is active
      const isOnline = user.isOnline;
      
      if (user.role === 'employer') {
        // Get job count for employers
        const jobCount = await Job.countDocuments({ company: user._id });
        return {
          ...user.toObject(),
          jobsCount: jobCount,
          isActive: isOnline
        };
      } else if (user.role === 'jobseeker') {
        // Get application count for job seekers
        const applicationCount = await Application.countDocuments({ applicant: user._id });
        return {
          ...user.toObject(),
          applicationsCount: applicationCount,
          isActive: isOnline
        };
      }
      return {
        ...user.toObject(),
        isActive: isOnline
      };
    }));
    
    res.json(enhancedUsers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete user (Admin)
// @route   DELETE /api/users/:id
// @access  Private (Admin only)
export const deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (user) {
      // Delete avatar file if it exists
      if (user.profile?.avatar) {
        const avatarPath = path.join(__dirname, '..', user.profile.avatar);
        if (fs.existsSync(avatarPath)) {
          fs.unlinkSync(avatarPath);
        }
      }

      // If user is an employer, delete their jobs and associated applications
      if (user.role === 'employer') {
        // Find all jobs posted by this employer
        const jobs = await Job.find({ company: user._id });
        
        // Delete all applications for these jobs
        const jobIds = jobs.map(job => job._id);
        if (jobIds.length > 0) {
          await Application.deleteMany({ job: { $in: jobIds } });
          console.log(`Deleted ${jobIds.length} job applications`);
        }
        
        // Delete all jobs posted by this employer
        await Job.deleteMany({ company: user._id });
        console.log(`Deleted ${jobs.length} jobs`);
      }
      
      // If user is a jobseeker, delete their applications
      if (user.role === 'jobseeker') {
        await Application.deleteMany({ applicant: user._id });
        console.log('Deleted jobseeker applications');
      }

      // Delete user from database
      await user.deleteOne();

      res.json({ message: 'User removed' });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get user by ID (Admin)
// @route   GET /api/users/:id
// @access  Private (Admin only)
export const getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');

    if (user) {
      res.json(user);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Approve company (Admin)
// @route   PUT /api/users/:id/approve-company
// @access  Private (Admin only)
export const approveCompany = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (user) {
      user.company.isApproved = true;
      const updatedUser = await user.save();
      res.json(updatedUser);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Block/unblock user (Admin)
// @route   PUT /api/users/:id/block
// @access  Private (Admin only)
export const blockUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (user) {
      user.isActive = !user.isActive;
      const updatedUser = await user.save();
      res.json({
        message: `User ${user.isActive ? 'unblocked' : 'blocked'} successfully`,
        user: updatedUser
      });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Close job (Admin)
// @route   PUT /api/users/admin/jobs/:id/close
// @access  Private (Admin only)
export const closeJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);

    if (job) {
      job.isActive = false;
      const updatedJob = await job.save();
      res.json({
        message: 'Job closed successfully',
        job: updatedJob
      });
    } else {
      res.status(404).json({ message: 'Job not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get admin statistics
// @route   GET /api/users/admin/stats
// @access  Private (Admin only)
export const getAdminStats = async (req, res) => {
  try {
    // Get counts for different entities (excluding admins)
    const totalUsers = await User.countDocuments({ role: { $ne: 'admin' } });
    const totalJobs = await Job.countDocuments({});
    const totalApplications = await Application.countDocuments({});
    const activeJobs = await Job.countDocuments({ isActive: true });
    
    // Get counts for specific user roles
    const totalEmployers = await User.countDocuments({ role: 'employer' });
    const totalJobSeekers = await User.countDocuments({ role: 'jobseeker' });
    
    res.json({
      totalUsers,
      totalJobs,
      totalApplications,
      activeJobs,
      totalEmployers,
      totalJobSeekers
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all jobs (Admin)
// @route   GET /api/users/admin/jobs
// @access  Private (Admin only)
export const getAllJobs = async (req, res) => {
  try {
    const jobs = await Job.find({}).populate({
      path: 'company',
      select: 'name email company avatar',
      populate: {
        path: 'company',
        select: 'name'
      }
    }).sort({ createdAt: -1 });
    res.json(jobs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete job (Admin)
// @route   DELETE /api/users/admin/jobs/:id
// @access  Private (Admin only)
export const deleteJobAsAdmin = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);

    if (job) {
      // Delete all applications for this job first
      await Application.deleteMany({ job: job._id });
      
      // Delete the job
      await Job.deleteOne({ _id: job._id });
      res.json({ message: 'Job removed' });
    } else {
      res.status(404).json({ message: 'Job not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update user (Admin)
// @route   PUT /api/users/:id
// @access  Private (Admin only)
export const updateUserAsAdmin = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (user) {
      // Update basic user info
      user.name = req.body.name || user.name;
      user.email = req.body.email || user.email;
      
      // Update profile fields
      if (req.body.profile) {
        user.profile = {
          ...user.profile,
          phone: req.body.profile.phone || user.profile?.phone || '',
          location: req.body.profile.location || user.profile?.location || ''
        };
      }
      
      // Update company fields for employers
      if (req.body.company && user.role === 'employer') {
        user.company = {
          ...user.company,
          name: req.body.company.name || user.company?.name,
          industry: req.body.company.industry || user.company?.industry
        };
      }

      const updatedUser = await user.save();
      res.json(updatedUser);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update job (Admin)
// @route   PUT /api/users/admin/jobs/:id
// @access  Private (Admin only)
export const updateJobAsAdmin = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);

    if (job) {
      // Update job fields
      job.title = req.body.title || job.title;
      job.location = req.body.location || job.location;
      job.salaryMin = req.body.salaryMin || job.salaryMin;
      job.salaryMax = req.body.salaryMax || job.salaryMax;

      const updatedJob = await job.save();
      res.json(updatedJob);
    } else {
      res.status(404).json({ message: 'Job not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update admin password
// @route   PUT /api/users/admin/password
// @access  Private (Admin only)
export const updateAdminPassword = async (req, res) => {
  try {
    // Find the admin user (the one making the request)
    const adminUser = await User.findById(req.user._id).select('+password');

    if (adminUser) {
      const { currentPassword, newPassword } = req.body;

      // Check if current password is correct
      if (!(await adminUser.comparePassword(currentPassword))) {
        return res.status(401).json({ message: 'Current password is incorrect' });
      }

      // Validate new password length
      if (!newPassword || newPassword.length < 6) {
        return res.status(400).json({ message: 'New password must be at least 6 characters long' });
      }

      // Update password
      adminUser.password = newPassword;
      await adminUser.save();

      res.json({ message: 'Admin password updated successfully' });
    } else {
      res.status(404).json({ message: 'Admin user not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get recent activities (Admin)
// @route   GET /api/users/admin/recent-activities
// @access  Private (Admin only)
export const getRecentActivities = async (req, res) => {
  try {
    // Fetch recent activities from all collections
    const recentUsers = await User.find({ role: { $ne: 'admin' } })
      .sort({ createdAt: -1 })
      .limit(5)
      .select('name email role createdAt');
    
    const recentJobs = await Job.find({})
      .populate('company', 'name email')
      .sort({ createdAt: -1 })
      .limit(5);
    
    const recentApplications = await Application.find({})
      .populate('applicant', 'name email')
      .populate('job', 'title')
      .sort({ createdAt: -1 })
      .limit(5);
    
    // Combine and sort all activities by timestamp
    const allActivities = [];
    
    // Add user registration activities
    recentUsers.forEach(user => {
      allActivities.push({
        type: 'user_registration',
        title: `${user.role === 'employer' ? 'New employer' : 'New job seeker'} registered`,
        description: `${user.name} joined the platform`,
        timestamp: user.createdAt,
        user: user
      });
    });
    
    // Add job posting activities
    recentJobs.forEach(job => {
      allActivities.push({
        type: 'job_posted',
        title: 'New job posted',
        description: `${job.title} position at ${job.company?.name || 'Company'}`,
        timestamp: job.createdAt,
        job: job
      });
    });
    
    // Add application submission activities
    recentApplications.forEach(app => {
      allActivities.push({
        type: 'application_submitted',
        title: 'New application submitted',
        description: `${app.applicant?.name || 'User'} applied for ${app.job?.title || 'a job'}`,
        timestamp: app.createdAt,
        application: app
      });
    });
    
    // Sort all activities by timestamp (newest first) and limit to 10
    const sortedActivities = allActivities
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
      .slice(0, 10);
    
    res.json(sortedActivities);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get system reports (Admin)
// @route   GET /api/users/admin/system-reports
// @access  Private (Admin only)
export const getSystemReports = async (req, res) => {
  try {
    // Get user growth data for the last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    // Get daily user registration counts
    const userGrowth = await User.aggregate([
      {
        $match: {
          role: { $ne: 'admin' },
          createdAt: { $gte: thirtyDaysAgo }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
          },
          count: { $sum: 1 },
          employers: {
            $sum: { $cond: [{ $eq: ["$role", "employer"] }, 1, 0] }
          },
          jobSeekers: {
            $sum: { $cond: [{ $eq: ["$role", "jobseeker"] }, 1, 0] }
          }
        }
      },
      { $sort: { _id: 1 } }
    ]);
    
    // Get job posting data
    const jobGrowth = await Job.aggregate([
      {
        $match: {
          createdAt: { $gte: thirtyDaysAgo }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
          },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);
    
    // Get application data
    const applicationGrowth = await Application.aggregate([
      {
        $match: {
          createdAt: { $gte: thirtyDaysAgo }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$createdAt" }
          },
          count: { $sum: 1 }
        }
      },
      { $sort: { _id: 1 } }
    ]);
    
    // Calculate additional metrics
    const totalUsers = await User.countDocuments({ role: { $ne: 'admin' } });
    const totalJobs = await Job.countDocuments({});
    const totalApplications = await Application.countDocuments({});
    const activeJobs = await Job.countDocuments({ isActive: true });
    
    const weeklyStats = {
      newUserRegistrations: await User.countDocuments({
        role: { $ne: 'admin' },
        createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
      }),
      newJobPosts: await Job.countDocuments({
        createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
      }),
      newApplications: await Application.countDocuments({
        createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
      })
    };
    
    res.json({
      userGrowth,
      jobGrowth,
      applicationGrowth,
      totals: {
        totalUsers,
        totalJobs,
        totalApplications,
        activeJobs
      },
      weeklyStats
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
