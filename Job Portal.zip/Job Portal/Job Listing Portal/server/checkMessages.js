import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Message from './models/Message.model.js';
import User from './models/User.model.js';

dotenv.config();

const connectDB = async () => {
  try {
    // Use the same URI as in server.js
    const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/jobportal';
    const conn = await mongoose.connect(uri);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

const checkMessages = async () => {
  await connectDB();
  
  try {
    // Find all messages
    const messages = await Message.find({}).populate('sender', 'name email role').populate('recipient', 'name email role');
    console.log('All messages:', messages);
    
    // Find admin user
    const admin = await User.findOne({ role: 'admin' });
    console.log('Admin user:', admin);
    
    if (admin) {
      // Find messages for admin
      const adminMessages = await Message.find({ recipient: admin._id }).populate('sender', 'name email role');
      console.log('Messages for admin:', adminMessages);
    }
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
};

checkMessages();