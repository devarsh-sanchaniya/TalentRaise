import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Application from './models/Application.model.js';

dotenv.config();

const connectDB = async () => {
  try {
    // Use the same URI as in server.js
    const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/jobportal';
    const conn = await mongoose.connect(uri);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

const deleteAllApplications = async () => {
  await connectDB();
  
  try {
    // Delete all applications
    const result = await Application.deleteMany({});
    console.log(`Deleted ${result.deletedCount} applications`);
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
};

deleteAllApplications();