import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from './models/User.model.js';

// Load environment variables
dotenv.config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/jobportal')
  .then(async () => {
    console.log('Connected to MongoDB');
    
    // Check if admin exists
    const admin = await User.findOne({ email: 'admin@jobportal.com' });
    console.log('Admin user:', admin);
    
    process.exit(0);
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  });