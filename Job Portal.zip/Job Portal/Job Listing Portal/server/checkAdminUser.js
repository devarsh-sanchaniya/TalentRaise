import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from './models/User.model.js';

dotenv.config();

const connectDB = async () => {
  try {
    // Use the same URI as in server.js
    const uri = process.env.MONGO_URI || 'mongodb://localhost:27017/jobportal';
    const conn = await mongoose.connect(uri);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

const checkAdminUser = async () => {
  await connectDB();
  
  try {
    // Find admin users
    const adminUsers = await User.find({ role: 'admin' });
    console.log('Admin users in database:', adminUsers);
    
    // Count admin users
    const adminCount = await User.countDocuments({ role: 'admin' });
    console.log('Total admin user count:', adminCount);
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
};

checkAdminUser();