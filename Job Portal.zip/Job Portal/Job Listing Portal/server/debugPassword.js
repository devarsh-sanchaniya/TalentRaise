import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import User from './models/User.model.js';

// Load environment variables
dotenv.config();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/jobportal')
  .then(async () => {
    console.log('Connected to MongoDB');
    
    try {
      // Find the admin user
      const user = await User.findOne({ email: 'admin@jobportal.com' });
      
      if (user) {
        console.log('User found:', user.email, user.role);
        console.log('Stored password hash:', user.password);
        
        // Test password comparison
        const isMatch = await user.comparePassword('Admin');
        console.log('Password comparison result:', isMatch);
        
        // Test manual bcrypt comparison
        const manualCompare = await bcrypt.compare('Admin', user.password);
        console.log('Manual bcrypt comparison result:', manualCompare);
      } else {
        console.log('Admin user not found');
      }
      
      process.exit(0);
    } catch (error) {
      console.error('Error:', error);
      process.exit(1);
    }
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  });