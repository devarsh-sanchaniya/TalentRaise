const axios = require('axios');
const mongoose = require('mongoose');

async function debugProfileDeletion() {
  try {
    console.log('Debugging profile deletion issue...');
    
    // Connect to MongoDB
    await mongoose.connect('mongodb://localhost:27017/jobportal');
    console.log('Connected to MongoDB');
    
    // Register a new test user
    const registerResponse = await axios.post('http://localhost:5000/api/auth/register', {
      name: 'Debug User',
      email: 'debuguser@test.com',
      password: 'password123',
      role: 'jobseeker'
    });
    
    console.log('Test user registered successfully');
    const token = registerResponse.data.token;
    const userId = registerResponse.data._id;
    
    // Check if user exists in database before deletion
    const User = require('./server/models/User.model.js');
    let userBefore = await User.findById(userId);
    console.log('User exists before deletion:', !!userBefore);
    if (userBefore) {
      console.log('User profile.avatar before deletion:', userBefore.profile?.avatar);
    }
    
    // Try to delete the profile
    console.log('\nAttempting to delete profile...');
    try {
      const deleteResponse = await axios.delete('http://localhost:5000/api/auth/profile', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      console.log('Delete response:', deleteResponse.data);
    } catch (error) {
      console.error('Delete error:', error.message);
      if (error.response) {
        console.error('Delete error response:', error.response.data);
        console.error('Delete error status:', error.response.status);
      }
    }
    
    // Check if user still exists in database after deletion
    let userAfter = await User.findById(userId);
    console.log('User exists after deletion:', !!userAfter);
    
    if (userAfter) {
      console.log('❌ ISSUE: User still exists in database after deletion attempt');
      console.log('User data:', JSON.stringify(userAfter, null, 2));
    } else {
      console.log('✅ SUCCESS: User properly deleted from database');
    }
    
    // Try to login with the deleted user (should fail)
    try {
      await axios.post('http://localhost:5000/api/auth/login', {
        email: 'debuguser@test.com',
        password: 'password123'
      });
      console.log('❌ ISSUE: Deleted user can still login');
    } catch (error) {
      if (error.response && error.response.status === 401) {
        console.log('✅ SUCCESS: Deleted user cannot login anymore');
      } else {
        console.log('❓ INFO: Unexpected error when trying to login with deleted user:', error.message);
      }
    }
    
    await mongoose.disconnect();
    
  } catch (error) {
    console.error('Debug error:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

debugProfileDeletion();