import axios from 'axios';

async function testAdminAPI() {
  try {
    console.log('Testing admin API endpoints...');
    
    // First, login as admin
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@jobportal.com',
      password: 'Admin'
    });
    
    const token = loginResponse.data.token;
    console.log('Admin logged in successfully');
    
    // Set default authorization header
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    
    // Test getting admin stats
    const statsResponse = await axios.get('http://localhost:5000/api/users/admin/stats');
    console.log('Admin stats:', statsResponse.data);
    
    // Test getting all users
    const usersResponse = await axios.get('http://localhost:5000/api/users');
    console.log('Users count:', usersResponse.data.length);
    
    // Test getting all jobs
    const jobsResponse = await axios.get('http://localhost:5000/api/users/admin/jobs');
    console.log('Jobs count:', jobsResponse.data.length);
    
    // Test getting all applications
    const applicationsResponse = await axios.get('http://localhost:5000/api/applications/admin/all');
    console.log('Applications count:', applicationsResponse.data.length);
    
    console.log('All admin API endpoints are working correctly!');
  } catch (error) {
    console.error('Error testing admin API:', error.response?.data || error.message);
  }
}

testAdminAPI();