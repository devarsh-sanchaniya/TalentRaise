const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();
const User = require('./server/models/User.model.js');

async function debugLogin() {
  try {
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/jobportal');
    console.log('Connected to MongoDB');
    
    // Find the admin user
    const user = await User.findOne({ email: 'admin@jobportal.com' }).select('+password');
    console.log('User found:', user ? 'Yes' : 'No');
    
    if (user) {
      console.log('User email:', user.email);
      console.log('User role:', user.role);
      console.log('Password hash length:', user.password.length);
      
      // Test password comparison
      const isMatch = await bcrypt.compare('Admin', user.password);
      console.log('Password match:', isMatch);
    } else {
      console.log('User not found in database');
    }
    
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
}

debugLogin();