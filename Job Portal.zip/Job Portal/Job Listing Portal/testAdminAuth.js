import axios from 'axios';

async function testAdminAuth() {
  try {
    console.log('Testing admin authentication and API access...');
    
    // First, login as admin
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@jobportal.com',
      password: 'Admin'
    });
    
    const token = loginResponse.data.token;
    console.log('Admin logged in successfully');
    console.log('Token:', token);
    console.log('User role:', loginResponse.data.role);
    
    // Create axios instance with auth header
    const api = axios.create({
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    // Test getting admin stats
    const statsResponse = await api.get('http://localhost:5000/api/users/admin/stats');
    console.log('Admin stats:', statsResponse.data);
    
    // Test getting all users
    const usersResponse = await api.get('http://localhost:5000/api/users');
    console.log('Users count:', usersResponse.data.length);
    
    // Test getting all jobs
    const jobsResponse = await api.get('http://localhost:5000/api/users/admin/jobs');
    console.log('Jobs count:', jobsResponse.data.length);
    
    // Test getting all applications
    const applicationsResponse = await api.get('http://localhost:5000/api/applications/admin/all');
    console.log('Applications count:', applicationsResponse.data.length);
    
    console.log('All admin API endpoints are working correctly!');
  } catch (error) {
    console.error('Error testing admin API:', error.response?.data || error.message);
  }
}

testAdminAuth();