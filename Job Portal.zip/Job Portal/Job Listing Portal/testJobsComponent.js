// Test script to verify Jobs component rendering
import React from 'react';

// Mock job data based on our diagnostic
const mockJobs = [
  {
    "_id": "692d84ab8e2c03fffe4f220d",
    "title": "Java Developer",
    "description": "ffsf sdflsdfj asdfsdf asdfsf asdsdf asdf d sd sd sdfsdfs ",
    "requirements": [
      "expereance"
    ],
    "responsibilities": [
      "team work"
    ],
    "location": "Mumbai",
    "employmentType": "Full-time",
    "experienceLevel": "Mid",
    "salaryMin": 30000,
    "salaryMax": 40000,
    "salaryCurrency": "USD",
    "salaryPeriod": "Monthly",
    "category": "Technology",
    "skills": [],
    "deadline": "2025-12-10T00:00:00.000Z",
    "isActive": true,
    "company": {
      "_id": "692d7de38e2c03fffe4f219f",
      "name": "Raj patel",
      "email": "raj@gmail.com"
    },
    "applicants": [
      {
        "user": "692b04a85ea9b9ae0dd316e4",
        "status": "Pending",
        "_id": "692d8fa07298a2aab35ee28a",
        "appliedAt": "2025-12-01T12:52:48.011Z",
        "id": "692d8fa07298a2aab35ee28a"
      }
    ],
    "createdAt": "2025-12-01T12:06:03.495Z",
    "updatedAt": "2025-12-01T12:52:48.014Z",
    "__v": 1,
    "salary": "₹2,490,000 - ₹3,320,000",
    "formattedSalary": "₹30,000 - ₹40,000 Monthly",
    "id": "692d84ab8e2c03fffe4f220d"
  }
];

// Test the getTypeClass function
const getTypeClass = (type) => {
  switch (type) {
    case 'Full-time':
      return 'bg-blue-100 text-blue-800';
    case 'Part-time':
      return 'bg-purple-100 text-purple-800';
    case 'Contract':
      return 'bg-green-100 text-green-800';
    case 'Internship':
      return 'bg-yellow-100 text-yellow-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

// Test the getStatusClass function
const getStatusClass = (status) => {
  switch (status) {
    case 'active':
      return 'bg-green-100 text-green-800';
    case 'closed':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

try {
  console.log('Testing Jobs component rendering...');
  console.log('Mock jobs count:', mockJobs.length);
  
  // Test mapping over jobs
  mockJobs.forEach((job, index) => {
    console.log(`Job ${index + 1}:`);
    console.log('  Title:', job.title);
    console.log('  Employment Type:', job.employmentType);
    console.log('  Type Class:', getTypeClass(job.employmentType));
    console.log('  Company:', job.company?.name || job.company?.company?.name || 'N/A');
    console.log('  Location:', job.location);
    console.log('  Salary:', job.salary);
    console.log('  Applicants:', job.applicants ? job.applicants.length : 0);
    console.log('  Status:', job.isActive ? 'Active' : 'Closed');
    console.log('  Status Class:', getStatusClass(job.isActive ? 'active' : 'closed'));
    console.log('  Created At:', new Date(job.createdAt).toLocaleDateString());
  });
  
  console.log('✅ Jobs component rendering test passed!');
} catch (error) {
  console.error('❌ Jobs component rendering test failed:', error);
}