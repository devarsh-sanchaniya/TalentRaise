const axios = require('axios');

async function testLogout() {
  try {
    console.log('Testing logout API...');
    
    // First login as admin to get token
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@jobportal.com',
      password: 'Admin'
    });
    
    const token = loginResponse.data.token;
    console.log('Admin token obtained');
    
    // Test logout endpoint
    const logoutResponse = await axios.post('http://localhost:5000/api/auth/logout', {}, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('Logout response:', logoutResponse.data);
    console.log('✅ Logout successful');
    
  } catch (error) {
    console.error('Error testing logout:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

testLogout();