import React, { useState, useEffect } from 'react';
import AdminLayout from './components/admin/AdminLayout';
import { adminAPI } from './services/api';

const TestJobsDebug = () => {
  const [jobs, setJobs] = useState([]);
  const [filteredJobs, setFilteredJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch jobs with extensive logging
  useEffect(() => {
    const fetchJobs = async () => {
      try {
        console.log('=== Starting job fetch ===');
        setLoading(true);
        setError(null);
        
        console.log('Calling adminAPI.getAllJobs()');
        const response = await adminAPI.getAllJobs();
        console.log('API response received:', response);
        console.log('Response data:', response.data);
        console.log('Response data length:', response.data.length);
        
        if (response.data && Array.isArray(response.data)) {
          console.log('Setting jobs state with', response.data.length, 'jobs');
          setJobs(response.data);
        } else {
          console.log('Response data is not an array or is null/undefined');
          setJobs([]);
        }
        
        setLoading(false);
        console.log('=== Job fetch completed ===');
      } catch (error) {
        console.error('Error fetching jobs:', error);
        console.error('Error response:', error.response);
        setError(error.message || 'Failed to fetch jobs');
        setLoading(false);
        setJobs([]);
      }
    };

    fetchJobs();
  }, []);

  // Log state changes
  useEffect(() => {
    console.log('Jobs state updated:', jobs.length, 'jobs');
    if (jobs.length > 0) {
      console.log('First job:', jobs[0]);
    }
  }, [jobs]);

  if (loading) {
    return (
      <AdminLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            <h1 className="text-2xl font-semibold text-gray-900">Job Management - DEBUG</h1>
          </div>
          <div className="mt-8">
            <div className="bg-white shadow overflow-hidden sm:rounded-lg">
              <div className="px-4 py-5 sm:px-6">
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
                  <span className="ml-4">Loading jobs... (Check console for logs)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </AdminLayout>
    );
  }

  if (error) {
    return (
      <AdminLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
            <h1 className="text-2xl font-semibold text-gray-900">Job Management - DEBUG</h1>
          </div>
          <div className="mt-8">
            <div className="bg-white shadow overflow-hidden sm:rounded-lg">
              <div className="px-4 py-5 sm:px-6">
                <div className="text-center py-12">
                  <h3 className="mt-2 text-sm font-medium text-red-600">Error Loading Jobs</h3>
                  <p className="mt-1 text-sm text-gray-500">{error}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-gray-900">Job Management - DEBUG</h1>
        </div>
        <div className="mt-8">
          <div className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:px-6">
              <h2>Debug Information</h2>
              <p>Total jobs: {jobs.length}</p>
              {jobs.length > 0 ? (
                <div>
                  <h3>Jobs List:</h3>
                  <ul>
                    {jobs.map((job, index) => (
                      <li key={job._id || index}>
                        <strong>{job.title}</strong> - {job.company?.name || job.company?.company?.name || 'Unknown Company'}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : (
                <p>No jobs found</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default TestJobsDebug;