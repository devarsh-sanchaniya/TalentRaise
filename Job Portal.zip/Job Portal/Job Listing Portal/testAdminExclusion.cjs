const axios = require('axios');

async function testAdminExclusion() {
  try {
    console.log('Testing admin exclusion from user list...');
    
    // First login as admin to get token
    const loginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@jobportal.com',
      password: 'Admin'
    });
    
    const token = loginResponse.data.token;
    console.log('Admin token obtained');
    
    // Test admin users endpoint
    const usersResponse = await axios.get('http://localhost:5000/api/users', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('Total users returned:', usersResponse.data.length);
    
    // Check if any admin users are in the list
    const adminUsers = usersResponse.data.filter(user => user.role === 'admin');
    console.log('Admin users in list:', adminUsers.length);
    
    if (adminUsers.length === 0) {
      console.log('✅ SUCCESS: No admin users found in user list');
    } else {
      console.log('❌ FAILURE: Found admin users in user list');
      console.log(adminUsers);
    }
    
    // Test admin stats endpoint
    const statsResponse = await axios.get('http://localhost:5000/api/users/admin/stats', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('Admin stats:', statsResponse.data);
    
  } catch (error) {
    console.error('Error testing admin exclusion:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

testAdminExclusion();