const axios = require('axios');
const fs = require('fs');

async function testProfileDeletion() {
  try {
    console.log('Testing profile deletion functionality...');
    
    // First, register a new test user
    const registerResponse = await axios.post('http://localhost:5000/api/auth/register', {
      name: 'Test User',
      email: 'testuser@example.com',
      password: 'password123',
      role: 'jobseeker'
    });
    
    console.log('Test user registered successfully');
    const token = registerResponse.data.token;
    
    // Test user-side profile deletion
    console.log('\n--- Testing User-Side Deletion ---');
    const deleteUserResponse = await axios.delete('http://localhost:5000/api/auth/profile', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    console.log('User-side deletion response:', deleteUserResponse.data);
    
    // Try to login with the deleted user (should fail)
    try {
      await axios.post('http://localhost:5000/api/auth/login', {
        email: 'testuser@example.com',
        password: 'password123'
      });
      console.log('❌ ERROR: Deleted user can still login');
    } catch (error) {
      if (error.response && error.response.status === 401) {
        console.log('✅ SUCCESS: Deleted user cannot login anymore');
      } else {
        console.log('❌ ERROR: Unexpected error when trying to login with deleted user');
      }
    }
    
    // Register another test user for admin-side deletion
    console.log('\n--- Testing Admin-Side Deletion ---');
    const registerResponse2 = await axios.post('http://localhost:5000/api/auth/register', {
      name: 'Test User 2',
      email: 'testuser2@example.com',
      password: 'password123',
      role: 'employer'
    });
    
    console.log('Second test user registered successfully');
    
    // Login as admin
    const adminLoginResponse = await axios.post('http://localhost:5000/api/auth/login', {
      email: 'admin@jobportal.com',
      password: 'Admin'
    });
    
    const adminToken = adminLoginResponse.data.token;
    console.log('Admin logged in successfully');
    
    // Get all users to find the test user
    const usersResponse = await axios.get('http://localhost:5000/api/users', {
      headers: {
        'Authorization': `Bearer ${adminToken}`
      }
    });
    
    const testUser = usersResponse.data.find(user => user.email === 'testuser2@example.com');
    if (!testUser) {
      console.log('❌ ERROR: Could not find test user for admin deletion');
      return;
    }
    
    console.log('Found test user for admin deletion:', testUser._id);
    
    // Test admin-side user deletion
    const adminDeleteResponse = await axios.delete(`http://localhost:5000/api/users/${testUser._id}`, {
      headers: {
        'Authorization': `Bearer ${adminToken}`
      }
    });
    
    console.log('Admin-side deletion response:', adminDeleteResponse.data);
    
    // Try to login with the admin-deleted user (should fail)
    try {
      await axios.post('http://localhost:5000/api/auth/login', {
        email: 'testuser2@example.com',
        password: 'password123'
      });
      console.log('❌ ERROR: Admin-deleted user can still login');
    } catch (error) {
      if (error.response && error.response.status === 401) {
        console.log('✅ SUCCESS: Admin-deleted user cannot login anymore');
      } else {
        console.log('❌ ERROR: Unexpected error when trying to login with admin-deleted user');
      }
    }
    
    console.log('\n🎉 All profile deletion tests completed!');
    
  } catch (error) {
    console.error('Error testing profile deletion:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
}

testProfileDeletion();