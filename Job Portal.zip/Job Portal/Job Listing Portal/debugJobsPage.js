// Debug script to check what's happening with the Jobs page
console.log('=== Jobs Page Debug ===');

// Check if we can access the DOM
console.log('Document readyState:', document.readyState);

// Try to find the admin layout
setTimeout(() => {
  const adminElements = document.querySelectorAll('[class*="admin"]');
  console.log('Admin elements found:', adminElements.length);
  
  // Try to find job-related elements
  const jobElements = document.querySelectorAll('[class*="job"]');
  console.log('Job-related elements found:', jobElements.length);
  
  // Check if there's a table
  const tables = document.querySelectorAll('table');
  console.log('Tables found:', tables.length);
  
  // Check for any content
  const allElements = document.querySelectorAll('*');
  console.log('Total elements on page:', allElements.length);
  
  // Look for specific text that should be in the Jobs page
  const jobManagementText = document.querySelector('h1');
  console.log('Page heading:', jobManagementText?.textContent);
  
  // Check for loading indicators
  const spinners = document.querySelectorAll('[class*="spin"], [class*="load"]');
  console.log('Spinners/loading indicators found:', spinners.length);
  
  // Check for "No jobs found" message
  const noJobsText = document.body.innerText.includes('No jobs found');
  console.log('Contains "No jobs found":', noJobsText);
}, 1000);